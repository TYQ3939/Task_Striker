# *********************************************************
# Program: taskstriker.py
# Course: PSP0201 MINI IT PROJECT
# Tutorial Section: TC5L    Group: G04
# Trimester: 2220
# Year: 2023 Trimester 2
# Member_1: 1211110592| LEE XUAN YU
# Member_2: 1211112131| EDWIN POT ZI BIN
# Member_3: 1211108881| LEE HONG YI
# Member_4: 1211108855| TEH YU QIAN
# *********************************************************
# Task Distribution
# Explain which function or which part of Python code you did
# LEE XUAN YU: Client menu(client profile, membership(tsp), client history, client logout)
# EDWIN POT ZI BIN: Get Started, Complete profile pro(in pro register), Pro menu(Pro profile, pro history, pro logout)
# LEE HONG YI: Browse(filter, next, previous, last, first), Chat system, Rating system, Report chat 
# TEH YU QIAN: Login, Register, Payment, Order details, Admin menu(Manage user data, manage user report)
# *********************************************************

# *********************************************************
# ----- Required Modules to pip install -----
# pip install ttkbootstrap
# pip install pillow
# *********************************************************
# ----- To run an order demo: -----
# first, login to a client acc (uid 222 and pwd 22222222 for demo)
# go to Browse, then choose a Pro (uid tyq123 for demo)
# in chat demo both click accept
# then order details will be shown

# then, login to pro acc (uid tyq123 and 11111111 for demo)
# go to My Order and view order details
# if click task complete will show error msg "Please wait for client to inform"

# Login back to client acc
# go to My Order, then click "task complete"
# key in total hours
# confirm payment
# choose payment
# payment complete
# rating
# order fully complete

# Login back to pro acc
# go to My Order
# click "task complete"
# confirm total commission fee
# Order Fully Completed
# got to both pro and client history and refresh to view order history
# *********************************************************



#  -------------------- import tkinter modules --------------------
from tkinter import *
from PIL import ImageTk, Image
from ttkbootstrap.constants import *
from ttkbootstrap.scrolled import ScrolledFrame
import ttkbootstrap as ttkb
from ttkbootstrap import Style
from tkinter import ttk
import tkinter.font as font
import datetime
import webbrowser
import threading
from datetime import date

# --------------------  Main window --------------------

root = ttkb.Window(themename="cosmo")
root.title("Task Striker")

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}+0+0")

# --------------------  Open txt file --------------------
global file_client
global client_content
global clientlist
file_client=open("clientlist.txt","r")
client_content=file_client.read()
clientlist=client_content.split("\n")

global file_pro
global pro_content
global prolist
file_pro=open("prolist.txt","r")
pro_content=file_pro.read()
prolist=pro_content.split("\n")

global pro_profile
global proprofile_content
global proprofile_list
pro_profile=open("pro_profile.txt","r")
proprofile_content=pro_profile.read()
proprofile_list=proprofile_content.split("\n")

global client_profile
global clientprofile_content
global clientprofile_list
client_profile=open("client_profile.txt","r")
clientprofile_content=client_profile.read()
clientprofile_list=clientprofile_content.split("\n")


# --------------------  Styles for texts (Font family and size etc.) --------------------

style_button1 = font.Font(family='Helvetica', size=10)
style_button2 = font.Font(family='Helvetica', size=15, weight='bold')
style_button3 = font.Font(family='Helvetica', size=20, weight='bold')
style_button4 = font.Font(family='Helvetica', size=10, weight='bold')
style_button5 = font.Font(family='Helvetica', size=40, weight='bold')

style_title1 = font.Font(family='Times New Roman', size=30, weight='bold')
style_title2 = font.Font(family='Times New Roman', size=40, weight='bold')
style_title3 = font.Font(family='Times New Roman', size=50, weight='bold')
style_title4 = font.Font(family='Times New Roman', size=80, weight='bold')

style_text1 = font.Font(family='Helvetica', size=20)
style_text2 = font.Font(family='Helvetica', size=17)
style_text3 = font.Font(family='Helvetica', size=15)

style_text4 = font.Font(family='Times New Roman', size=20, weight='bold')
style_text5 = font.Font(family='Helvetica', size=24, weight='bold')
style_text6 = font.Font(family='Times New Roman', size=25, weight='bold')

style_texterror = font.Font(family='Helvetica', size=10)

style_frame = ttkb.Style()
style_btn = ttkb.Style()
style_separator = ttkb.Style()

# --------------------- Frames --------------------

frame_main = Frame(root)

frame_getstart1 = Frame(root)
frame_getstart2 = Frame(root)
frame_getstart3 = Frame(root)
frame_getstart4 = Frame(root)

frame_login = Frame(root)
frame_choosecp = Frame(root)

frame_registerc = Frame(root)

frame_registerp = Frame(root)
frame_choosefield = Frame(root)
frame_startp = Frame(root)

frame_register_complete = Frame(root)

# -------------------- Functions --------------------

# -------------------- Creating Admin Menu --------------------
# Create homepagemin
homepagemin = ttkb.Notebook(root, style='TNotebook')
homepagemin.place(x=0, y=0, relheight=1, relwidth=1)

# Frame Home Admin
frame_parent_homemin = Frame(homepagemin)
frame_homemin = ttkb.Frame(frame_parent_homemin)

# Manage User
frame_chooseuser = Frame(frame_parent_homemin)
frame_clientlist = Frame(frame_parent_homemin)

frame_prolist = Frame(frame_parent_homemin)
frame_informpro = Frame(frame_parent_homemin)
frame_informcomplete = Frame(frame_parent_homemin)

frame_searchclientadmin = Frame(frame_parent_homemin)
frame_searchproadmin = Frame(frame_parent_homemin)
frame_adminpwd = Frame(frame_parent_homemin)
frame_managecomplete = Frame(frame_parent_homemin)

# Check User Report
frame_choosecheck = Frame(frame_parent_homemin)
frame_chatreport = Frame(frame_parent_homemin)
frame_taskreport = Frame(frame_parent_homemin)

# Frame Logout Admin
frame_parent_logoutmin = ttkb.Frame(homepagemin)
frame_logoutmin = Frame(frame_parent_logoutmin)

# Add Tabs to homepagemin
homepagemin.add(frame_parent_homemin, text='Home')
homepagemin.add(frame_parent_logoutmin, text='Logout')

# ---------- Home Admin ----------

# ----- Check User Report -----

# Function ignore report
def ignore_report():
    reportchat=open("reportchat.txt","r")
    reportchat_content=reportchat.read()
    reportchat_list=reportchat_content.split("\n")
    # Delete report details if choose ignore
    global report_table
    admin_selected = report_table.selection()
    if admin_selected:
        selected_item = report_table.selection()[0]
        selected_uid = report_table.item(selected_item)["values"][0]

        id_index_userlist = reportchat_list.index(selected_uid)
        if reportchat_list[id_index_userlist] == selected_uid:
            del reportchat_list[id_index_userlist:id_index_userlist + 9]
            reportchat = open("reportchat.txt", "w")
            reportchat.write("\n".join(reportchat_list))
            reportchat.close()

            check_report()
    else:
        lbl_error = Label(frame_chatreport, text="Please choose a report !", font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(fg="RED")

# Function ban(dlt) user 
def ban_user():
    reportchat=open("reportchat.txt","r")
    reportchat_content=reportchat.read()
    reportchat_list=reportchat_content.split("\n")

    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    client_profile=open("client_profile.txt","r")
    clientprofile_content=client_profile.read()
    clientprofile_list=clientprofile_content.split("\n")
    
    file_pro=open("prolist.txt","r")
    pro_content=file_pro.read()
    prolist=pro_content.split("\n")

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    # Delete reported uid's data in userlist and profilelist shown in second column that is choosed by admin
    global report_table
    admin_selected = report_table.selection()
    if admin_selected:
        selected_item = report_table.selection()[0]
        selected_uid = report_table.item(selected_item)["values"][0]
        reported_uid = report_table.item(selected_item)["values"][1]

        id_index_userlist = reportchat_list.index(selected_uid)
        if reportchat_list[id_index_userlist] == selected_uid:
            del reportchat_list[id_index_userlist:id_index_userlist + 9]
            reportchat = open("reportchat.txt", "w")
            reportchat.write("\n".join(reportchat_list))
            reportchat.close()
            # Check whether user in clientlist or prolist, and delete respective data
            if reported_uid in clientlist:
                id_index_userlist = clientlist.index(reported_uid)
                if clientlist[id_index_userlist] == reported_uid:
                    del clientlist[id_index_userlist:id_index_userlist + 6]
                    file_client = open("clientlist.txt", "w")
                    file_client.write("\n".join(clientlist))
                    file_client.close()

                id_index_profilelist = clientprofile_list.index(reported_uid)
                if clientprofile_list[id_index_profilelist] == reported_uid:
                    del clientprofile_list[id_index_profilelist:id_index_profilelist + 8]
                    client_profile = open("client_profile.txt", "w")
                    client_profile.write("\n".join(clientprofile_list))
                    client_profile.close()

                    check_report()

            if reported_uid in prolist:
                id_index_userlist = prolist.index(reported_uid)
                if prolist[id_index_userlist] == reported_uid:
                    del prolist[id_index_userlist:id_index_userlist + 4]
                    file_pro = open("prolist.txt", "w")
                    file_pro.write("\n".join(prolist))
                    file_pro.close()
                id_index_profilelist = proprofile_list.index(reported_uid)
                if proprofile_list[id_index_profilelist] == reported_uid:
                    del proprofile_list[id_index_profilelist:id_index_profilelist + 15]
                    pro_profile = open("pro_profile.txt", "w")
                    pro_profile.write("\n".join(proprofile_list))
                    pro_profile.close()
                    check_report()
    else:
        lbl_error = Label(frame_chatreport, text="Please choose a report !", font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(fg="RED")

# Function check user chat report
def check_report():
    reportchat=open("reportchat.txt","r")
    reportchat_content=reportchat.read()
    reportchat_list=reportchat_content.split("\n")

    frame_chatreport.place(x=0, y=0, relheight=1, relwidth=1)
    frame_chatreport.lift()

    # Create table to show user report
    columns = ("uid", "reported_uid", "reasons", "reason_other")

    global report_table
    report_table = ttkb.Treeview(frame_chatreport, bootstyle="dark", columns=columns, show="headings")
    report_table.place(relx=0.485, rely=0.35, anchor=CENTER, relwidth=0.95, relheight=0.6)

    hsb = ttkb.Scrollbar(frame_chatreport, orient="horizontal", command=report_table.xview)
    hsb.place(relx=0.485, rely=0.658, relwidth=0.95, anchor=CENTER)

    vsb = ttkb.Scrollbar(frame_chatreport, orient="vertical", command=report_table.yview)
    vsb.place(relx=0.96, rely=0.35, relheight=0.6, anchor=CENTER)

    report_table.configure(xscrollcommand=hsb.set)
    report_table.configure(yscrollcommand=vsb.set)

    report_table.heading('uid', text="UID")
    report_table.heading('reported_uid', text="Reported UID")
    report_table.heading('reasons', text="Reasons")
    report_table.heading('reason_other', text="Other")

    report_table.column("reasons", minwidth=0, width=1000, stretch=NO)
    report_table.column("reason_other", minwidth=0, width=600, stretch=NO)

    report_list = []

    # Loop in range of txt file and append report details into list
    for id_index in range(9,len(reportchat_list),9):
        uid = reportchat_list[id_index]
        reported_uid = reportchat_list[id_index+1]
        reason1 = reportchat_list[id_index+2]
        reason2 = reportchat_list[id_index+3]
        reason3 = reportchat_list[id_index+4]
        reason4 = reportchat_list[id_index+5]
        reason5 = reportchat_list[id_index+6]
        reason6 = reportchat_list[id_index+7]
        reason_other = reportchat_list[id_index+8]

        reasons = ", ".join([reason1, reason2, reason3, reason4, reason5, reason6])

        report_list.append((uid, reported_uid, reasons, reason_other))

    # Loop until all details inserted into table
    for report in report_list:
        report_table.insert("", END, values=report)

    style_btn_reportchat = ttkb.Style()
    style_btn_reportchat.configure("BtnReportChat.dark.TButton", font=('Helvetica',20,'bold'))

    btn_ignore = ttkb.Button(frame_chatreport, text="Ignore Report", width=30, style="BtnReportChat.dark.TButton", takefocus=False, command=ignore_report)
    btn_ignore.place(relx=0.4, rely=0.845, anchor=CENTER, height=80)

    style_btn_reportchat.configure("BtnReportChat.danger.TButton", font=('Helvetica',20,'bold'))
    btn_ban = ttkb.Button(frame_chatreport, text="Ban Reported User", width=30, style="BtnReportChat.danger.TButton", takefocus=False, command=ban_user)
    btn_ban.place(relx=0.75, rely=0.845, anchor=CENTER, height=80)

    style_btn_reportchat.configure("BtnBack.dark.Outline.TButton", font=('Helvetica',15))
    btn_back = ttkb.Button(frame_chatreport, text="Back", width=15,  style="BtnBack.dark.Outline.TButton", takefocus=False, command=lambda: frame_homemin.lift())
    btn_back.place(x=100, y=800, height=80)

# ----- Manage User -----

# Function admin complete dlt user
def dlt_complete():
    frame_managecomplete.place(x=0, y=0, relheight=1, relwidth=1)
    frame_managecomplete.pack_propagate(False)
    frame_managecomplete.lift()

    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    client_profile=open("client_profile.txt","r")
    clientprofile_content=client_profile.read()
    clientprofile_list=clientprofile_content.split("\n")

    file_pro=open("prolist.txt","r")
    pro_content=file_pro.read()
    prolist=pro_content.split("\n")

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")
    
    # Delete user data in userlist and userprofile (c/p)
    global user_type
    global selected_uid
    if user_type == "client":
        id_index_userlist = clientlist.index(selected_uid)
        if clientlist[id_index_userlist] == selected_uid:
            del clientlist[id_index_userlist:id_index_userlist + 6]
            file_client = open("clientlist.txt", "w")
            file_client.write("\n".join(clientlist))
            file_client.close()
        id_index_profilelist = clientprofile_list.index(selected_uid)
        if clientprofile_list[id_index_profilelist] == selected_uid:
            del clientprofile_list[id_index_profilelist:id_index_profilelist + 8]
            client_profile = open("client_profile.txt", "w")
            client_profile.write("\n".join(clientprofile_list))
            client_profile.close()

            btn_confirm = ttkb.Button(frame_managecomplete, text="Back to Menu", width=30, style="BtnConfirmDlt.dark.TButton", takefocus=False, command=admin_manageclient)
            btn_confirm.place(relx=0.5, rely=0.845, anchor=CENTER, height=80)
    if user_type == "pro":
        id_index_userlist = prolist.index(selected_uid)
        if prolist[id_index_userlist] == selected_uid:
            del prolist[id_index_userlist:id_index_userlist + 4]
            file_pro = open("prolist.txt", "w")
            file_pro.write("\n".join(prolist))
            file_pro.close()
        id_index_profilelist = proprofile_list.index(selected_uid)
        if proprofile_list[id_index_profilelist] == selected_uid:
            del proprofile_list[id_index_profilelist:id_index_profilelist + 15]
            pro_profile = open("pro_profile.txt", "w")
            pro_profile.write("\n".join(proprofile_list))
            pro_profile.close()

            btn_confirm = ttkb.Button(frame_managecomplete, text="Back to Menu", width=30, style="BtnConfirmDlt.dark.TButton", takefocus=False, command=admin_managepro)
            btn_confirm.place(relx=0.5, rely=0.845, anchor=CENTER, height=80)

    lbl_confirm = Label(frame_managecomplete, text="User Management Complete", font=style_title1)
    lbl_confirm.place(relx=0.5, rely=0.4, anchor=CENTER)

# Function check admin pwd
def check_adminpwd():
    admin_pwd = entry_pwdadmin.get()
    if admin_pwd == "333":
        entry_pwdadmin.delete(0, END)
        lbl_error = Label(frame_adminpwd, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(text="                                                            " )
        dlt_complete()
    else:
        entry_pwdadmin.delete(0, END)
        lbl_error = Label(frame_adminpwd, text="Password Incorrect !", font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(fg="RED")

# Function dlt user
def dlt_confirm():   
    style_btn_confirmdlt = ttkb.Style()
    style_btn_confirmdlt.configure("BtnConfirmDlt.dark.TButton", font=('Helvetica',20,'bold'))
    
    # Check if selected user is c/p
    global selected_uid
    if user_type == "client":
        # If client then get selection from client table, vice versa pro table, else prompt admin to choose user
        admin_selected = client_table.selection()
        if admin_selected:
            frame_adminpwd.place(x=0, y=0, relheight=1, relwidth=1)
            frame_adminpwd.pack_propagate(False)
            frame_adminpwd.lift()
            lbl_error = Label(frame_clientlist, font=style_text3)
            lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
            lbl_error.configure(text="                                                  ")
            # Get first column and its value
            selected_item = client_table.selection()[0]
            selected_uid = client_table.item(selected_item)["values"][0]

            lbl_confirm = Label(frame_adminpwd, text=f"Are you sure to delete User ID {selected_uid} ?", font=style_title1)
            lbl_confirm.place(relx=0.5, rely=0.3, anchor=CENTER)

            style_btn_confirmdlt.configure("BtnCancel.dark.Outline.TButton", font=('Helvetica',15))
            btn_cancel = ttkb.Button(frame_adminpwd, text="Cancel", width=15,  style="BtnCancel.dark.Outline.TButton", takefocus=False, command=lambda: frame_clientlist.lift())
            btn_cancel.place(x=100, y=800, height=80)
        else:
            lbl_error = Label(frame_clientlist, text="Please choose a Client !", font=style_text3)
            lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
            lbl_error.configure(fg="RED")
    if user_type == "pro":
        admin_selected = pro_table.selection()
        if admin_selected:
            frame_adminpwd.place(x=0, y=0, relheight=1, relwidth=1)
            frame_adminpwd.pack_propagate(False)
            frame_adminpwd.lift()
            lbl_error = Label(frame_prolist, font=style_text3)
            lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
            lbl_error.configure(text="                                                  ")
            selected_item = pro_table.selection()[0]
            selected_uid = pro_table.item(selected_item)["values"][0]

            lbl_confirm = Label(frame_adminpwd, text=f"Are you sure to delete User ID {selected_uid} ?", font=style_title1)
            lbl_confirm.place(relx=0.5, rely=0.3, anchor=CENTER)

            style_btn_confirmdlt.configure("BtnCancel.dark.Outline.TButton", font=('Helvetica',15))
            btn_cancel = ttkb.Button(frame_adminpwd, text="Cancel", width=15,  style="BtnCancel.dark.Outline.TButton", takefocus=False, command=lambda: frame_prolist.lift())
            btn_cancel.place(x=100, y=800, height=80)
        else:
            lbl_error = Label(frame_prolist, text="Please choose a Pro !", font=style_text3)
            lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
            lbl_error.configure(fg="RED")

    lbl_ifsure = Label(frame_adminpwd, text=f"If sure, please enter admin password for confirmation", font=style_title1)
    lbl_ifsure.place(relx=0.5, rely=0.45, anchor=CENTER)

    global entry_pwdadmin
    entry_pwdadmin = Entry(frame_adminpwd)
    entry_pwdadmin.place(relx=0.5, rely=0.55, anchor=CENTER, width=500, height=80)
    entry_pwdadmin.configure(font=style_title2, show="*")

    btn_confirm = ttkb.Button(frame_adminpwd, text="Confirm", width=30, style="BtnConfirmDlt.dark.TButton", takefocus=False, command=check_adminpwd)
    btn_confirm.place(relx=0.5, rely=0.845, anchor=CENTER, height=80)

# Function admin manage pro
def admin_managepro():
    frame_prolist.place(x=0, y=0, relheight=1, relwidth=1)
    frame_prolist.lift()
    
    file_pro=open("prolist.txt","r")
    pro_content=file_pro.read()
    prolist=pro_content.split("\n")

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    # Create table to list pro details
    columns = ("pro_uid", "pro_name", "pro_email", "pro_phone", "pro_gender", "pro_age", "pro_bday", "pro_bio", "pro_field", "pro_lit","pro_pgrm","pro_multi","pro_rating")

    global pro_table
    pro_table = ttkb.Treeview(frame_prolist, bootstyle="dark", columns=columns, show="headings")
    pro_table.place(relx=0.485, rely=0.35, anchor=CENTER, relwidth=0.95, relheight=0.6)

    hsb = ttkb.Scrollbar(frame_prolist, orient="horizontal", command=pro_table.xview)
    hsb.place(relx=0.485, rely=0.658, relwidth=0.95, anchor=CENTER)

    vsb = ttkb.Scrollbar(frame_prolist, orient="vertical", command=pro_table.yview)
    vsb.place(relx=0.96, rely=0.35, relheight=0.6, anchor=CENTER)

    pro_table.configure(xscrollcommand=hsb.set)
    pro_table.configure(yscrollcommand=vsb.set)

    pro_table.heading('pro_uid', text="Pro UID")
    pro_table.heading('pro_name', text="Pro Name")
    pro_table.heading('pro_email', text="Pro Email")
    pro_table.heading('pro_phone', text="Pro Phone")
    pro_table.heading('pro_gender', text="Pro Gender")
    pro_table.heading('pro_age', text="Pro Age")
    pro_table.heading('pro_bday', text="Pro Birthday")
    pro_table.heading('pro_bio', text="Pro Bio")
    pro_table.heading('pro_field', text="Pro Field")
    pro_table.heading('pro_lit', text="Pro Literature Skills")
    pro_table.heading('pro_pgrm', text="Pro Programming Skills")
    pro_table.heading('pro_multi', text="Pro Multimedia Skills")
    pro_table.heading('pro_rating', text="Pro Rating")

    pro_table.column("pro_email", minwidth=0, width=200, stretch=NO)
    pro_table.column("pro_bio", minwidth=0, width=1500, stretch=NO)
    pro_table.column("pro_field", minwidth=0, width=300, stretch=NO)
    pro_table.column("pro_lit", minwidth=0, width=700, stretch=NO)
    pro_table.column("pro_pgrm", minwidth=0, width=700, stretch=NO)
    pro_table.column("pro_multi", minwidth=0, width=700, stretch=NO)

    pro_infolist = []

    # Loop in range and append pro details into list
    for id_index in range(15,len(proprofile_list),15):
        pro_uid = proprofile_list[id_index]
        pro_name = proprofile_list[id_index+1]
        pro_email = proprofile_list[id_index+2]
        pro_phone = proprofile_list[id_index+3]
        pro_gender = proprofile_list[id_index+4]
        pro_age = proprofile_list[id_index+5]
        pro_bday = proprofile_list[id_index+6]
        pro_bio = proprofile_list[id_index+7]
        pro_rating = proprofile_list[id_index+14]

        # In txt file if value = "y", then value = Field, else "na"
        field_list = []
        if proprofile_list[id_index+8] == "y":
            field_list.append("Literature")
            pro_lit = proprofile_list[id_index+11]
        else:
            pro_lit = "na"
        if proprofile_list[id_index+9] == "y":
            field_list.append("Programming")
            pro_pgrm = proprofile_list[id_index+12]
        else:
            pro_pgrm = "na"
        if proprofile_list[id_index+10] == "y":
            field_list.append("Multimedia")
            pro_multi = proprofile_list[id_index+13]
        else:
            pro_multi = "na"
        pro_field = ",".join(field_list)

        
        pro_infolist.append((pro_uid, pro_name, pro_email, pro_phone, pro_gender, pro_age, pro_bday, pro_bio, pro_field, pro_lit, pro_pgrm, pro_multi, pro_rating))

    # Loop until all pro details is inserted into table
    for pro in pro_infolist:
        pro_table.insert("", END, values=pro)

    columns = pro_table["columns"]
    for column in columns:
        pro_table.column(column, stretch=YES)

    global user_type
    user_type = "pro"

    style_btnManagePro = ttkb.Style()
    style_btnManagePro.configure("BtnManagePro.dark.TButton", font=('Helvetica',20,'bold'))

    btn_dltpro = ttkb.Button(frame_prolist, text="Delete selected Pro data", width=30, style="BtnManagePro.dark.TButton", takefocus=False, command=dlt_confirm)
    btn_dltpro.place(relx=0.5, rely=0.845, anchor=CENTER, height=80)

    style_btnManagePro.configure("BtnBack.dark.Outline.TButton", font=('Helvetica',15))
    btn_back = ttkb.Button(frame_prolist, text="Back", width=15,  style="BtnBack.dark.Outline.TButton", takefocus=False, command=lambda: frame_chooseuser.lift())
    btn_back.place(x=100, y=800, height=80)

# Function admin manage client
def admin_manageclient():
    frame_clientlist.place(x=0, y=0, relheight=1, relwidth=1)
    frame_clientlist.pack_propagate(False)
    frame_clientlist.lift()

    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    client_profile=open("client_profile.txt","r")
    clientprofile_content=client_profile.read()
    clientprofile_list=clientprofile_content.split("\n")
    # Create table to list client details
    columns = ("client_uid", "client_name", "client_email", "client_phone", "client_gender", "client_age", "client_bday", "client_bio")

    global client_table
    client_table = ttkb.Treeview(frame_clientlist, bootstyle="dark", columns=columns, show="headings")
    client_table.place(relx=0.485, rely=0.35, anchor=CENTER, relwidth=0.95, relheight=0.6)

    # Bind scrollbars to table to scroll
    hsb = ttkb.Scrollbar(frame_clientlist, orient="horizontal", command=client_table.xview)
    hsb.place(relx=0.485, rely=0.658, relwidth=0.95, anchor=CENTER)

    vsb = ttkb.Scrollbar(frame_clientlist, orient="vertical", command=client_table.yview)
    vsb.place(relx=0.96, rely=0.35, relheight=0.6, anchor=CENTER)

    client_table.configure(xscrollcommand=hsb.set)
    client_table.configure(yscrollcommand=vsb.set)

    client_table.heading('client_uid', text="Client UID")
    client_table.heading('client_name', text="Client Name")
    client_table.heading('client_email', text="Client Email")
    client_table.heading('client_phone', text="Client Phone")
    client_table.heading('client_gender', text="Client Gender")
    client_table.heading('client_age', text="Client Age")
    client_table.heading('client_bday', text="Client Birthday")
    client_table.heading('client_bio', text="Client Bio")

    client_table.column("client_email", minwidth=0, width=200, stretch=NO)
    client_table.column("client_bio", minwidth=0, width=1000, stretch=NO)

    client_infolist = []

    # Loop in range client profile list and append client details in list
    for id_index in range(8,len(clientprofile_list),8):
        client_uid = clientprofile_list[id_index]
        client_name = clientprofile_list[id_index+1]
        client_email = clientprofile_list[id_index+2]
        client_phone = clientprofile_list[id_index+3]
        client_gender = clientprofile_list[id_index+4]
        client_age = clientprofile_list[id_index+5]
        client_bday = clientprofile_list[id_index+6]
        client_bio = clientprofile_list[id_index+7] 
        client_infolist.append((client_uid, client_name, client_email, client_phone, client_gender, client_age, client_bday, client_bio))

    # Loop to insert client details into table for client details in list
    for client in client_infolist:
        client_table.insert("", END, values=client)

    global user_type
    user_type = "client"

    style_btnManageClient = ttkb.Style()
    style_btnManageClient.configure("BtnManageClient.dark.TButton", font=('Helvetica',20,'bold'))

    btn_dltclient = ttkb.Button(frame_clientlist, text="Delete selected Client data", width=30, style="BtnManageClient.dark.TButton", takefocus=False, command=dlt_confirm)
    btn_dltclient.place(relx=0.5, rely=0.845, anchor=CENTER, height=80)

    style_btnManageClient.configure("BtnBack.dark.Outline.TButton", font=('Helvetica',15))
    btn_back = ttkb.Button(frame_clientlist, text="Back", width=15,  style="BtnBack.dark.Outline.TButton", takefocus=False, command=lambda: frame_chooseuser.lift())
    btn_back.place(x=100, y=800, height=80)

# Function admin choose c/p
def chooseuser():
    frame_chooseuser.place(x=0, y=0, relheight=1, relwidth=1)
    frame_chooseuser.pack_propagate(False)
    frame_chooseuser.lift()

    label_choose = Label(frame_chooseuser, text="Search Client or Pro", font=style_title2)
    label_choose.place(relx=0.5,rely=0.1, anchor=CENTER)

    style_btn_chooseuser = ttkb.Style()
    style_btn_chooseuser.configure("BtnChooseUser.dark.Outline.TButton", font=("Helvetica",15,"bold"))

    btn_client = ttkb.Button(frame_chooseuser, text="Client", width=30, style="BtnChooseUser.dark.Outline.TButton", takefocus=False, command=admin_manageclient)
    btn_client.place(relx=0.335, rely=0.42, anchor=CENTER, width=600, height=500)

    btn_pro = ttkb.Button(frame_chooseuser, text="Pro", width=30,  style="BtnChooseUser.dark.Outline.TButton", takefocus=False, command=admin_managepro)
    btn_pro.place(relx=0.665, rely=0.42, anchor=CENTER, width=600, height=500)

    style_btn_chooseuser.configure("Btnback.dark.Outline.TButton", font=("Helvetica",15))
    btn_back = ttkb.Button(frame_chooseuser, text="Back", width=15,  style="Btnback.dark.Outline.TButton", takefocus=False, command=lambda: frame_homemin.lift())
    btn_back.place(x=100, y=800, height=80)

# ----- Admin Menu -----

# Function home admin
def home_admin():
    frame_homemin.place(x=0, y=0, relheight=1, relwidth=1)
    frame_homemin.lift()

    # Configure the style of the buttons
    style_btn_homemin = ttkb.Style()
    style_btn_homemin.configure('BtnMin.dark.Outline.TButton', font=('Helvetica', 20))

    btn_userdata = ttkb.Button(frame_homemin, text='Manage User Data',width=30, style="BtnMin.dark.Outline.TButton", takefocus=False, command=chooseuser)
    btn_userreport = ttkb.Button(frame_homemin, text='Manage User Report',width=30, style="BtnMin.dark.Outline.TButton", takefocus=False, command=check_report)

    btn_userdata.place(relx=0.5, rely=0.25, anchor=CENTER, height=200)
    btn_userreport.place(relx=0.5, rely=0.65, anchor=CENTER, height=200)

# ----- Logout Admin ----- 

# Function confirm logout admin
def logoutmin_ok():
    homepagemin.select(0)
    global lbl_status
    lbl_status.configure(text="")
    main()

# Function cancel logout admin
def logoutmin_cancel():
    homepagemin.select(0)

frame_logoutmin.place(relx=0.5, rely=0.4, anchor=CENTER)
frame_logoutmin.pack_propagate(False)
frame_logoutmin.configure(padx=20, pady=20,highlightbackground="black", highlightthickness=4)
frame_logoutmin.lift()

lbl_biom = ttkb.Label(frame_logoutmin, text="Are you sure to logout from your account?", font=style_button3)
lbl_biom.grid(row=0, column=0, columnspan=2)

btn_okm = Button(frame_logoutmin, text="OK", width=15, height=3, font=style_button1, takefocus=False,command=logoutmin_ok)
btn_okm.grid(row=1, column=0)

btn_cancelm = Button(frame_logoutmin, text="Cancel", width=15, height=3, font=style_button1, takefocus=False,command=logoutmin_cancel)
btn_cancelm.grid(row=1, column=1)

# Show first page in home whenever clicked home tab
def show_framemin(min_tab_clicked):
    current_tab = min_tab_clicked.widget.tab('current')['text']
    if current_tab == "Home":
        frame_homemin.lift()

# Bind to keyboard/mouse so that when mouse left click, fucntion will be executed
homepagemin.bind("<Button-1>", show_framemin)

# ---------- Pro Home page functions ----------

# homepagep style
style_homepagep = Style(theme='vapor')

style_homepagep.configure('TNotebook.Tab', font=('Helvetica', 20), padding=(20, 10))

# Create homepagep
homepagep = ttkb.Notebook(root, style='TNotebook')
homepagep.place(x=0, y=0, relheight=1, relwidth=1)

# Frame Home Pro
frame_parent_homep = Frame(homepagep)
frame_homep = ttkb.Frame(frame_parent_homep)

frame_inboxp = Frame(frame_parent_homep)

frame_accountp = Frame(frame_parent_homep)
frame_enterpwdp = Frame(frame_parent_homep)
frame_newpwd_pro = Frame(frame_parent_homep)
frame_pwdupdatedp = Frame(frame_parent_homep)

frame_wlcbackp = Frame(frame_homep)
frame_search = Frame(frame_homep)
frame_proprofile = Frame(frame_search)

# Frame Profile Pro
frame_parent_profilep = ttkb.Frame(homepagep)
frame_profilep = Frame(frame_parent_profilep)
frame_editprofilep = Frame(frame_parent_profilep)

# Frame My Order Pro
frame_parent_orderp = ttkb.Frame(homepagep)

frame_noorderp = Frame(frame_parent_orderp)
frame_orderp = Frame(frame_parent_orderp)
frame_report_problemp = Frame(frame_parent_orderp)

frame_paymentp = Frame(frame_parent_orderp)
frame_completep = Frame(frame_parent_orderp)

# Frame History Pro
frame_parent_historyp = ttkb.Frame(homepagep)
frame_historyp = Frame(frame_parent_historyp)

# Frame Logout Pro
frame_parent_logoutp = ttkb.Frame(homepagep)
frame_logoutp = Frame(frame_parent_logoutp)

# Add Tabs to homepagep
homepagep.add(frame_parent_homep, text='Home')
homepagep.add(frame_parent_profilep, text='Profile')
homepagep.add(frame_parent_orderp, text='My Order')
homepagep.add(frame_parent_historyp, text='History')
homepagep.add(frame_parent_logoutp, text='Logout')

# ---------- Pro Login Home Page Functions ----------

# ----- MY ORDER PRO -----

# Function back to home after task completed
def backhome_orderp():
    frame_paymentp.place_forget()
    frame_orderp.place_forget()
    frame_completep.place_forget()
    # Call function to refresh My Order page
    orderp()
    homepagep.select(0)

# Function task complete pro
def task_completep():
    frame_completep.place(x=0, y=0, relheight=1, relwidth=1)
    frame_completep.pack_propagate(False)
    frame_completep.lift()

    pro_history=open("pro_history.txt","r")
    prohistory_content=pro_history.read()
    prohistory_list=prohistory_content.split("\n")

    # After task completed, append order details in history list
    pro_history=open("pro_history.txt","a")
    pro_history.write("\n"+pro_uid+"\n")
    pro_history.write(client_uid+"\n")
    pro_history.write(client_name+"\n")
    pro_history.write(client_email+"\n")
    pro_history.write(client_phone+"\n")
    pro_history.write(pro_field+"\n")
    pro_history.write(total_commission+"\n")
    pro_history.write(order_date)
    pro_history.close()

    pro_myorder=open("pro_myorder.txt","r")
    proorder_content=pro_myorder.read()
    proorder_list=proorder_content.split("\n")

    pro_idindex = proorder_list.index(pro_uid)
    del proorder_list[pro_idindex:pro_idindex + 8]
    pro_myorder = open("pro_myorder.txt", "w")
    pro_myorder.write("\n".join(proorder_list))
    pro_myorder.close()

    lbl_complete = ttkb.Label(frame_completep, text="Order Fully Completed ", font=style_title3)
    lbl_complete.place(relx=0.5, rely=0.3, anchor=CENTER)
    lbl_info = ttkb.Label(frame_completep, text="~ The commission fee will be deposited into your account in 5–10 minutes. Thank You ~", font=style_title1)
    lbl_info.place(relx=0.5, rely=0.4, anchor=CENTER)

    style_btn_tspcompletep = ttkb.Style()
    style_btn_tspcompletep.configure("BtnHome.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    btn_back = ttkb.Button(frame_completep, text="Back to Home", width=15,  style="BtnHome.dark.Outline.TButton", takefocus=False,command=backhome_orderp)
    btn_back.place(relx=0.5, rely=0.85, anchor=CENTER, width=700, height=100)

def paymentp():
    # Try until get nameerror(variable cant found), then show error msg telling pro to wait for client
    try:
        lbl_error = Label(frame_orderp, font=style_text3)
        lbl_error.place(relx=0.3, rely=0.85, anchor=CENTER)
        lbl_error.configure(text="                                                                                                                  ", fg="RED")

        frame_paymentp.place(x=0, y=0, relheight=1, relwidth=1)
        frame_paymentp.pack_propagate(False)
        frame_paymentp.lift()

        pro_myorder=open("pro_myorder.txt","r")
        proorder_content=pro_myorder.read()
        proorder_list=proorder_content.split("\n")

        client_history=open("client_history.txt","r")
        clienthistory_content=client_history.read()
        clienthistory_list=clienthistory_content.split("\n")

        global final_fee
        global total_commission
        # Counting of total commission fee: Client payment - 10% of client payment(platform fee)
        client_fee = float(final_fee)
        platform_fee = client_fee*0.1
        total_commission = "{:.2f}".format(client_fee - platform_fee)
        
        # Change price into 2dp
        final_fee_2f = "{:.2f}".format(client_fee)
        platform_fee_2f = "{:.2f}".format(platform_fee)

        lbl_profile = ttkb.Label(frame_paymentp, text="Commission Details", font=style_title2)
        lbl_profile.place(x=300, y=30)

        lbl_type = ttkb.Label(frame_paymentp, text="Type", font=style_title1)
        lbl_type.place(x=300, y=170)
        lbl_amount = ttkb.Label(frame_paymentp, text="Amount (RM)", font=style_title1)
        lbl_amount.place(x=1300, y=170)

        sep = ttkb.Separator(frame_paymentp, bootstyle="default", orient="horizontal")
        sep.place(relx=0.5, y=260, relwidth=0.8, anchor=CENTER)

        lbl_base = ttkb.Label(frame_paymentp, text="Client's Payment", font=style_text4)
        lbl_base.place(x=300, y=290)
        lbl_basenum = ttkb.Label(frame_paymentp, text=str(final_fee_2f), font=style_text4)
        lbl_basenum.place(x=1500, y=290, anchor=NE)

        lbl_hours = ttkb.Label(frame_paymentp, text="Platform commision (10%)", font=style_text4)
        lbl_hours.place(x=300, y=350)
        lbl_hoursnum = ttkb.Label(frame_paymentp, text=str(platform_fee_2f), font=style_text4)
        lbl_hoursnum.place(x=1500, y=350, anchor=NE)

        sep = ttkb.Separator(frame_paymentp, bootstyle="default", orient="horizontal")
        sep.place(relx=0.5, y=430, relwidth=0.8, anchor=CENTER)

        lbl_total = ttkb.Label(frame_paymentp, text="Total Commission", font=style_title1)
        lbl_total.place(x=900, y=470)
        lbl_totalnum = ttkb.Label(frame_paymentp, text=str(total_commission), font=style_title1)
        lbl_totalnum.place(x=1500, y=470, anchor=NE)

        style_btn_paymentp = ttkb.Style()
        style_btn_paymentp.configure("BtnOrder.dark.Outline.TButton", font=("Helvetica",15,"bold"))

        style_btn_paymentp.configure("BtnComplete.success.TButton", font=("Helvetica",15,"bold"))
        btn_confirm = ttkb.Button(frame_paymentp, text="Confirm", width=25,  style="BtnComplete.success.TButton", takefocus=False,command=task_completep)
        btn_confirm.place(relx=0.5, rely=0.8, height=80, anchor=CENTER)
    except NameError:
        orderp()
        lbl_error = Label(frame_orderp, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.85, anchor=CENTER)
        lbl_error.configure(text="Please wait for your Client to inform you !", fg="RED")

# Function order details pro
def orderp():

    frame_orderp.place(x=0, y=0, relheight=1, relwidth=1)
    frame_orderp.pack_propagate(False)
    frame_orderp.lift()

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    pro_myorder=open("pro_myorder.txt","r")
    proorder_content=pro_myorder.read()
    proorder_list=proorder_content.split("\n")

    # Try until get ValueError, then show no order now
    try:
        frame_noorderp.place_forget()
        global pro_uid
        pro_idindex = proorder_list.index(pro_uid)
        if proorder_list[pro_idindex] == pro_uid:
            pro_idindex = proorder_list.index(pro_uid)
            pro_uid = proorder_list[pro_idindex]
            client_uid = proorder_list[pro_idindex+1]
            client_name = proorder_list[pro_idindex+2]
            client_email = proorder_list[pro_idindex+3]
            client_phone = proorder_list[pro_idindex+4]
            pro_field = proorder_list[pro_idindex+5]
            priceperhour = proorder_list[pro_idindex+6]
            order_date = proorder_list[pro_idindex+7]

            lbl_profile = ttkb.Label(frame_orderp, text="Order Details", font=style_title2)
            lbl_profile.place(x=400, y=30)

            lbl_uid = ttkb.Label(frame_orderp, text="User ID:  " + client_uid, font=style_button3)
            lbl_uid.place(x=420, y=130)
            lbl_name = ttkb.Label(frame_orderp, text="Name:  " + client_name, font=style_button3)
            lbl_name.place(x=420, y=180)
            lbl_email = ttkb.Label(frame_orderp, text="Email:  " + client_email, font=style_button3)
            lbl_email.place(x=420, y=230)
            lbl_phone = ttkb.Label(frame_orderp, text="Phone:  " + client_phone, font=style_button3)
            lbl_phone.place(x=420, y=280)
            lbl_field = ttkb.Label(frame_orderp, text="Field:  " + pro_field, font=style_button3)
            lbl_field.place(x=420, y=330)
            lbl_fee = ttkb.Label(frame_orderp, text="Fee:  " + "RM"+str(priceperhour)+" / hour"    , font=style_button3)
            lbl_fee.place(x=420, y=380)
            lbl_date = ttkb.Label(frame_orderp, text="Order Date:  " + order_date    , font=style_button3)
            lbl_date.place(x=420, y=430)

            lbl_info = ttkb.Label(frame_orderp, text="* Please click this only after"  , font=style_text3)
            lbl_info.place(relx=0.5, rely=0.64, anchor=CENTER)
            lbl_info2 = ttkb.Label(frame_orderp, text="  your Client informed you."  , font=style_text3)
            lbl_info2.place(relx=0.5, rely=0.67, anchor=CENTER)

            style_btn_orderp = ttkb.Style()
            style_btn_orderp.configure("BtnOrder.dark.Outline.TButton", font=("Helvetica",15,"bold"))

            style_btn_orderp.configure("BtnComplete.success.TButton", font=("Helvetica",15,"bold"))
            btn_complete = ttkb.Button(frame_orderp, text="Task Completed!", width=20,  style="BtnComplete.success.TButton", takefocus=False,command=paymentp)
            btn_complete.place(relx=0.5, rely=0.75, height=80, anchor=CENTER)
    except ValueError:
        frame_noorderp.place(x=0, y=0, relheight=1, relwidth=1)
        frame_noorderp.pack_propagate(False)
        frame_noorderp.lift()

        lbl_noorder = ttkb.Label(frame_noorderp, text="There's no order now!", font=style_title2)
        lbl_noorder.place(relx=0.5, rely=0.4, anchor=CENTER)


# ----- HISTORY PRO -----

# Function history pro
def history_pro():
    frame_historyp.place(x=0, y=0, relheight=1, relwidth=1)
    frame_historyp.pack_propagate(False)
    frame_historyp.lift()

    pro_history=open("pro_history.txt","r")
    prohistory_content=pro_history.read()
    prohistory_list=prohistory_content.split("\n")

    # Try until get UnboundLocalError(no value associated to variable), then show no history
    try:
        lbl_history = ttkb.Label(frame_historyp, text="Order History", font=style_title2)
        lbl_history.place(x=300,y=30)

        sep = ttkb.Separator(frame_historyp, bootstyle="default", orient="horizontal")
        sep.place(relx=0.5, y=160, relwidth=1, anchor=CENTER)

        style_btn_refresh = ttkb.Style()
        style_btn_refresh.configure("BtnRefresh.dark.Outline.TButton", font=("Helvetica",15))
        btn_back = ttkb.Button(frame_historyp, text="Refresh", width=15,  style="BtnRefresh.dark.Outline.TButton", takefocus=False, command=history_pro)
        btn_back.place(relx=0.8, y=30, height=80)

        frame_historyscroll = ScrolledFrame(frame_historyp, autohide=FALSE)
        frame_historyscroll.place(relx=0.5, rely=0.565, anchor=CENTER, width=1880, height=800)

        # Loop in range of list and show history details
        for id_index in range(8, len(prohistory_list),8):
            if prohistory_list[id_index] == pro_uid:
                client_uid = prohistory_list[id_index+1]
                client_name = prohistory_list[id_index+2]
                client_email = prohistory_list[id_index+3]
                client_phone = prohistory_list[id_index+4]
                pro_field = prohistory_list[id_index+5]
                total_commission = prohistory_list[id_index+6]
                order_date = prohistory_list[id_index+7]

            frame_prohistory1 = Frame(frame_historyscroll)
            lbl_date = Label(frame_prohistory1, text="Order Date: "+order_date, font=style_text4)
            lbl_date.pack(padx=200, pady=20, side=LEFT)  
            frame_prohistory2 = Frame(frame_historyscroll)
            lbl_uid = Label(frame_prohistory2, text="Client's User ID: "+client_uid, font=style_text4)
            lbl_uid.pack(padx=200, pady=20, side=LEFT)
            frame_prohistory3 = Frame(frame_historyscroll)
            lbl_name = Label(frame_prohistory3, text="Client's Name: "+client_name, font=style_text4)
            lbl_name.pack(padx=200, pady=20,side=LEFT)
            frame_prohistory4 = Frame(frame_historyscroll)
            lbl_email = Label(frame_prohistory4, text="Client's Email address: "+client_email, font=style_text4)
            lbl_email.pack(padx=200, pady=20, side=LEFT)
            frame_prohistory5 = Frame(frame_historyscroll)
            lbl_phone = Label(frame_prohistory5, text="Client's Phone number: "+client_phone, font=style_text4)
            lbl_phone.pack(padx=200, pady=20, side=LEFT)
            frame_prohistory6 = Frame(frame_historyscroll)
            lbl_field = Label(frame_prohistory6, text="Field: "+pro_field, font=style_text4)
            lbl_field.pack(padx=200, pady=20, side=LEFT)
            frame_prohistory7 = Frame(frame_historyscroll)
            lbl_fee = Label(frame_prohistory7, text="Total Commission Fee: RM "+total_commission, font=style_text4)
            lbl_fee.pack(padx=200, pady=20, side=LEFT)

            frame_prohistory1.pack(fill=X, expand=True)
            frame_prohistory2.pack(fill=X, expand=True)
            frame_prohistory3.pack(fill=X, expand=True)
            frame_prohistory4.pack(fill=X, expand=True)
            frame_prohistory5.pack(fill=X, expand=True)
            frame_prohistory6.pack(fill=X, expand=True)
            frame_prohistory7.pack(fill=X, expand=True)

            sep = ttkb.Separator(frame_historyscroll, bootstyle="default", orient="horizontal")
            sep.pack(ipadx=800, pady=20)
    except UnboundLocalError:
        lbl_noorder = ttkb.Label(frame_historyp, text="There's no previous order now~", font=style_title2)
        lbl_noorder.place(relx=0.5, rely=0.4, anchor=CENTER)

def history_pro():

    frame_historyp.place(x=0, y=0, relheight=1, relwidth=1)
    frame_historyp.pack_propagate(False)
    frame_historyp.lift()

    pro_history=open("pro_history.txt","r")
    prohistory_content=pro_history.read()
    prohistory_list=prohistory_content.split("\n")

    lbl_history = ttkb.Label(frame_historyp, text="Order History", font=style_title2)
    lbl_history.place(x=300,y=30)

    style_btn_refresh = ttkb.Style()
    style_btn_refresh.configure("BtnRefresh.dark.Outline.TButton", font=("Helvetica",15))
    btn_back = ttkb.Button(frame_historyp, text="Refresh", width=15,  style="BtnRefresh.dark.Outline.TButton", takefocus=False, command=history_pro)
    btn_back.place(relx=0.8, y=30, height=80)

    sep = ttkb.Separator(frame_historyp, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=160, relwidth=1, anchor=CENTER)

    try:
        # Create order details table
        columns = ("order_date", "client_uid", "client_name", "client_email", "client_phone", "pro_field", "total_commission")

        global pro_history_table
        pro_history_table = ttkb.Treeview(frame_historyp, bootstyle="dark", columns=columns, show="headings")
        pro_history_table.place(relx=0.485, rely=0.55, anchor=CENTER, relwidth=0.95, relheight=0.6)

        hsb = ttkb.Scrollbar(frame_historyp, orient="horizontal", command=pro_history_table.xview)
        hsb.place(relx=0.485, rely=0.858, relwidth=0.95, anchor=CENTER)

        vsb = ttkb.Scrollbar(frame_historyp, orient="vertical", command=pro_history_table.yview)
        vsb.place(relx=0.96, rely=0.55, relheight=0.6, anchor=CENTER)

        pro_history_table.configure(xscrollcommand=hsb.set)
        pro_history_table.configure(yscrollcommand=vsb.set)

        pro_history_table.heading('order_date', text="Order Date")
        pro_history_table.heading('client_uid', text="Client UID")
        pro_history_table.heading('client_name', text="Client Name")
        pro_history_table.heading('client_email', text="Client Email")
        pro_history_table.heading('client_phone', text="Client Phone")
        pro_history_table.heading('pro_field', text="Field")
        pro_history_table.heading('total_commission', text="Total Commission")

        pro_history_table.column("client_email", minwidth=0, width=200, stretch=NO)

        history_pro_list = []

        # Loop in range and append order details into list
        for id_index in range(8,len(prohistory_list),8):
            client_uid = prohistory_list[id_index+1]
            client_name = prohistory_list[id_index+2]
            client_email = prohistory_list[id_index+3]
            client_phone = prohistory_list[id_index+4]
            pro_field = prohistory_list[id_index+5]
            total_commission = prohistory_list[id_index+6]
            order_date = prohistory_list[id_index+7]
            
            history_pro_list.append((order_date, client_uid, client_name, client_email, client_phone, pro_field, total_commission))

        # Loop until all order details is inserted into table
        for order in history_pro_list:
            pro_history_table.insert("", END, values=order)

        columns = pro_history_table["columns"]
        for column in columns:
            pro_history_table.column(column, stretch=YES)
    except UnboundLocalError:
        lbl_noorder = ttkb.Label(frame_historyp, text="There's no previous order now~", font=style_title2)
        lbl_noorder.place(relx=0.5, rely=0.4, anchor=CENTER)

# ----- Home Pro -----

# Function pwd updated pro
def pwd_updatedp():
    frame_pwdupdatedp.place(x=0, y=0, relheight=1, relwidth=1)
    frame_pwdupdatedp.lift()

    lbl_success = ttkb.Label(frame_pwdupdatedp, text="Password Updated", font=style_title2)
    lbl_success.place(x=200,y=30)
    lbl_welcome = ttkb.Label(frame_pwdupdatedp, text="Password Successfully Updated ! ", font=style_title3)
    lbl_welcome.place(relx=0.5, rely=0.3, anchor=CENTER)

    style_btn_pwdupdatedp = ttkb.Style()
    style_btn_pwdupdatedp.configure("BtnBack.dark.Outline.TButton", font=("Helvetica",20,"bold"), padding=(50, 30))
    btn_confirm = ttkb.Button(frame_pwdupdatedp, text="Back to Home", width=20, style="BtnBack.dark.Outline.TButton", takefocus=False, command=lambda: frame_homep.lift())
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER)

# Function check new pwd
def check_newpwd_pro():

    file_pro=open("prolist.txt","r")
    pro_content=file_pro.read()
    prolist=pro_content.split("\n")

    # Check new pwd whether empty, <8 chars, not matched with confirmation etc.
    if entry_newpwdp.get() == "":
        entry_newpwdp.delete(0, END)
        entry_newpwdconfirmp.delete(0, END)
        lbl_error = Label(frame_newpwd_pro, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(text="                  Please enter a password !               ", fg="RED")
    else:
        if len(entry_newpwdp.get()) <8:
            entry_newpwdp.delete(0, END)
            entry_newpwdconfirmp.delete(0, END)
            lbl_error = Label(frame_newpwd_pro, font=style_text3)
            lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
            lbl_error.configure(text="                  Password must be 8 characters or more !                 ", fg="RED")
        else:
            if entry_newpwdp.get() != entry_newpwdconfirmp.get():
                entry_newpwdp.delete(0, END)
                entry_newpwdconfirmp.delete(0, END)
                lbl_error = Label(frame_newpwd_pro, font=style_text3)
                lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
                lbl_error.configure(text="                  Password Confirmation failed! Please try again.                 ", fg="RED")
            else:
                # If all requirements fulfilled, update new pwd in pro list
                lbl_error = Label(frame_newpwd_pro, font=style_text3)
                lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
                lbl_error.configure(text="                                                                             ")
                newpwdp = entry_newpwdp.get()

                id_index = prolist.index(pro_uid)
                prolist[id_index+2] = newpwdp
                file_pro=open("prolist.txt", "w")
                file_pro.write("\n".join(prolist))
                file_pro.close()
                pwd_updatedp()

# Function pro enter new pwd and confirmation
def newpwd_pro():
    frame_newpwd_pro.place(x=0, y=0, relheight=1, relwidth=1)
    frame_newpwd_pro.lift()

    lbl_profile = ttkb.Label(frame_newpwd_pro, text="Change Password", font=style_title2)
    lbl_profile.place(x=300, y=30)

    lbl_enterpwd = ttkb.Label(frame_newpwd_pro, text="Please enter new password: ", font=style_title1)
    lbl_enterpwd.place(relx=0.08, rely=0.3)
    lbl_enterpwdconfirm = ttkb.Label(frame_newpwd_pro, text="Please enter password confirmation: ", font=style_title1)
    lbl_enterpwdconfirm.place(relx=0.08, rely=0.4)

    global entry_newpwdp
    entry_newpwdp = Entry(frame_newpwd_pro)
    entry_newpwdp.place(relx=0.55, rely=0.3, width=600, height=80)
    entry_newpwdp.configure(font=style_title1, show="*")

    global entry_newpwdconfirmp
    entry_newpwdconfirmp = Entry(frame_newpwd_pro)
    entry_newpwdconfirmp.place(relx=0.55, rely=0.4, width=600, height=80)
    entry_newpwdconfirmp.configure(font=style_title1, show="*")

    style_btn_enternewpwdp = ttkb.Style()
    style_btn_enternewpwdp.configure("BtnConfirm.dark.TButton", font=("Helvetica",20,"bold"), padding=(50, 30))
    btn_confirm = ttkb.Button(frame_newpwd_pro, text="Confirm", width=20, style="BtnConfirm.dark.TButton", takefocus=False, command=check_newpwd_pro)
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER)

    btn_back = ttkb.Button(frame_newpwd_pro, text="Cancel", width=15, style="BtnCancel.dark.Outline.TButton", takefocus=False, command=lambda: frame_accountp.lift())
    btn_back.place(relx=0.15, rely=0.85, height=100, anchor=CENTER)

# Function check pro pwd
def check_pwd_pro():
    # If pwd entered matched with current pwd proceed, else show error msg prompt user reenter
    if entry_pwdp.get() == pro_pwd:
        lbl_error = Label(frame_enterpwdp, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(text="                                                    ")
        newpwd_pro()
    else:
        entry_pwdp.delete(0, END)
        lbl_error = Label(frame_enterpwdp, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(text="Password Incorrect !", fg="RED")

# Function change pro pwd
def change_pwd_pro():
    frame_enterpwdp.place(x=0, y=0, relheight=1, relwidth=1)
    frame_enterpwdp.lift()

    lbl_enterpwd = ttkb.Label(frame_enterpwdp, text="Please enter password: ", font=style_title1)
    lbl_enterpwd.place(relx=0.3, rely=0.3, anchor=CENTER)

    global entry_pwdp
    entry_pwdp = Entry(frame_enterpwdp)
    entry_pwdp.place(relx=0.6, rely=0.3, anchor=CENTER, width=600, height=80)
    entry_pwdp.configure(font=style_title1, show="*")

    style_btn_enterpwdp = ttkb.Style()
    style_btn_enterpwdp.configure("BtnConfirm.dark.TButton", font=("Helvetica",20,"bold"), padding=(50, 30))
    btn_confirm = ttkb.Button(frame_enterpwdp, text="Confirm", width=20, style="BtnConfirm.dark.TButton", takefocus=False, command=check_pwd_pro)
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER)

    style_btn_enterpwdp.configure("BtnCancel.dark.Outline.TButton", font=("Helvetica",15,"bold"))
    btn_back = ttkb.Button(frame_enterpwdp, text="Cancel", width=15, style="BtnCancel.dark.Outline.TButton", takefocus=False, command=lambda: frame_accountp.lift())
    btn_back.place(relx=0.15, rely=0.85, height=100, anchor=CENTER)

# Function show pro acc
def show_accountp():
    frame_accountp.place(x=0, y=0, relheight=1, relwidth=1)
    frame_accountp.lift()

    lbl_account= ttkb.Label(frame_accountp, text="Manage Account", font=style_title2)
    lbl_account.place(x=300, y=30)

    lbl_uid = ttkb.Label(frame_accountp, text="User ID: " + pro_uid, font=style_title1)
    lbl_uid.place(relx=0.5, rely=0.3, anchor=CENTER)

    style_btn_accountp = ttkb.Style()
    style_btn_accountp.configure("BtnAccountP.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    btn_pwd = ttkb.Button(frame_accountp, text="Change Password", width=20,  style="BtnAccountP.dark.Outline.TButton", takefocus=False, command=change_pwd_pro)
    btn_pwd.place(relx=0.5, rely=0.5, height=120, anchor=CENTER)

    style_btn_accountp.configure("BtnBack.dark.Outline.TButton", font=("Helvetica",15,"bold"))
    btn_back = ttkb.Button(frame_accountp, text="Back", width=15, style="BtnBack.dark.Outline.TButton", takefocus=False, command=lambda: frame_homep.lift())
    btn_back.place(relx=0.15, rely=0.85, height=100, anchor=CENTER)

# Frame home pro
def home_loginp():

    frame_homep.place(x=0, y=0, relheight=1, relwidth=1)
    frame_homep.lift()

    global pro_name
    global icon_profile
    global icon_search

    frame_homep.place(x=0, y=0, relheight=1, relwidth=1)

    lbl_wlcb1 = ttkb.Label(frame_homep, text="Hi, "+pro_name, font=style_title4)
    lbl_wlcb1.place(x=100, y=120)

    lbl_wlcb2 = ttkb.Label(frame_homep, text="It's nice to see you here. Hope you found your desire Client!", font=style_title1)
    lbl_wlcb2.place(x=120, y=280)

    sep = ttkb.Separator(frame_homep, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=90, relwidth=1, anchor='center')

    icon_profile = 'C:\VSCode\sem3 project\iconprofile.png'
    icon_profile = PhotoImage(file='C:\VSCode\sem3 project\iconprofile.png')
    btn_profilep = ttkb.Button(frame_homep, image=icon_profile, bootstyle="light", takefocus=False,command=show_accountp)
    btn_profilep.place(x=1770, y=20)
    btn_profilep.configure()

    sep2 = ttkb.Separator(frame_homep, bootstyle="default", orient="horizontal")
    sep2.place(relx=0.49, y=600, relwidth=1, anchor='center')

    style_btnfeedback = ttkb.Style()
    style_btnfeedback.configure("BtnFeedback.primary.TButton", font=('Helvetica',15), padding=(50, 24))

    btn_feedback = ttkb.Button(frame_homep, text="Give us a feedback!", style="BtnFeedback.primary.TButton", takefocus=False, command=feedbackc)
    btn_feedback.place(relx=0.05, y=820)

# ----- PROFILE PRO -----

def cancel_profilep():
    frame_editprofilep.place_forget()
    frame_profilep.lift()

# Function check edit profile pro
def check_profilep():

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    client_profile=open("client_profile.txt","r")
    clientprofile_content=client_profile.read()
    clientprofile_list=clientprofile_content.split("\n")

    global pro_uid
    global entry_name
    global entry_email
    global entry_phone
    global entry_gender
    global var_age
    global entry_bday
    global entry_lit
    global entry_pgrm
    global entry_multi
    global entry_litskill1
    global entry_litskill2
    global entry_litskill3
    global entry_pgrmskill1
    global entry_pgrmskill2
    global entry_pgrmskill3
    global entry_multiskill1
    global entry_multiskill2
    global entry_multiskill3
    global lbl_biotext
    global entry_bday

    # Get birthday from date entry
    pro_bday = entry_bday.entry.get()
    # Change input from str to date format
    pro_bday = datetime.datetime.strptime(pro_bday, "%d/%m/%Y").date()
    # Get today's date
    today = date.today()
    # Calculate age by substracting today's date's year and birthday date year
    # then substract a Boolean(1/0) that represents if today's day/month precedes the birth day/month
    pro_age = today.year - pro_bday.year - ((today.month, today.day) < (pro_bday.month, pro_bday.day))
    
    # Create empty list and append entry status into list
    status_list = []
    if not entry_name.get():
        status_list.append("name_empty")
    if not entry_email.get():
        status_list.append("email_empty")
    if entry_email.get() != pro_email:
        if entry_email.get() in clientprofile_list or entry_email.get() in proprofile_list:
            status_list.append("email_exist")
    if not entry_phone.get():
        status_list.append("phone_empty")
    if entry_phone.get() != pro_phone:
        if entry_phone.get() in clientprofile_list or entry_phone.get() in proprofile_list:
            status_list.append("phone_exist")
    # Need to choose at least one field
    if check_lit.get() + check_pgrm.get() + check_multi.get() == 0:
        status_list.append("field_empty")
    # Age needs to be above or equal to 19
    if pro_age < 19:
        status_list.append("age_small")

    # If status exist in status list
    if status_list:
        
        lbl_errorname = Label(frame_editprofilep, font=style_texterror)
        lbl_errorname.place(x=1400, y=135)
        lbl_errorname.configure(fg='RED', text = "                                                ")
        lbl_erroremail = Label(frame_editprofilep, font=style_texterror)
        lbl_erroremail.place(x=1400, y=185)
        lbl_erroremail.configure(fg='RED', text = "                                                          ")
        lbl_errorphone = Label(frame_editprofilep, font=style_texterror)
        lbl_errorphone.place(x=1400, y=235)
        lbl_errorphone.configure(fg='RED', text = "                                                          ")
        lbl_errorfield = Label(frame_editprofilep, font=style_texterror)
        lbl_errorfield.place(x=1400, y=385, anchor=CENTER)
        lbl_errorfield.configure(fg='RED', text = "                                                           ")
        lbl_errorage = Label(frame_editprofilep, font=style_texterror)
        lbl_errorage.place(x=1400, y=385, anchor=CENTER)
        lbl_errorage.configure(fg='RED', text = "                                                           ")
        lbl_age = ttkb.Label(frame_editprofilep, text="Age: "+str(pro_age)+"                 " , font=style_button3)
        lbl_age.place(x=300, y=280)
        lbl_status = Label(frame_editprofilep, font=style_texterror)
        lbl_status.place(relx=0.5, rely=0.78, anchor=CENTER)
        lbl_status.configure(fg='RED', text = "                                             ")
        # Loop to show error msges untill all requirements fulfilled
        for status in status_list:
            if status == "name_empty":
                lbl_errorname = Label(frame_editprofilep, font=style_texterror)
                lbl_errorname.place(x=1400, y=135)
                lbl_errorname.configure(fg='RED', text = "Please enter name!     ")
            if status == "email_empty":
                lbl_erroremail = Label(frame_editprofilep, font=style_texterror)
                lbl_erroremail.place(x=1400, y=185)
                lbl_erroremail.configure(fg='RED', text = "Please enter email address!       ")
            if status == "email_exist":
                lbl_erroremail = Label(frame_editprofilep, font=style_texterror)
                lbl_erroremail.place(x=1400, y=185)
                lbl_erroremail.configure(fg='RED', text = "Email address already exist!       ")
            if status == "phone_empty":
                lbl_errorphone = Label(frame_editprofilep, font=style_texterror)
                lbl_errorphone.place(x=1400, y=235)
                lbl_errorphone.configure(fg='RED', text = "Please enter phone number!        ")
            if status == "phone_exist":
                lbl_errorphone = Label(frame_editprofilep, font=style_texterror)
                lbl_errorphone.place(x=1400, y=235)
                lbl_errorphone.configure(fg='RED', text = "Phone number already exist!       ")
            if status == "field_empty":
                lbl_errorfield = Label(frame_editprofilep, font=style_texterror)
                lbl_errorfield.place(x=1400, y=385, anchor=CENTER)
                lbl_errorfield.configure(fg='RED', text = "*** Please choose at least 1 field !")
            if status == "age_small":
                lbl_age = ttkb.Label(frame_editprofilep, text="Age: "+str(pro_age)+"                 " , font=style_button3)
                lbl_age.place(x=300, y=280)
                lbl_errorage = Label(frame_editprofilep, font=style_texterror)
                lbl_errorage.place(x=860, y=300, anchor=CENTER)
                lbl_errorage.configure(fg='RED', text = "You need to be above or equal to 19 years old to be a Pro!")
        lbl_status = Label(frame_editprofilep, font=style_texterror)
        lbl_status.place(relx=0.5, rely=0.78, anchor=CENTER)
        lbl_status.configure(fg='RED', text = "*** Please check input")
        return
    # After all requirements fulfilled
    lbl_errorname = Label(frame_editprofilep, font=style_texterror)
    lbl_errorname.place(x=1400, y=135)
    lbl_errorname.configure(fg='RED', text = "                                                ")
    lbl_erroremail = Label(frame_editprofilep, font=style_texterror)
    lbl_erroremail.place(x=1400, y=185)
    lbl_erroremail.configure(fg='RED', text = "                                                          ")
    lbl_errorphone = Label(frame_editprofilep, font=style_texterror)
    lbl_errorphone.place(x=1400, y=235)
    lbl_errorphone.configure(fg='RED', text = "                                                          ")
    lbl_errorage = Label(frame_editprofilep, font=style_texterror)
    lbl_errorage.place(x=1400, y=385, anchor=CENTER)
    lbl_errorage.configure(fg='RED', text = "                                                           ")
    lbl_age = ttkb.Label(frame_editprofilep, text="Age: "+str(pro_age)+"                 " , font=style_button3)
    lbl_age.place(x=300, y=280)
    lbl_status = Label(frame_editprofilep, font=style_texterror)
    lbl_status.place(relx=0.5, rely=0.78, anchor=CENTER)
    lbl_status.configure(fg='RED', text = "                                             ")

    # Get required informations after all correct
    name = entry_name.get()
    email = entry_email.get()
    phone = entry_phone.get()
    bday = datetime.datetime.strftime(pro_bday, "%d/%m/%Y")
    age = str(pro_age)

    # Optional informations if no value then value in txtfile = "na"
    if entry_gender.get() == "":
        gender = "na"
    else:
        gender = entry_gender.get()
    if lbl_biotext.get("1.0", "end-1c") == "":
        bio = "na"
    else:
        bio = lbl_biotext.get("1.0", "end-1c")

    # get field value and 1=y, 0=n
    lit = check_lit.get()
    if lit == 1:
        lit = "y"
    elif lit == 0:
        lit = "n"
    pgrm = check_pgrm.get()
    if pgrm == 1:
        pgrm = "y"
    elif pgrm == 0:
        pgrm = "n"
    multi = check_multi.get()
    if multi == 1:
        multi = "y"
    elif multi == 0:
        multi = "n"
    
    skill_lit1 = entry_litskill1.get()
    skill_lit2 = entry_litskill2.get()
    skill_lit3 = entry_litskill3.get()
    skill_pgrm1 = entry_pgrmskill1.get()
    skill_pgrm2 = entry_pgrmskill2.get()
    skill_pgrm3 = entry_pgrmskill3.get()
    skill_multi1 = entry_multiskill1.get()
    skill_multi2 = entry_multiskill2.get()
    skill_multi3 = entry_multiskill3.get()
    skill1 = f'{skill_lit1},{skill_lit2},{skill_lit3}'
    skill2 = f'{skill_pgrm1},{skill_pgrm2},{skill_pgrm3}'
    skill3 = f'{skill_multi1},{skill_multi2},{skill_multi3}'

    # Update details in txt file 
    id_index = proprofile_list.index(pro_uid)
    proprofile_list[id_index+1] = name
    proprofile_list[id_index+2] = email
    proprofile_list[id_index+3] = phone
    proprofile_list[id_index+4] = gender
    proprofile_list[id_index+5] = age
    proprofile_list[id_index+6] = bday
    proprofile_list[id_index+7] = bio
    proprofile_list[id_index+8] = lit
    proprofile_list[id_index+9] = pgrm
    proprofile_list[id_index+10] = multi
    proprofile_list[id_index+11] = skill1
    proprofile_list[id_index+12] = skill2
    proprofile_list[id_index+13] = skill3
    pro_profile=open("pro_profile.txt", "w")
    pro_profile.write("\n".join(proprofile_list))
    pro_profile.close()

    # Call function to refresh pro profile
    profile_pro()

# Function check in txt file to see chosen field(s) when in completing profile pro, then insert value
def profield_exist():
    global check_lit
    global check_pgrm
    global check_multi

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    entry_litskill1 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_litskill2 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_litskill3 = ttkb.Entry(frame_editprofilep, font=style_text3)

    entry_pgrmskill1 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_pgrmskill2 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_pgrmskill3 = ttkb.Entry(frame_editprofilep, font=style_text3)

    entry_multiskill1 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_multiskill2 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_multiskill3 = ttkb.Entry(frame_editprofilep, font=style_text3)

    if check_lit.get() == 1:
        skill1text = lbl_skill1text.get("1.0", "end-1c")
        skill1_list = skill1text.split(",")
        lit_skill1,lit_skill2,lit_skill3 = skill1_list

        entry_litskill1.place(x=570, y=430, width=300, height=40)
        entry_litskill1.insert(0,lit_skill1)

        entry_litskill2.place(x=920, y=430, width=300, height=40)
        entry_litskill2.insert(0,lit_skill2)

        entry_litskill3.place(x=1270, y=430, width=300, height=40)
        entry_litskill3.insert(0,lit_skill3)

    if check_lit.get() == 0:
        entry_litskill1.place_forget()
        entry_litskill2.place_forget()
        entry_litskill3.place_forget()
        lbl_skill1 = ttkb.Label(frame_editprofilep, text=" -                                                                                                                "
                                , font=style_button3)
        lbl_skill1.place(x=570, y=430)

    if check_pgrm.get() == 1:
        skill2text = lbl_skill2text.get("1.0", "end-1c")
        skill2_list = skill2text.split(",")
        pgrm_skill1,pgrm_skill2,pgrm_skill3 = skill2_list

        entry_pgrmskill1.place(x=630, y=480, width=300, height=40)
        entry_pgrmskill1.insert(0,pgrm_skill1)

        entry_pgrmskill2.place(x=980, y=480, width=300, height=40)
        entry_pgrmskill2.insert(0,pgrm_skill2)

        entry_pgrmskill3.place(x=1330, y=480, width=300, height=40)
        entry_pgrmskill3.insert(0,pgrm_skill3)
    if check_pgrm.get() == 0:
        entry_pgrmskill1.place_forget()
        entry_pgrmskill2.place_forget()
        entry_pgrmskill3.place_forget()
        lbl_skill2 = ttkb.Label(frame_editprofilep, text=" -                                                                                                                "
                                , font=style_button3)
        lbl_skill2.place(x=630, y=480)

    if check_multi.get() == 1:
        skill3text = lbl_skill3text.get("1.0", "end-1c")
        skill3_list = skill3text.split(",")
        multi_skill1,multi_skill2,multi_skill3 = skill3_list

        entry_multiskill1.place(x=590, y=530, width=300, height=40)
        entry_multiskill1.insert(0,multi_skill1)

        entry_multiskill2.place(x=940, y=530, width=300, height=40)
        entry_multiskill2.insert(0,multi_skill2)

        entry_multiskill3.place(x=1290, y=530, width=300, height=40)
        entry_multiskill3.insert(0,multi_skill3)
    if check_multi.get() == 0:
        entry_multiskill1.place_forget()
        entry_multiskill2.place_forget()
        entry_multiskill3.place_forget()
        lbl_skill3 = ttkb.Label(frame_editprofilep, text=" -                                                                                                                "
                                , font=style_button3)
        lbl_skill3.place(x=590, y=530)

# Function pro edit profile
def edit_profilep():
    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    frame_editprofilep.place(x=0, y=0, relheight=1, relwidth=1)
    frame_editprofilep.pack_propagate(False)
    frame_editprofilep.lift()

    lbl_errorname = Label(frame_editprofilep, font=style_texterror)
    lbl_errorname.place(x=1400, y=135)
    lbl_errorname.configure(fg='RED', text = "                                                ")
    lbl_erroremail = Label(frame_editprofilep, font=style_texterror)
    lbl_erroremail.place(x=1400, y=185)
    lbl_erroremail.configure(fg='RED', text = "                                                          ")
    lbl_errorphone = Label(frame_editprofilep, font=style_texterror)
    lbl_errorphone.place(x=1400, y=235)
    lbl_errorphone.configure(fg='RED', text = "                                                          ")
    lbl_errorfield = Label(frame_editprofilep, font=style_texterror)
    lbl_errorfield.place(x=1400, y=385, anchor=CENTER)
    lbl_errorfield.configure(fg='RED', text = "                                                           ")
    lbl_errorage = Label(frame_editprofilep, font=style_texterror)
    lbl_errorage.place(x=1400, y=385, anchor=CENTER)
    lbl_errorage.configure(fg='RED', text = "                                                           ")
    lbl_age = ttkb.Label(frame_editprofilep, text="Age: "+str(pro_age)+"                 " , font=style_button3)
    lbl_age.place(x=300, y=280)
    lbl_status = Label(frame_editprofilep, font=style_texterror)
    lbl_status.place(relx=0.5, rely=0.78, anchor=CENTER)
    lbl_status.configure(fg='RED', text = "                                             ")

    global entry_name
    global entry_email
    global entry_phone
    global entry_gender
    global var_age
    global entry_bday
    global entry_lit
    global entry_pgrm
    global entry_multi

    global lbl_skill1text
    global lbl_skill2text
    global lbl_skill3text
    global lbl_biotext

    global pro_bday

    lbl_profile = ttkb.Label(frame_editprofilep, text="Edit Profile", font=style_title2)
    lbl_profile.place(x=300,y=30)
    lbl_profile.configure()

    lbl_name = ttkb.Label(frame_editprofilep, text="Name: ", font=style_button3)
    lbl_name.place(x=900, y=130)
    lbl_name.config()
    entry_name = ttkb.Entry(frame_editprofilep)
    entry_name.place(x=1050, y=130, width=300, height=40)
    entry_name.configure(font=style_text3)
    entry_name.insert(0,pro_name)

    lbl_email = ttkb.Label(frame_editprofilep, text="Email: ", font=style_button3)
    lbl_email.place(x=900, y=180)
    lbl_email.config()
    entry_email = ttkb.Entry(frame_editprofilep)
    entry_email.place(x=1050, y=180, width=300, height=40)
    entry_email.configure(font=style_text3)
    entry_email.insert(0,pro_email)

    lbl_phone = ttkb.Label(frame_editprofilep, text="Phone: ", font=style_button3)
    lbl_phone.place(x=900, y=230)
    lbl_phone.config()
    entry_phone = ttkb.Entry(frame_editprofilep)
    entry_phone.place(x=1050, y=230, width=300, height=40)
    entry_phone.configure(font=style_text3)
    entry_phone.insert(0,pro_phone)

    lbl_uid = ttkb.Label(frame_editprofilep, text="User ID: "+pro_uid, font=style_button3)
    lbl_uid.place(x=300, y=130)
    lbl_uid.config()

    lbl_gender = ttkb.Label(frame_editprofilep, text="Gender: " , font=style_button3)
    lbl_gender.place(x=300, y=180)
    lbl_gender.config()
    genders = ['Male', 'Female', 'Others', 'Rather not say']
    entry_gender = ttkb.Combobox(frame_editprofilep, bootstyle='dark', values=genders)
    entry_gender.place(x=460, y=180)

    lbl_bday = ttkb.Label(frame_editprofilep, text="Birthday: " , font=style_button3)
    lbl_bday.place(x=300, y=230)
    lbl_bday.config()
    pro_bday = datetime.datetime.strptime(pro_bday, "%d/%m/%Y").date()
    entry_bday = ttkb.DateEntry(frame_editprofilep, bootstyle="dark", dateformat="%d/%m/%Y", startdate=pro_bday)
    entry_bday.place(x=460, y=230)

    lbl_age = ttkb.Label(frame_editprofilep, text="Age: "+pro_age , font=style_button3)
    lbl_age.place(x=300, y=280)
    lbl_age.config()

    sep = ttkb.Separator(frame_editprofilep, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=350, relwidth=0.8, anchor='center')

    lbl_field = ttkb.Label(frame_editprofilep, text="Field(s): ", font=style_button3)
    lbl_field.place(x=300, y=380)
    lbl_field.config()

    global check_lit
    global check_pgrm
    global check_multi

    global entry_litskill1
    global entry_litskill2
    global entry_litskill3
    global entry_pgrmskill1
    global entry_pgrmskill2
    global entry_pgrmskill3
    global entry_multiskill1
    global entry_multiskill2
    global entry_multiskill3

    style_cbtn_startp = ttkb.Style()
    style_cbtn_startp.configure("BtnEditP.dark.TCheckbutton", font=(style_text4))

    entry_lit = ttkb.Checkbutton(frame_editprofilep,
                            text="Literature",
                            style="BtnEditP.dark.TCheckbutton",
                            variable=check_lit,
                            onvalue=1,
                            offvalue=0,
                            width=20,
                            command=profield_exist)
    entry_pgrm = ttkb.Checkbutton(frame_editprofilep,
                             text="Programming",
                             style="BtnEditP.dark.TCheckbutton",
                             variable=check_pgrm,
                             onvalue=1,
                             offvalue=0,
                            width=20,
                            command=profield_exist)
    entry_multi = ttkb.Checkbutton(frame_editprofilep,
                              text="Multimedia",
                              style="BtnEditP.dark.TCheckbutton",
                              onvalue=1,
                              offvalue=0,
                              variable=check_multi,
                            width=20,
                            command=profield_exist)

    entry_lit.place(x=500, y=380)
    entry_pgrm.place(x=730, y=380)
    entry_multi.place(x=1000, y=380)

    entry_litskill1 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_litskill2 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_litskill3 = ttkb.Entry(frame_editprofilep, font=style_text3)

    entry_pgrmskill1 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_pgrmskill2 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_pgrmskill3 = ttkb.Entry(frame_editprofilep, font=style_text3)

    entry_multiskill1 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_multiskill2 = ttkb.Entry(frame_editprofilep, font=style_text3)
    entry_multiskill3 = ttkb.Entry(frame_editprofilep, font=style_text3)

    if check_lit.get() == 1:
        skill1text = lbl_skill1text.get("1.0", "end-1c")
        skill1_list = skill1text.split(",")
        lit_skill1,lit_skill2,lit_skill3 = skill1_list

        entry_litskill1.place(x=570, y=430, width=300, height=40)
        entry_litskill1.insert(0,lit_skill1)

        entry_litskill2.place(x=920, y=430, width=300, height=40)
        entry_litskill2.insert(0,lit_skill2)

        entry_litskill3.place(x=1270, y=430, width=300, height=40)
        entry_litskill3.insert(0,lit_skill3)

    if check_lit.get() == 0:
        entry_litskill1.place_forget()
        entry_litskill2.place_forget()
        entry_litskill3.place_forget()
        lbl_skill1 = ttkb.Label(frame_editprofilep, text=" -                                                                                                                "
                                , font=style_button3)
        lbl_skill1.place(x=570, y=430)

    if check_pgrm.get() == 1:
        skill2text = lbl_skill2text.get("1.0", "end-1c")
        skill2_list = skill2text.split(",")
        pgrm_skill1,pgrm_skill2,pgrm_skill3 = skill2_list

        entry_pgrmskill1.place(x=630, y=480, width=300, height=40)
        entry_pgrmskill1.insert(0,pgrm_skill1)

        entry_pgrmskill2.place(x=980, y=480, width=300, height=40)
        entry_pgrmskill2.insert(0,pgrm_skill2)

        entry_pgrmskill3.place(x=1330, y=480, width=300, height=40)
        entry_pgrmskill3.insert(0,pgrm_skill3)
    if check_pgrm.get() == 0:
        entry_pgrmskill1.place_forget()
        entry_pgrmskill2.place_forget()
        entry_pgrmskill3.place_forget()
        lbl_skill2 = ttkb.Label(frame_editprofilep, text=" -                                                                                                                "
                                , font=style_button3)
        lbl_skill2.place(x=630, y=480)

    if check_multi.get() == 1:
        skill3text = lbl_skill3text.get("1.0", "end-1c")
        skill3_list = skill3text.split(",")
        multi_skill1,multi_skill2,multi_skill3 = skill3_list

        entry_multiskill1.place(x=590, y=530, width=300, height=40)
        entry_multiskill1.insert(0,multi_skill1)

        entry_multiskill2.place(x=940, y=530, width=300, height=40)
        entry_multiskill2.insert(0,multi_skill2)

        entry_multiskill3.place(x=1290, y=530, width=300, height=40)
        entry_multiskill3.insert(0,multi_skill3)
    if check_multi.get() == 0:
        entry_multiskill1.place_forget()
        entry_multiskill2.place_forget()
        entry_multiskill3.place_forget()
        lbl_skill3 = ttkb.Label(frame_editprofilep, text=" -                                                                                                                "
                                , font=style_button3)
        lbl_skill3.place(x=590, y=530)

    lbl_skill1 = ttkb.Label(frame_editprofilep, text="Literature Skills: ", font=style_button3)
    lbl_skill1.place(x=300, y=430)
    lbl_skill1.config()

    lbl_skill2 = ttkb.Label(frame_editprofilep, text="Programming Skills: ", font=style_button3)
    lbl_skill2.place(x=300, y=480)
    lbl_skill2.config()

    lbl_skill3 = ttkb.Label(frame_editprofilep, text="Multimedia Skills: ", font=style_button3)
    lbl_skill3.place(x=300, y=530)
    lbl_skill3.config()

    lbl_bio = ttkb.Label(frame_editprofilep, text="Bio: ", font=style_button3)
    lbl_bio.place(x=300, y=580)
    lbl_bio.config()
    lbl_biotext = Text(frame_editprofilep, wrap="word", relief="sunken", bd=2, width=50, height=5, borderwidth=0, bg="#d0d6d6", font=style_button3)
    lbl_biotext.place(x=400, y=580, width=1200, height=150)
    lbl_biotext.insert("end", pro_bio)
    lbl_biotext.configure()

    style_btn_editp = ttkb.Style()
    style_btn_editp.configure("BtnEditP.dark.TButton", font=('Helvetica',20,'bold'))

    btn_check_profile = ttkb.Button(frame_editprofilep, text="Save Changes", width=20, style="BtnEditP.dark.TButton", takefocus=False, command=check_profilep)
    btn_check_profile.place(relx=0.5, rely=0.85, anchor=CENTER, height=80)

    style_btn_editp.configure("BtnCancelP.dark.Outline.TButton", font=('Helvetica',15,'bold'))
    btn_cancel = ttkb.Button(frame_editprofilep, text="Cancel", width=15, style="BtnCancelP.dark.Outline.TButton", takefocus=False, command=cancel_profilep)
    btn_cancel.place(relx=0.1, rely=0.85, anchor=CENTER, height=80)

# Function pro profile
def profile_pro():

    frame_profilep.place(x=0, y=0, relheight=1, relwidth=1)
    frame_profilep.pack_propagate(False)
    frame_profilep.lift()

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    global pro_uid
    global pro_name
    global pro_email
    global pro_phone
    global pro_gender
    global pro_age
    global pro_bday
    global pro_bio
    global pro_skill1
    global pro_skill2
    global pro_skill3
    global pro_fields
    global pro_lit
    global pro_pgrm
    global pro_multi

    global lbl_skill1text
    global lbl_skill2text
    global lbl_skill3text

    pro_uid = entry_id.get()
    pro_uid_index = proprofile_list.index(pro_uid)

    pro_name = proprofile_list[pro_uid_index+1]
    pro_email = proprofile_list[pro_uid_index+2]
    pro_phone = proprofile_list[pro_uid_index+3]
    if pro_phone == "na":
        pro_phone = " -                          "
    pro_gender = proprofile_list[pro_uid_index+4]
    if pro_gender == "na":
        pro_gender = " -                     "
    pro_age = proprofile_list[pro_uid_index+5]
    if pro_age == "na":
        pro_age = " -                        "
    pro_bday = proprofile_list[pro_uid_index+6]
    if pro_bday == "na":
        pro_bday = " -                       "
    pro_bio = proprofile_list[pro_uid_index+7]
    if pro_bio == "na":
        pro_bio = " - "
    pro_skill1 = proprofile_list[pro_uid_index+11]
    if pro_skill1 == "na, na, na":
        pro_skill1 = " - "
    pro_skill2 = proprofile_list[pro_uid_index+12]
    if pro_skill2 == "na, na, na":
        pro_skill2 = " - "
    pro_skill3 = proprofile_list[pro_uid_index+13]
    if pro_skill3 == "na, na, na":
        pro_skill3 = " - "
    pro_lit = proprofile_list[pro_uid_index+8]
    pro_pgrm = proprofile_list[pro_uid_index+9]
    pro_multi = proprofile_list[pro_uid_index+10]

    global check_lit
    global check_pgrm
    global check_multi

    check_lit = IntVar()
    check_pgrm = IntVar()
    check_multi = IntVar()

    field = []
    if pro_lit == "y":
        field.append("Literature")
        check_lit.set(1)
    elif pro_lit == "n":
        pro_skill1 = "- , - , - "
        check_lit.set(0)
    if pro_pgrm == "y":
        field.append("Programming")
        check_pgrm.set(1)
    elif pro_pgrm == "n":
        pro_skill2 = "- , - , - "
        check_pgrm.set(0)
    if pro_multi == "y":
        field.append("Multimedia")
        check_multi.set(1)
    elif pro_multi == "n":
        pro_skill3 = " - , - , - "
        check_multi.set(0)

    pro_fields = ', '.join(field)

    lbl_profile = ttkb.Label(frame_profilep, text="My Profile", font=style_title2)
    lbl_profile.place(x=300,y=30)
    lbl_profile.configure()

    lbl_name = ttkb.Label(frame_profilep, text="Name: " + pro_name, font=style_button3)
    lbl_name.place(x=900, y=130)
    lbl_name.config()
    lbl_email = ttkb.Label(frame_profilep, text="Email: " + pro_email, font=style_button3)
    lbl_email.place(x=900, y=180)
    lbl_email.config()
    lbl_phone = ttkb.Label(frame_profilep, text="Phone: " + pro_phone, font=style_button3)
    lbl_phone.place(x=900, y=230)
    lbl_phone.config()

    lbl_uid = ttkb.Label(frame_profilep, text="User ID: " + pro_uid, font=style_button3)
    lbl_uid.place(x=300, y=130)
    lbl_uid.config()
    lbl_gender = ttkb.Label(frame_profilep, text="Gender: " + pro_gender, font=style_button3)
    lbl_gender.place(x=300, y=180)
    lbl_gender.config()

    lbl_bday = ttkb.Label(frame_profilep, text="Birthday: " + pro_bday, font=style_button3)
    lbl_bday.place(x=300, y=230)
    lbl_bday.config()
    lbl_age = ttkb.Label(frame_profilep, text="Age: " + pro_age+"              ", font=style_button3)
    lbl_age.place(x=300, y=280)
    lbl_age.config()

    sep = ttkb.Separator(frame_profilep, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=350, relwidth=0.8, anchor='center')

    lbl_field = ttkb.Label(frame_profilep, text="Field(s): " + pro_fields, font=style_button3)
    lbl_field.place(x=300, y=380)
    lbl_field.config()

    lbl_skill1 = ttkb.Label(frame_profilep, text="Literature Skills: ", font=style_button3)
    lbl_skill1.place(x=300, y=430)
    lbl_skill1.config()
    lbl_skill1text = Text(frame_profilep, wrap="word", relief="sunken", bd=2, width=60, borderwidth=0, bg="#d0d6d6", font=style_button3)
    lbl_skill1text.place(x=570, y=430)
    lbl_skill1text.insert("end", pro_skill1)
    lbl_skill1text.configure(highlightthickness=0, state=DISABLED)

    lbl_skill2 = ttkb.Label(frame_profilep, text="Programming Skills: ", font=style_button3)
    lbl_skill2.place(x=300, y=480)
    lbl_skill2.config()
    lbl_skill2text = Text(frame_profilep, wrap="word", relief="sunken", bd=2, width=60, borderwidth=0, bg="#d0d6d6", font=style_button3)
    lbl_skill2text.place(x=630, y=480)
    lbl_skill2text.insert("end", pro_skill2)
    lbl_skill2text.configure(highlightthickness=0, state=DISABLED)

    lbl_skill3 = ttkb.Label(frame_profilep, text="Multimedia Skills: ", font=style_button3)
    lbl_skill3.place(x=300, y=530)
    lbl_skill3.config()
    lbl_skill3text = Text(frame_profilep, wrap="word", relief="sunken", bd=2, width=60, borderwidth=0, bg="#d0d6d6", font=style_button3)
    lbl_skill3text.place(x=590, y=530)
    lbl_skill3text.insert("end", pro_skill3)
    lbl_skill3text.configure(highlightthickness=0, state=DISABLED)

    lbl_bio = ttkb.Label(frame_profilep, text="Bio: ", font=style_button3)
    lbl_bio.place(x=300, y=580)
    lbl_bio.config()
    lbl_biotext = Text(frame_profilep, wrap="word", relief="sunken", bd=2, width=50, borderwidth=0, bg="#d0d6d6", font=style_button3)
    lbl_biotext.place(x=400, y=580)
    lbl_biotext.insert("end", pro_bio)
    lbl_biotext.configure(highlightthickness=0, state=DISABLED)

    style_btn_edit = ttkb.Style()
    style_btn_edit.configure("BtnEdit.dark.TButton", font=('Helvetica',20,'bold'))
    btn_edit_profile = ttkb.Button(frame_profilep, text="Edit Profile", width=25, style="BtnEdit.dark.TButton", takefocus=False, command=edit_profilep)
    btn_edit_profile.place(relx=0.5, rely=0.85, anchor=CENTER, height=80)

# ----- Logout Pro -----

# Function logout confirm pro
def logout_okp():
    homepagep.select(0)
    main()

# Function logout cancel pro
def logout_cancelp():
    homepagep.select(0)

frame_logoutp.place(relx=0.5, rely=0.4, anchor=CENTER)
frame_logoutp.pack_propagate(False)
frame_logoutp.configure(padx=20, pady=20, highlightbackground="black", highlightthickness=4)
frame_logoutp.lift()

lbl_bio = ttkb.Label(frame_logoutp, text="Are you sure to logout from your account?", font=style_button3)
lbl_bio.grid(row=0, column=0, columnspan=2)

btn_ok = Button(frame_logoutp, text="OK", width=15, height=3, font=style_button1, takefocus=False,command=logout_okp)
btn_ok.grid(row=1, column=0)

btn_cancel = Button(frame_logoutp, text="Cancel", width=15, height=3, font=style_button1, takefocus=False,command=logout_cancelp)
btn_cancel.grid(row=1, column=1)

# ----- Show Frame Pro -----

# Function show first page in every tab when clicked
def show_framep(pro_tab_clicked):
    current_tab = pro_tab_clicked.widget.tab('current')['text']
    if current_tab == "Home":
        frame_homep.lift()
    elif current_tab == "Profile":
        frame_editprofilep.place_forget()
        frame_profilep.lift()
    elif current_tab == "History":
        frame_historyp.lift()

# Bind function to left click button of mouse
homepagep.bind("<Button-1>", show_framep)

# -------------------- Creating Client Menu --------------------

# homepagec style
style_homepagec = Style(theme='cosmo')

style_homepagec.configure('TNotebook.Tab', font=('Helvetica', 20), padding=(20, 10))

# Create homepagec
homepagec = ttkb.Notebook(root, style='TNotebook')
homepagec.place(x=0, y=0, relheight=1, relwidth=1)

# Frame Home Client
frame_parent_homec = ttkb.Frame(homepagec)
frame_homec = Frame(frame_parent_homec)

frame_search = Frame(frame_parent_homec)
frame_searchpro = Frame(frame_search)
frame_nopro = Frame(frame_search)

# Manage Account Client
frame_accountc = Frame(frame_parent_homec)
frame_edit_accountc = Frame(frame_parent_homec)

frame_enterpwdc = Frame(frame_parent_homec)

frame_newpwd_client = Frame(frame_parent_homec)
frame_pwdupdatedc = Frame(frame_parent_homec)

frame_dltacc_client = Frame(frame_parent_homec)
frame_accdltedc = Frame(frame_parent_homec)

# Frame Browse
frame_browse = ttkb.Frame(homepagec)

frame_filter = Frame(frame_browse)
frame_profile = Frame(frame_browse)
frame_proprofile = Frame(frame_profile)

# Frame Membership Client
frame_parent_membershipc = ttkb.Frame(homepagec)
frame_base_membershipc = Frame(frame_parent_membershipc)
frame_membershipc = ttkb.LabelFrame(frame_base_membershipc)

frame_jointsp = Frame(frame_parent_membershipc)
frame_tspcomplete = Frame(frame_parent_membershipc)
frame_tspstatus = Frame(frame_parent_membershipc)
frame_base_cancelconfirm = Frame(frame_parent_membershipc)
frame_cancelconfirm = Frame(frame_base_cancelconfirm)
frame_tysupport = Frame(frame_parent_membershipc)

# Frame Profile Client
frame_parent_profilec = ttkb.Frame(homepagec)
frame_profilec = Frame(frame_parent_profilec)
frame_editprofilec = Frame(frame_parent_profilec)

# My Order Client
frame_parent_orderc = ttkb.Frame(homepagec)
frame_noorderc = Frame(frame_parent_orderc)
frame_orderc = Frame(frame_parent_orderc)
frame_report_problem = Frame(frame_parent_orderc)

frame_hoursc = Frame(frame_parent_orderc)
frame_paymentc = Frame(frame_parent_orderc)

frame_paymentsuccessc = Frame(frame_parent_orderc)
frame_ratingc = Frame(frame_parent_orderc)
frame_completec = Frame(frame_parent_orderc)

# Frame History Client
frame_parent_historyc = ttkb.Frame(homepagec)
frame_historyc = Frame(frame_parent_historyc)

# Frame Logout Client
frame_parent_logoutc = ttkb.Frame(homepagec)
frame_logoutc = Frame(frame_parent_logoutc)

# Frame Payment Client
frame_choosepayment = Frame(root)

# Add Tabs to homepagec
homepagec.add(frame_parent_homec, text='Home')
homepagec.add(frame_browse, text='Browse')
homepagec.add(frame_parent_membershipc, text='Task Striker Premium')
homepagec.add(frame_parent_profilec, text='Profile')
homepagec.add(frame_parent_orderc, text='My Order')
homepagec.add(frame_parent_historyc, text='History')
homepagec.add(frame_parent_logoutc, text='Logout')

# ---------- HOME Client ----------

# Function back to home page after search
def back_wlcbackc():
    global entry_searchc
    global entryc
    entryc = entry_searchc.delete(0, END)
    frame_search.place_forget()
    frame_proprofile.place_forget()
    frame_homec.lift()

# Function open google form link for platform feedback
def feedbackc():
    webbrowser.open("https://forms.gle/1DrYyFh2sMXrwv6j9")

# Function show tsp details after clicking tsp banner
def show_membershipc():
    homepagec.select(2)

# Function search pro
def searchc(enter_entry_search):
    global entry_searchc
    global entryc

    style_btn_search = ttkb.Style()

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")
    # If entry not empty then proceed, else remain
    if entry_searchc.get() != "":
        frame_search.place(x=0, y=0, relheight=1, relwidth=1)
        frame_search.lift()

        entryc = entry_searchc.get()
        # if pro exist, show pro profile, else show no exist
        if entryc in proprofile_list:
            global uid
            global id_index
            global name
            global gender
            global bday
            global age
            global bio
            global skills
            uid = entryc
            id_index = proprofile_list.index(uid)
            name = proprofile_list[id_index+1]
            gender = proprofile_list[id_index+4]
            bday = proprofile_list[id_index+5]
            age = proprofile_list[id_index+6]
            bio = proprofile_list[id_index+7]
            skills = "Literature:  "+proprofile_list[id_index+11]+"\n"+"Programming:  "+proprofile_list[id_index+12]+"\n"+"Multimedia:  "+proprofile_list[id_index+13]
            
            frame_searchpro.place(relx=0.5, rely=0.4, anchor=CENTER)
            frame_searchpro.pack_propagate(False)
            frame_searchpro.configure(width=1400, height=700, highlightbackground="black", highlightthickness=1)
            frame_searchpro.lift()

            lbl_uid = Label(frame_searchpro, text ="User ID:  "+uid+"                          ", font=style_button3)
            lbl_uid.place(x=30, y=30)
            lbl_name = Label(frame_searchpro, text ="Name:  "+name+"                               ", font=style_button3)
            lbl_name.place(x=30, y=80)
            lbl_gender = Label(frame_searchpro, text ="Gender:  "+gender+"                               ", font=style_button3)
            lbl_gender.place(x=30, y=130)
            lbl_age = Label(frame_searchpro, text ="Age:  "+age+"                               ", font=style_button3)
            lbl_age.place(x=30, y=180)
            lbl_bday = Label(frame_searchpro, text ="Birthday:  "+bday+"                               ", font=style_button3)
            lbl_bday.place(x=30, y=230)

            sep = ttkb.Separator(frame_searchpro, bootstyle="default", orient="horizontal")
            sep.place(relx=0.5, y=290, relwidth=0.95, anchor=CENTER)

            lbl_skill = Label(frame_searchpro, text ="Skills: ", bg="#d0d6d6", font=style_button3)
            lbl_skill.place(x=30, y=300)

            lbl_skilltext = Text(frame_searchpro, wrap="word", relief="flat", width=50, font=style_button3)
            lbl_skilltext.place(x=130, y=300, width=1000, height=300)
            lbl_skilltext.insert("end", skills)
            lbl_skilltext.configure(highlightthickness=0, state=DISABLED)

            lbl_bio = Label(frame_searchpro, text ="Bio: ", font=style_button3)
            lbl_bio.place(x=30, y=520)

            lbl_biotext = Text(frame_searchpro, wrap="word", relief="sunken", width=50, font=style_button3)
            lbl_biotext.place(x=130, y=520, width=1250, height=170)
            lbl_biotext.insert("end", bio)
            lbl_biotext.configure(highlightthickness=0, state=DISABLED)
        else:
            frame_nopro.place(relx=0.5, rely=0.4, anchor=CENTER, width=1400, height=700)
            frame_nopro.pack_propagate(False)
            frame_nopro.lift()

            lbl_empty = Label(frame_nopro, font=style_title2)
            lbl_empty.place(relx=0.5, rely=0.5, anchor=CENTER)
            lbl_empty.configure(text="User does not exist :(")
        style_btn_search.configure("BtnBackS.dark.Outline.TButton", font=("Helvetica",15,"bold"))
        btn_back = ttkb.Button(frame_search, text="Back", width=15, style="BtnBackS.dark.Outline.TButton", takefocus=False, command=back_wlcbackc)
        btn_back.place(x=100, y=800, height=80)

# Function pwd updated
def pwd_updatedc():
    frame_pwdupdatedc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_pwdupdatedc.lift()

    lbl_success = ttkb.Label(frame_pwdupdatedc, text="Password Updated", font=style_title2)
    lbl_success.place(x=200,y=30)
    lbl_welcome = ttkb.Label(frame_pwdupdatedc, text="Password Successfully Updated ! ", font=style_title3)
    lbl_welcome.place(relx=0.5, rely=0.3, anchor=CENTER)

    style_btn_pwdupdatedc = ttkb.Style()
    style_btn_pwdupdatedc.configure("BtnBack.dark.Outline.TButton", font=("Helvetica",20,"bold"), padding=(50, 30))
    btn_confirm = ttkb.Button(frame_pwdupdatedc, text="Back to Home", width=20, style="BtnBack.dark.Outline.TButton", takefocus=False, command=lambda: frame_homec.lift())
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER)
# Function check new pwd
def check_newpwd_client():

    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")
    # Check new pwd empty, <8 characters, newpwd confirmation until fulfill all requirements
    if entry_newpwdc.get() == "":
        entry_newpwdc.delete(0, END)
        entry_newpwdconfirmc.delete(0, END)
        lbl_error = Label(frame_newpwd_client, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(text="                  Please enter a password !               ", fg="RED")
    else:
        if len(entry_newpwdc.get()) <8:
            entry_newpwdc.delete(0, END)
            entry_newpwdconfirmc.delete(0, END)
            lbl_error = Label(frame_newpwd_client, font=style_text3)
            lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
            lbl_error.configure(text="                  Password must be 8 characters or more !                 ", fg="RED")
        else:
            if entry_newpwdc.get() != entry_newpwdconfirmc.get():
                entry_newpwdc.delete(0, END)
                entry_newpwdconfirmc.delete(0, END)
                lbl_error = Label(frame_newpwd_client, font=style_text3)
                lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
                lbl_error.configure(text="                  Password Confirmation failed! Please try again.                 ", fg="RED")
            else:
                # If all requirements fulfilled, update new pwd in client list txt file
                lbl_error = Label(frame_newpwd_client, font=style_text3)
                lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
                lbl_error.configure(text="                                                                             ")
                newpwdc = entry_newpwdc.get()
                id_index = clientlist.index(client_uid)
                clientlist[id_index+2] = newpwdc
                file_client=open("clientlist.txt", "w")
                file_client.write("\n".join(clientlist))
                file_client.close()
                pwd_updatedc()

# Function client enter new pwd
def newpwd_client():
    frame_newpwd_client.place(x=0, y=0, relheight=1, relwidth=1)
    frame_newpwd_client.lift()

    lbl_profile = ttkb.Label(frame_newpwd_client, text="Change Password", font=style_title2)
    lbl_profile.place(x=300, y=30)

    lbl_enterpwd = ttkb.Label(frame_newpwd_client, text="Please enter new password: ", font=style_title1)
    lbl_enterpwd.place(relx=0.08, rely=0.3)
    lbl_enterpwdconfirm = ttkb.Label(frame_newpwd_client, text="Please enter password confirmation: ", font=style_title1)
    lbl_enterpwdconfirm.place(relx=0.08, rely=0.4)

    global entry_newpwdc
    entry_newpwdc = Entry(frame_newpwd_client)
    entry_newpwdc.place(relx=0.55, rely=0.3, width=600, height=80)
    entry_newpwdc.configure(font=style_title1, show="*")

    global entry_newpwdconfirmc
    entry_newpwdconfirmc = Entry(frame_newpwd_client)
    entry_newpwdconfirmc.place(relx=0.55, rely=0.4, width=600, height=80)
    entry_newpwdconfirmc.configure(font=style_title1, show="*")

    style_btn_enternewpwdc = ttkb.Style()
    style_btn_enternewpwdc.configure("BtnConfirm.dark.Outline.TButton", font=("Helvetica",20,"bold"), padding=(50, 30))
    btn_confirm = ttkb.Button(frame_newpwd_client, text="Confirm", width=20, style="BtnConfirm.dark.Outline.TButton", takefocus=False, command=check_newpwd_client)
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER)

# Function check client pwd
def check_pwd_client():
    # if pwd entered matched with current pwd, call function enter new pwd
    if entry_pwdc.get() == client_pwd:
        lbl_error = Label(frame_enterpwdc, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(text="                                                    ")
        newpwd_client()
    # if pwd entered wrong, prompt user to enter again
    else:
        entry_pwdc.delete(0, END)
        lbl_error = Label(frame_enterpwdc, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.75, anchor=CENTER)
        lbl_error.configure(text="Password Incorrect !", fg="RED")

# Function client change acc pwd
def change_pwd_client():
    frame_enterpwdc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_enterpwdc.lift()

    lbl_enterpwd = ttkb.Label(frame_enterpwdc, text="Please enter password: ", font=style_title1)
    lbl_enterpwd.place(relx=0.3, rely=0.3, anchor=CENTER)

    global entry_pwdc
    entry_pwdc = Entry(frame_enterpwdc)
    entry_pwdc.place(relx=0.6, rely=0.3, anchor=CENTER, width=600, height=80)
    entry_pwdc.configure(font=style_title1, show="*")

    style_btn_enterpwdc = ttkb.Style()
    style_btn_enterpwdc.configure("BtnConfirm.dark.Outline.TButton", font=("Helvetica",20,"bold"), padding=(50, 30))
    btn_confirm = ttkb.Button(frame_enterpwdc, text="Confirm", width=20, style="BtnConfirm.dark.Outline.TButton", takefocus=False, command=check_pwd_client)
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER)

# Function show client ts acc
def show_accountc():
    frame_accountc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_accountc.lift()

    lbl_account= ttkb.Label(frame_accountc, text="Manage Account", font=style_title2)
    lbl_account.place(x=300, y=30)

    lbl_uid = ttkb.Label(frame_accountc, text="User ID: " + client_uid, font=style_title1)
    lbl_uid.place(relx=0.5, rely=0.3, anchor=CENTER)

    style_btn_accountc = ttkb.Style()
    style_btn_accountc.configure("BtnAccountC.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    btn_pwd = ttkb.Button(frame_accountc, text="Change Password", width=20,  style="BtnAccountC.dark.Outline.TButton", takefocus=False, command=change_pwd_client)
    btn_pwd.place(relx=0.5, rely=0.5, height=120, anchor=CENTER)

    style_btn_accountc.configure("BtnBack.dark.Outline.TButton", font=("Helvetica",15,"bold"))
    btn_back = ttkb.Button(frame_accountc, text="Back", width=15, style="BtnBack.dark.Outline.TButton", takefocus=False, command=lambda: frame_homec.lift())
    btn_back.place(relx=0.15, rely=0.85, height=100, anchor=CENTER)

# Frame Home Client

def home_loginc():
    frame_homec.place(x=0, y=0, relheight=1, relwidth=1)

    global entry_searchc
    global client_name
    global icon_profile
    global icon_search
    global banner_membership

    sep = ttkb.Separator(frame_homec, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=90, relwidth=1, anchor='center')

    lbl_wlcb1 = ttkb.Label(frame_homec, text="Hi, "+ client_name, font=style_title4)
    lbl_wlcb1.place(x=100, y=120)

    lbl_wlcb2 = ttkb.Label(frame_homec, text="It's nice to see you here. Hope you found your desire Pro!", font=style_title1)
    lbl_wlcb2.place(x=100, y=280)

    lbl_search = ttkb.Label(frame_homec, text="Search Pros by their User ID", font=style_button2)
    lbl_search.place(x=1065, y=30)

    entry_searchc = Entry(frame_homec)
    entry_searchc.place(x=1420, y=20, width=250, height=50)
    entry_searchc.configure(font=style_text3)
    entry_searchc.bind("<Return>", searchc)

    icon_search = 'C:\VSCode\sem3 project\search.png'
    icon_search = PhotoImage(file='C:\VSCode\sem3 project\search.png')
    btn_searchc = ttkb.Button(frame_homec, image=icon_search, bootstyle="light",  takefocus=False,command=searchc)
    btn_searchc.place(x=1680, y=23)
    btn_searchc.bind("<Button-1>", searchc)

    icon_profile = 'C:\VSCode\sem3 project\iconprofile.png'
    icon_profile = PhotoImage(file='C:\VSCode\sem3 project\iconprofile.png')
    btn_profilec = ttkb.Button(frame_homec, image=icon_profile, bootstyle="light",  takefocus=False,command=show_accountc)
    btn_profilec.place(x=1770, y=20)

    sep2 = ttkb.Separator(frame_homec, bootstyle="default", orient="horizontal")
    sep2.place(relx=0.49, y=600, relwidth=1, anchor='center')

    banner_membership= 'C:\VSCode\sem3 project\membership.png'
    banner_membership = PhotoImage(file='C:\VSCode\sem3 project\membership.png')
    btn_membership = ttkb.Button(frame_homec, image=banner_membership, bootstyle="light", takefocus=False, command=show_membershipc)
    btn_membership.place(relx=0.3, y=650)

    style_btnfeedback = ttkb.Style()
    style_btnfeedback.configure("BtnFeedback.primary.TButton", font=('Helvetica',15), padding=(50, 24))

    btn_feedback = ttkb.Button(frame_homec, text="Give us a feedback!", style="BtnFeedback.primary.TButton", takefocus=False, command=feedbackc)
    btn_feedback.place(relx=0.05, y=820)
    # Call function to check tsp subscribed or not
    check_tspexist()

# ---------- Payment ----------

# Function check payment chosen
def check_acclink():
    # if payment chosen, check whether is task or tsp payment then proceed with respective function
    if account_link.get():
        lbl_error = Label(frame_choosepayment, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.77, anchor=CENTER)
        lbl_error.configure(text="                                                    ")
        global function_from
        if function_from == "tsp_payment":
            tsp_complete()
        if function_from == "task_payment":
            payment_successful()
    # If no payment chosen, prompt user to choose again
    else:
        lbl_error = Label(frame_choosepayment, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.77, anchor=CENTER)
        lbl_error.configure(text="Please choose a payment option!", fg="RED")

# Function choose way of payment
def choose_paymentc():
    frame_choosepayment.place(x=0, y=0, relheight=1, relwidth=1)
    frame_choosepayment.lift()

    lbl_choose = ttkb.Label(frame_choosepayment, text="Choose Payment", font=style_title2)
    lbl_choose.place(x=200,y=30)

    lbl_info = ttkb.Label(frame_choosepayment, text="Please choose a payment option:", font=style_text5)
    lbl_info.place(x=200, y=140)

    lbl_bank = ttkb.Label(frame_choosepayment, text="Online Banking", font=style_title1)
    lbl_bank.place(x=200, y=250)

    style_btn_chooselink = ttkb.Style()
    style_btn_chooselink.configure("BtnCL.dark.Outline.TButton", font=("Helvetica",15,"bold"))

    global account_link
    account_link = StringVar()
    # Options for client to choose whether to pay using bank acc or e-wallet
    style_btn_chooselink.configure("BtnCIMB.danger.Outline.Toolbutton", font=("Helvetica",18,"bold"))
    rbtn_cimb = ttkb.Radiobutton(frame_choosepayment, text="CIMB Bank",
                                 style="BtnCIMB.danger.Outline.Toolbutton", 
                                 variable=account_link, 
                                 value = "CIMB Bank",
                                 takefocus=False
                                )
    rbtn_cimb.place(x=200, y=330, width=300, height=80)

    style_btn_chooselink.configure("BtnMay.warning.Outline.Toolbutton", font=("Helvetica",18,"bold"))
    rbtn_maybank = ttkb.Radiobutton(frame_choosepayment, text="Maybank",
                                 style="BtnMay.warning.Outline.Toolbutton", 
                                 variable=account_link, 
                                 value = "Maybank",
                                 takefocus=False
                                )
    rbtn_maybank.place(x=600, y=330, width=300, height=80)

    style_btn_chooselink.configure("BtnPublic.danger.Outline.Toolbutton", font=("Helvetica",18,"bold"))
    rbtn_public = ttkb.Radiobutton(frame_choosepayment, text="Public Bank",
                                 style="BtnPublic.danger.Outline.Toolbutton", 
                                 variable=account_link, 
                                 value = "Public Bank",
                                 takefocus=False
                                )
    rbtn_public.place(x=1000, y=330, width=300, height=80)


    lbl_or = ttkb.Label(frame_choosepayment, text="OR", font=style_title1)
    lbl_or.place(x=720, y=450)

    lbl_ewallet = ttkb.Label(frame_choosepayment, text="E-wallet", font=style_title1)
    lbl_ewallet.place(x=200, y=520)

    style_btn_chooselink.configure("BtnTnG.primary.Outline.Toolbutton", font=("Helvetica",18,"bold"))
    rbtn_tng = ttkb.Radiobutton(frame_choosepayment, text="TnG (Touch n Go)",
                                 style="BtnTnG.primary.Outline.Toolbutton", 
                                 variable=account_link, 
                                 value = "Touch n Go",
                                 takefocus=False
                                )
    rbtn_tng.place(x=200, y=600, width=300, height=80)

    style_btn_chooselink.configure("BtnBoost.danger.Outline.Toolbutton", font=("Helvetica",18,"bold"))
    rbtn_boost = ttkb.Radiobutton(frame_choosepayment, text="Boost",
                                 style="BtnBoost.danger.Outline.Toolbutton", 
                                 variable=account_link, 
                                 value = "Boost",
                                 takefocus=False
                                )
    rbtn_boost.place(x=600, y=600, width=300, height=80)

    style_btn_chooselink.configure("BtnGrab.success.Outline.Toolbutton", font=("Helvetica",18,"bold"))
    rbtn_grabpay = ttkb.Radiobutton(frame_choosepayment, text="GrabPay",
                                 style="BtnGrab.success.Outline.Toolbutton", 
                                 variable=account_link, 
                                 value = "GrabPay",
                                 takefocus=False
                                )
    rbtn_grabpay.place(x=1000, y=600, width=300, height=80)

    style_btn_chooselink.configure("BtnConfirm.success.TButton", font=("Helvetica",20,"bold"), padding=(50, 30))
    btn_confirm = ttkb.Button(frame_choosepayment, text="Confirm", width=20, style="BtnConfirm.success.TButton", takefocus=False, command=check_acclink)
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER)

# ---------- Membership Client ----------

# Function back home page after cancelled tsp
def backhome_canceltsp():
    # Call function to show again tsp details
    membershipc()
    lbl_nojoin = ttkb.Label(frame_base_membershipc, text="                                ", font=style_button2)
    lbl_nojoin.place(relx=0.05, y=800, width=400, height=700)

    # show ad banner again
    btn_membership = ttkb.Button(frame_homec, image=banner_membership, bootstyle="light", takefocus=False, command=show_membershipc)
    btn_membership.place(relx=0.3, y=650)
    homepagec.select(0)

# Function cancel tsp
def cancel_tsp():
    frame_tspstatus.place_forget()
    frame_tysupport.place(x=0, y=0, relheight=1, relwidth=1)
    frame_tysupport.lift()

    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    # Update txt file tsp status to unsubscribed
    id_index = clientlist.index(client_uid)
    clientlist[id_index+3] = "n"
    clientlist[id_index+4] = "d/m/y"

    file_client=open("clientlist.txt", "w")
    file_client.write("\n".join(clientlist))
    file_client.close()

    lbl_confirm = ttkb.Label(frame_tysupport, text="Task Striker Premium Cancelled Successful", font=style_title2)
    lbl_confirm.place(x=300, y=30)

    lbl_tq = ttkb.Label(frame_tysupport, text="Thank You for Your Support ", font=style_title3)
    lbl_tq.place(relx=0.5, rely=0.3, anchor=CENTER)
    lbl_hope = ttkb.Label(frame_tysupport, text="Hope to see you again in the future ~", font=style_title1)
    lbl_hope.place(relx=0.5, rely=0.4, anchor=CENTER)

    style_btn_tspcancel = ttkb.Style()
    style_btn_tspcancel.configure("BtnBackhome.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    btn_back = ttkb.Button(frame_tysupport, text="Back to Home", width=15,  style="BtnBackhome.dark.Outline.TButton", takefocus=False,command=backhome_canceltsp)
    btn_back.place(relx=0.5, rely=0.85, anchor=CENTER, width=700, height=100)

# Function confirmation to cancel tsp
def cancel_confirmtsp():
    frame_base_cancelconfirm.place(x=0, y=0, relheight=1, relwidth=1)
    frame_base_cancelconfirm.lift()

    frame_cancelconfirm.place(relx=0.5, rely=0.4, anchor=CENTER, width=1400, height=300)
    frame_cancelconfirm.configure(highlightbackground="black", highlightthickness=2)
    frame_cancelconfirm.lift()

    lbl_confirm = ttkb.Label(frame_cancelconfirm, text="Are you sure to cancel subscription of Task Striker Premium ?", font=style_title1)
    lbl_confirm.place(relx=0.5, rely=0.2, anchor=CENTER)

    style_btn_canceltsp = ttkb.Style()
    style_btn_canceltsp.configure("BtnConfirm.success.TButton", font=('Helvetica',15,'bold'))
    btn_ok = ttkb.Button(frame_cancelconfirm, text="Confirm", style="BtnConfirm.success.TButton", takefocus=False,command=cancel_tsp)
    btn_ok.place(relx=0.7, rely=0.7, anchor=CENTER, width=400, height=80)

    style_btn_canceltsp.configure("BtnCancel.danger.TButton", font=('Helvetica',15,'bold'))
    btn_cancel = ttkb.Button(frame_cancelconfirm, text="Cancel", style="BtnCancel.danger.TButton", takefocus=False,command=lambda: frame_tspstatus.lift())
    btn_cancel.place(relx=0.3, rely=0.7, anchor=CENTER, width=400, height=80)

# Function check benefits(show page when first clicking tsp)
def check_benefitc():
    membershipc()
    style_back_status = ttkb.Style()
    style_back_status.configure("BtnBack.dark.Outline.TButton", font=('Helvetica',15,'bold'))
    btn_back = ttkb.Button(frame_base_membershipc, text="Back", width=15, style="BtnBack.dark.Outline.TButton", takefocus=False,command=lambda: frame_tspstatus.lift())
    btn_back.place(x=300, y=800, height=80)
    lbl_nojoin = ttkb.Label(frame_membershipc, text="                             ", font=style_button2)
    lbl_nojoin.place(relx=0.5, y=900, width=900, height=500, anchor=CENTER) 

# Function TSP status
def status_tsp():
    frame_tspstatus.place(x=0, y=0, relheight=1, relwidth=1)
    frame_tspstatus.lift()

    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    # Get value from txt file
    id_index = clientlist.index(client_uid)
    tsp_date = clientlist[id_index+4]
    start_date = datetime.datetime.strptime(tsp_date, "%d/%m/%Y")
    one_month_delta = datetime.timedelta(days=30)
    renew_date = start_date + one_month_delta

    # Show tsp renew date
    lbl_tsp = ttkb.Label(frame_tspstatus, text="Task Striker Premium", font=style_title2)
    lbl_tsp.place(x=200,y=200)

    lbl_ppm = ttkb.Label(frame_tspstatus, text="RM 4.90 / month", font=style_title1)
    lbl_ppm.place(x=200, y=330)
    lbl_renewdate = ttkb.Label(frame_tspstatus, text="Renew Date: "+str(renew_date), font=style_title1)
    lbl_renewdate.place(x=200, y=400)

    style_btn_tspstatus = ttkb.Style()
    style_btn_tspstatus.configure("BtnTSPS.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    style_btn_tspstatus.configure("BtnCancel.danger.TButton", font=("Helvetica",20,"bold"))
    btn_cancel = ttkb.Button(frame_tspstatus, text="Cancel Subscription", width=20,  style="BtnCancel.danger.TButton", takefocus=False,command=cancel_confirmtsp)
    btn_cancel.place(relx=0.3, rely=0.85, anchor=CENTER, width=700, height=100)

    style_btn_tspstatus.configure("BtnBenefit.success.TButton", font=("Helvetica",20,"bold"))
    btn_benefit = ttkb.Button(frame_tspstatus, text="Check Benefits", width=20,  style="BtnBenefit.success.TButton", takefocus=False,command=check_benefitc)
    btn_benefit.place(relx=0.7, rely=0.85, anchor=CENTER, width=700, height=100)

# Function check tsp subscribed or not
def check_tspexist():
    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    tsp_index = clientlist.index(client_uid)+3
    tsp_status = clientlist[tsp_index]
    # if tsp not subscribed, no discount and hide back button in tsp benefits
    if tsp_status == "n":
        frame_tspstatus.place_forget()
        frame_base_membershipc.lift()
        global discount
        discount = 0.0
        lbl_nojoin = ttkb.Label(frame_membershipc, text="                                ", font=style_button2)
        lbl_nojoin.place(relx=0.05, y=800, width=400, height=700)
    # if tsp subscribed, discount = 10% and hide ad banner in home page
    elif tsp_status == "y":
        frame_base_membershipc.place_forget()
        frame_tspstatus.lift()

        lbl_adfree = ttkb.Label(frame_homec, text="                             ", font=style_button2)
        lbl_adfree.place(relx=0.3, y=650, width=900, height=300)    
        discount = 0.1

# Function to home page after completing tsp payment
def backtohome():
    frame_tspcomplete.place_forget()
    homepagec.select(0)
    status_tsp()

# Function after user complete tsp payment
def tsp_complete():
    frame_choosepayment.place_forget()

    frame_tspcomplete.place(x=0, y=0, relheight=1, relwidth=1)
    frame_tspcomplete.lift()

    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    # Get curretn date time of client subscribe tsp
    current_date = datetime.datetime.now()
    tsp_date = current_date.strftime("%d/%m/%Y")

    # Update in client list txt file tsp status and datetime
    id_index = clientlist.index(client_uid)
    global tsp_status
    tsp_status = "y"
    clientlist[id_index+3] = tsp_status
    clientlist[id_index+4] = tsp_date
    file_client=open("clientlist.txt", "w")
    file_client.write("\n".join(clientlist))
    file_client.close()

    # Call function to check whether tsp ald subscribed
    check_tspexist()

    lbl_complete = ttkb.Label(frame_tspcomplete, text="Payment Successful", font=style_title2)
    lbl_complete.place(x=200,y=30)

    lbl_welcome = ttkb.Label(frame_tspcomplete, text="Welcome to Task Striker Premium!", font=style_title3)
    lbl_welcome.place(relx=0.5, rely=0.3, anchor=CENTER)
    lbl_info = ttkb.Label(frame_tspcomplete, text="You can check your Task Striker Premium status in the Membership option.", font=style_title1)
    lbl_info.place(relx=0.5, rely=0.4, anchor=CENTER)

    style_btn_tspcomplete = ttkb.Style()
    style_btn_tspcomplete.configure("BtnHome.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    btn_back = ttkb.Button(frame_tspcomplete, text="Back to Home", width=15,  style="BtnHome.dark.Outline.TButton", takefocus=False,command=backtohome)
    btn_back.place(relx=0.5, rely=0.85, anchor=CENTER, width=700, height=100)

# Function show join tsp details
def join_tsp():
    frame_jointsp.place(x=0, y=0, relheight=1, relwidth=1)
    frame_jointsp.lift()

    global function_from
    function_from = "tsp_payment"
    
    lbl_join = ttkb.Label(frame_jointsp, text="Join Task Striker Premium", font=style_title2)
    lbl_join.place(x=200,y=30)

    lbl_tsp = ttkb.Label(frame_jointsp, text="Task Striker Premium", font=style_title1)
    lbl_tsp.place(x=300, y=350)

    lbl_tsp = ttkb.Label(frame_jointsp, text="Auto renew, cancel anytime.", font=style_text1)
    lbl_tsp.place(x=300, y=400)

    lbl_price = ttkb.Label(frame_jointsp, text="RM 4.90 / month", font=style_title1)
    lbl_price.place(x=1200, y=350)

    style_btnjointsp = ttkb.Style()
    style_btnjointsp.configure("BtnJoinTSP.success.TButton", font=('Helvetica',20,'bold'), padding=(50, 30))

    btn_confirm = ttkb.Button(frame_jointsp, text="Confirm", width=20, style="BtnJoinTSP.success.TButton", takefocus=False, command=choose_paymentc)
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER)

    style_btnjointsp.configure("Btnback.dark.Outline.TButton", font=("Helvetica",15))
    btn_cancel = ttkb.Button(frame_jointsp, text="Cancel", width=15,  style="Btnback.dark.Outline.TButton", takefocus=False, command=lambda: frame_base_membershipc.tkraise())
    btn_cancel.place(x=100, y=800, height=80)

# Function membership(tsp) details
def membershipc():

    frame_base_membershipc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_base_membershipc.lift()

    style_lblmembership = ttkb.Style()
    style_lblmembership.configure('LblMembership.TLabel', font=style_title2, padding=(30,0))
    lbl_membershipc = ttkb.Label(frame_membershipc, text="Task Striker Premium", style='LblMembership.TLabel')

    style_frame.configure('FrameMembership1.TLabelframe',
                          padding=(0,0,0,30),
                          highlightthickness=4,
                          labelmargins=20
                          )

    frame_membershipc.pack(anchor=CENTER)
    frame_membershipc.configure(height=1200,
                                width=1600,
                                style='FrameMembership1.TLabelframe',
                                labelwidget=lbl_membershipc
                                )
    frame_membershipc.lift()

    lbl_noback = ttkb.Label(frame_membershipc, text="                       ", font=style_button2)
    lbl_noback.place(x=100, y=800)

    lbl_price = ttkb.Label(frame_membershipc, text="RM 4.90 / month", font=style_title1)
    lbl_price.place(relx=0.72)

    sep1 = ttkb.Separator(frame_membershipc, orient="horizontal")
    sep1.place(relx=0.5, y=80, relwidth=0.95, anchor='center')


    lbl_benefit = ttkb.Label(frame_membershipc, text="Benefits", font=style_title1)
    lbl_benefit.place(relx=0.5, y=120, anchor=CENTER)

    sep2 = ttkb.Separator(frame_membershipc, orient="vertical")
    sep2.place(relx=0.3, y=200, relheight=0.47)

    sep3 = ttkb.Separator(frame_membershipc, orient="vertical")
    sep3.place(relx=0.7, y=200, relheight=0.47)

    lbl_adfree = ttkb.Label(frame_membershipc, text="Ad Free", font=style_text5)
    lbl_adfree.place(x=85, y=240)
    lbl_adfreetext1 = ttkb.Label(frame_membershipc, text="Enjoy a clean and", font=style_text2)
    lbl_adfreetext1.place(x=85, y=350)
    lbl_adfreetext2 = ttkb.Label(frame_membershipc, text="uninterrupted experience", font=style_text2)
    lbl_adfreetext2.place(x=85, y=390)
    lbl_adfreetext3 = ttkb.Label(frame_membershipc, text="without ads !", font=style_text2)
    lbl_adfreetext3.place(x=85, y=430)

    lbl_disc = ttkb.Label(frame_membershipc, text="Discounts", font=style_text5)
    lbl_disc.place(x=680, y=240)
    lbl_disctext1 = ttkb.Label(frame_membershipc, text="Get a ", font=style_text2)
    lbl_disctext1.place(x=680, y=350)
    lbl_disctext2 = ttkb.Label(frame_membershipc, text="10%", font=style_title3)
    lbl_disctext2.place(x=780, y=300)
    lbl_disctext3 = ttkb.Label(frame_membershipc, text="discount on", font=style_text2)
    lbl_disctext3.place(x=680, y=390)
    lbl_disctext4 = ttkb.Label(frame_membershipc, text="every commission ! ", font=style_text2)
    lbl_disctext4.place(x=680, y=430)

    lbl_adfree = ttkb.Label(frame_membershipc, text="Fast Responses", font=style_text5)
    lbl_adfree.place(x=1200, y=240)
    lbl_adfree = ttkb.Label(frame_membershipc, text="Chat immediately", font=style_text2)
    lbl_adfree.place(x=1200, y=350)
    lbl_adfree = ttkb.Label(frame_membershipc, text="with Pros !", font=style_text2)
    lbl_adfree.place(x=1200, y=390)

    style_btnjoin = ttkb.Style()
    style_btnjoin.configure("BtnJoin.dark.Outline.TButton", font=('Helvetica',20,'bold'))

    btn_join = ttkb.Button(frame_membershipc, text="Join Task Striker Premium!", width=40, style="BtnJoin.dark.Outline.TButton", takefocus=False,command=join_tsp)
    btn_join.place(relx=0.5, rely=0.85, height=80, anchor=CENTER)


# ---------- PROFILE Client ----------

# Function cancel edit client profile
def cancel_profilec():
    frame_editprofilec.place_forget()
    frame_profilec.lift()

# Function check client profile input
def check_profilec():

    client_profile=open("client_profile.txt","r")
    clientprofile_content=client_profile.read()
    clientprofile_list=clientprofile_content.split("\n")

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    global client_uid
    global entry_name
    global entry_email
    global entry_phone
    global entry_gender
    global var_age
    global entry_bday
    global lbl_biotext

    # Create list, append entry status in list
    status_list = []
    if not entry_name.get():
        status_list.append("name_empty")
    if not entry_email.get():
        status_list.append("email_empty")
    if entry_email.get() != client_email:
        if entry_email.get() in clientprofile_list or entry_email.get() in proprofile_list:
            status_list.append("email_exist")
    if not entry_phone.get():
        status_list.append("phone_empty")
    if entry_phone.get() != client_phone:
        if entry_phone.get() in clientprofile_list or entry_phone.get() in proprofile_list:
            status_list.append("phone_exist")
    # If value in list
    if status_list:
        
        lbl_errorname = Label(frame_editprofilec, font=style_texterror)
        lbl_errorname.place(x=1400, y=135)
        lbl_errorname.configure(fg='RED', text = "                                                ")
        lbl_erroremail = Label(frame_editprofilec, font=style_texterror)
        lbl_erroremail.place(x=1400, y=185)
        lbl_erroremail.configure(fg='RED', text = "                                                          ")
        lbl_errorphone = Label(frame_editprofilec, font=style_texterror)
        lbl_errorphone.place(x=1400, y=235)
        lbl_errorphone.configure(fg='RED', text = "                                                          ")
        lbl_status = Label(frame_editprofilec, font=style_texterror)
        lbl_status.place(relx=0.5, rely=0.78, anchor=CENTER)
        lbl_status.configure(fg='RED', text = "                                             ")
        # Loop until all status is cleared
        for status in status_list:
            if status == "name_empty":
                lbl_errorname = Label(frame_editprofilec, font=style_texterror)
                lbl_errorname.place(x=1400, y=135)
                lbl_errorname.configure(fg='RED', text = "Please enter name!     ")
            if status == "email_empty":
                lbl_erroremail = Label(frame_editprofilec, font=style_texterror)
                lbl_erroremail.place(x=1400, y=185)
                lbl_erroremail.configure(fg='RED', text = "Please enter email address!       ")
            if status == "email_exist":
                lbl_erroremail = Label(frame_editprofilec, font=style_texterror)
                lbl_erroremail.place(x=1400, y=185)
                lbl_erroremail.configure(fg='RED', text = "Email address already exist!       ")
            if status == "phone_empty":
                lbl_errorphone = Label(frame_editprofilec, font=style_texterror)
                lbl_errorphone.place(x=1400, y=235)
                lbl_errorphone.configure(fg='RED', text = "Please enter phone number!        ")
            if status == "phone_exist":
                lbl_errorphone = Label(frame_editprofilec, font=style_texterror)
                lbl_errorphone.place(x=1400, y=235)
                lbl_errorphone.configure(fg='RED', text = "Phone number already exist!       ")
        lbl_status = Label(frame_editprofilec, font=style_texterror)
        lbl_status.place(relx=0.5, rely=0.78, anchor=CENTER)
        lbl_status.configure(fg='RED', text = "*** Please check input")
        return
    # If all requirement ok, then proceed
    lbl_errorname = Label(frame_editprofilec, font=style_texterror)
    lbl_errorname.place(x=1400, y=135)
    lbl_errorname.configure(fg='RED', text = "                                                ")
    lbl_erroremail = Label(frame_editprofilec, font=style_texterror)
    lbl_erroremail.place(x=1400, y=185)
    lbl_erroremail.configure(fg='RED', text = "                                                          ")
    lbl_errorphone = Label(frame_editprofilec, font=style_texterror)
    lbl_errorphone.place(x=1400, y=235)
    lbl_errorphone.configure(fg='RED', text = "                                                          ")
    lbl_status = Label(frame_editprofilec, font=style_texterror)
    lbl_status.place(relx=0.5, rely=0.78, anchor=CENTER)
    lbl_status.configure(fg='RED', text = "                                             ")

    # Get required details after all correct
    name = entry_name.get()
    email = entry_email.get()
    phone = entry_phone.get()

    # Optional details if no value then value = "na"
    if entry_gender.get() == "":
        gender = "na"
    else:
        gender = entry_gender.get()
    if var_age.get() == "":
        age = "na"
    else:
        age = var_age.get()
    if entry_bday.entry.get() == "":
        bday = "na"
    else:
        bday = entry_bday.entry.get()
    if lbl_biotext.get("1.0", "end-1c") == "":
        bio = "na"
    else:
        bio = lbl_biotext.get("1.0", "end-1c")

    # Update information in txt file
    id_index = clientprofile_list.index(client_uid)
    clientprofile_list[id_index+1] = name
    clientprofile_list[id_index+2] = email
    clientprofile_list[id_index+3] = phone
    clientprofile_list[id_index+4] = gender
    clientprofile_list[id_index+5] = age
    clientprofile_list[id_index+6] = bday
    clientprofile_list[id_index+7] = bio
    client_profile=open("client_profile.txt", "w")
    client_profile.write("\n".join(clientprofile_list))
    client_profile.close()

    # Call function to update client profile
    profile_client()

# Function edit profile client
def edit_profilec():
    client_profile=open("client_profile.txt","r")
    clientprofile_content=client_profile.read()
    clientprofile_list=clientprofile_content.split("\n")

    frame_editprofilec.place(x=0, y=0, relheight=1, relwidth=1)
    frame_editprofilec.pack_propagate(False)
    frame_editprofilec.lift()
    # Set error msg initial value
    lbl_errorname = Label(frame_editprofilec, font=style_texterror)
    lbl_errorname.place(x=1400, y=135)
    lbl_errorname.configure(fg='RED', text = "                                                ")
    lbl_erroremail = Label(frame_editprofilec, font=style_texterror)
    lbl_erroremail.place(x=1400, y=185)
    lbl_erroremail.configure(fg='RED', text = "                                                          ")
    lbl_errorphone = Label(frame_editprofilec, font=style_texterror)
    lbl_errorphone.place(x=1400, y=235)
    lbl_errorphone.configure(fg='RED', text = "                                                          ")
    lbl_status = Label(frame_editprofilec, font=style_texterror)
    lbl_status.place(relx=0.5, rely=0.78, anchor=CENTER)
    lbl_status.configure(fg='RED', text = "                                             ")

    # Entry widgets etc. to get profile details input
    global entry_name
    global entry_email
    global entry_phone
    global entry_gender
    global var_age
    global entry_bday
    global lbl_biotext

    lbl_profile = ttkb.Label(frame_editprofilec, text="Edit Profile", font=style_title2)
    lbl_profile.place(x=300, y=30)
    lbl_profile.configure()

    lbl_name = ttkb.Label(frame_editprofilec, text="Name: ", font=style_button3)
    lbl_name.place(x=900, y=130)
    lbl_name.config()
    entry_name = ttkb.Entry(frame_editprofilec)
    entry_name.place(x=1050, y=130, width=300, height=40)
    entry_name.configure(font=style_text3)
    entry_name.insert(0,client_name)

    lbl_email = ttkb.Label(frame_editprofilec, text="Email: ", font=style_button3)
    lbl_email.place(x=900, y=180)
    lbl_email.config()
    entry_email = ttkb.Entry(frame_editprofilec)
    entry_email.place(x=1050, y=180, width=300, height=40)
    entry_email.configure(font=style_text3)
    entry_email.insert(0,client_email)

    lbl_phone = ttkb.Label(frame_editprofilec, text="Phone: ", font=style_button3)
    lbl_phone.place(x=900, y=230)
    lbl_phone.config()
    entry_phone = ttkb.Entry(frame_editprofilec)
    entry_phone.place(x=1050, y=230, width=300, height=40)
    entry_phone.configure(font=style_text3)
    entry_phone.insert(0,client_phone)

    lbl_uid = ttkb.Label(frame_editprofilec, text="User ID: "+client_uid, font=style_button3)
    lbl_uid.place(x=300, y=130)
    lbl_uid.config()

    lbl_gender = ttkb.Label(frame_editprofilec, text="Gender: " , font=style_button3)
    lbl_gender.place(x=300, y=180)
    lbl_gender.config()
    genders = ['Male', 'Female', 'Others', 'Rather not say']
    entry_gender = ttkb.Combobox(frame_editprofilec, bootstyle='dark', values=genders)
    entry_gender.place(x=460, y=180)

    lbl_age = ttkb.Label(frame_editprofilec, text="Age: " , font=style_button3)
    lbl_age.place(x=300, y=230)
    lbl_age.config()
    var_age = StringVar()
    var_age.set(client_age)
    entry_agep = ttkb.Spinbox(frame_editprofilec, style="dark", textvariable=var_age, font=("Helvetica",15), from_=18, to=100, state="readonly")
    entry_agep.place(x=400, y=230, width=100, height=45)

    lbl_bday = ttkb.Label(frame_editprofilec, text="Birthday: " , font=style_button3)
    lbl_bday.place(x=300, y=280)
    entry_bday = ttkb.DateEntry(frame_editprofilec, bootstyle="dark", dateformat="%d/%m/%Y")
    entry_bday.place(x=460, y=280)

    sep = ttkb.Separator(frame_editprofilec, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=350, relwidth=0.8, anchor='center')

    lbl_bio = ttkb.Label(frame_editprofilec, text="Bio: ", font=style_button3)
    lbl_bio.place(x=300, y=380)
    lbl_biotext = Text(frame_editprofilec, wrap="word", relief="sunken", bd=2, width=50, height=5, borderwidth=0, bg="#d0d6d6", font=style_button3)
    lbl_biotext.place(x=400, y=380)
    lbl_biotext.insert("end", client_bio)
    lbl_biotext.configure()

    style_btn_editc = ttkb.Style()
    style_btn_editc.configure("BtnEditC.dark.TButton", font=('Helvetica',20,'bold'))

    btn_check_profile = ttkb.Button(frame_editprofilec, text="Save Changes", width=20, style="BtnEditC.dark.TButton", takefocus=False, command=check_profilec)
    btn_check_profile.place(relx=0.5, rely=0.85, anchor=CENTER, height=80)

    style_btn_editc.configure("BtnCancelC.dark.Outline.TButton", font=('Helvetica',15,'bold'))
    btn_cancel = ttkb.Button(frame_editprofilec, text="Cancel", width=15, style="BtnCancelC.dark.Outline.TButton", takefocus=False, command=cancel_profilec)
    btn_cancel.place(relx=0.1, rely=0.85, anchor=CENTER, height=80)

# Function client profile
def profile_client():

    client_profile=open("client_profile.txt","r")
    clientprofile_content=client_profile.read()
    clientprofile_list=clientprofile_content.split("\n")

    frame_profilec.place(x=0, y=0, relheight=1, relwidth=1)
    frame_profilec.pack_propagate(False)
    frame_profilec.lift()

    global client_uid
    global client_name
    global client_email
    global client_phone
    global client_gender
    global client_age
    global client_bday
    global client_bio

    client_uid = entry_id.get()
    client_uid_index = clientprofile_list.index(client_uid)
    # Get value from txt file, if na then value = "-"
    client_name = clientprofile_list[client_uid_index+1]
    client_email = clientprofile_list[client_uid_index+2]
    client_phone = clientprofile_list[client_uid_index+3]
    if client_phone == "na":
        client_phone = " -                  "
    client_gender = clientprofile_list[client_uid_index+4]
    if client_gender == "na":
        client_gender = " -                 "
    client_age = clientprofile_list[client_uid_index+5]
    if client_age == "na":
        client_age = " -                    "
    client_bday = clientprofile_list[client_uid_index+6]
    if client_bday == "na":
        client_bday = " -                   "
    client_bio = clientprofile_list[client_uid_index+7]
    if client_bio == "na":
        client_bio = " -                    "


    lbl_profile = ttkb.Label(frame_profilec, text="My Profile", font=style_title2)
    lbl_profile.place(x=300, y=30)
    lbl_profile.configure()

    lbl_name = ttkb.Label(frame_profilec, text="Name: " + client_name, font=style_button3)
    lbl_name.place(x=900, y=130)
    lbl_name.config()
    lbl_email = ttkb.Label(frame_profilec, text="Email: " + client_email, font=style_button3)
    lbl_email.place(x=900, y=180)
    lbl_email.config()
    lbl_phone = ttkb.Label(frame_profilec, text="Phone: " + client_phone, font=style_button3)
    lbl_phone.place(x=900, y=230)
    lbl_phone.config()

    lbl_uid = ttkb.Label(frame_profilec, text="User ID: " + client_uid, font=style_button3)
    lbl_uid.place(x=300, y=130)
    lbl_uid.config()
    lbl_gender = ttkb.Label(frame_profilec, text="Gender: " + client_gender, font=style_button3)
    lbl_gender.place(x=300, y=180)
    lbl_gender.config()
    lbl_age = ttkb.Label(frame_profilec, text="Age: " + client_age, font=style_button3)
    lbl_age.place(x=300, y=230)
    lbl_age.config()
    lbl_bday = ttkb.Label(frame_profilec, text="Birthday: " + client_bday, font=style_button3)
    lbl_bday.place(x=300, y=280)
    lbl_bday.config()

    sep = ttkb.Separator(frame_profilec, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=350, relwidth=0.8, anchor='center')

    lbl_bio = ttkb.Label(frame_profilec, text="Bio: ", font=style_button3)
    lbl_bio.place(x=300, y=380)
    lbl_bio.config()
    lbl_biotext = Text(frame_profilec, wrap="word", relief="sunken", bd=2, width=50, borderwidth=0, bg="#d0d6d6", font=style_button3)
    lbl_biotext.place(x=400, y=380)
    lbl_biotext.insert("end", client_bio)
    lbl_biotext.configure(highlightthickness=0, state=DISABLED)

    style_btn_edit = ttkb.Style()
    style_btn_edit.configure("BtnEdit.dark.TButton", font=('Helvetica',20,'bold'))
    btn_edit_profile = ttkb.Button(frame_profilec, text="Edit Profile", width=25, style="BtnEdit.dark.TButton", takefocus=False, command=edit_profilec)
    btn_edit_profile.place(relx=0.5, rely=0.85, anchor=CENTER, height=80)

# ---------- My Order Client ----------

# Go to home page after task fully completed
def backhome_order():
    # forget all order frames and call function orderc to refresh current order
    frame_ratingc.place_forget()
    frame_paymentsuccessc.place_forget()
    frame_paymentc.place_forget()
    frame_hoursc.place_forget()
    frame_orderc.place_forget()
    frame_completec.place_forget()
    orderc()

    homepagec.select(0)

# Function task fully complete
def taskpayment_complete():
    frame_completec.place(x=0, y=0, relheight=1, relwidth=1)
    frame_completec.pack_propagate(False)
    frame_completec.lift()

    client_history=open("client_history.txt","r")
    clienthistory_content=client_history.read()
    clienthistory_list=clienthistory_content.split("\n")

    client_history=open("client_history.txt","a")
    client_history.write("\n"+client_uid+"\n")
    client_history.write(pro_uid+"\n")
    client_history.write(pro_name+"\n")
    client_history.write(pro_email+"\n")
    client_history.write(pro_phone+"\n")
    client_history.write(pro_field+"\n")
    client_history.write(pro_skills+"\n")
    client_history.write(priceperhour+"\n")
    client_history.write(final_fee+"\n")
    client_history.write(order_date)
    client_history.close()

    client_myorder=open("client_myorder.txt","r")
    clientorder_content=client_myorder.read()
    clientorder_list=clientorder_content.split("\n")

    # Delete current order details in client myorder as task already completed
    client_idindex = clientorder_list.index(client_uid)
    del clientorder_list[client_idindex:client_idindex + 10]
    client_myorder = open("client_myorder.txt", "w")
    client_myorder.write("\n".join(clientorder_list))
    client_myorder.close()

    lbl_welcome = ttkb.Label(frame_completec, text="Order Fully Completed ", font=style_title3)
    lbl_welcome.place(relx=0.5, rely=0.3, anchor=CENTER)
    lbl_info = ttkb.Label(frame_completec, text="~ Please continue support us in the future. Thank You ~", font=style_title1)
    lbl_info.place(relx=0.5, rely=0.4, anchor=CENTER)

    style_btn_tspcomplete = ttkb.Style()
    style_btn_tspcomplete.configure("BtnHome.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    btn_back = ttkb.Button(frame_completec, text="Back to Home", width=15,  style="BtnHome.dark.Outline.TButton", takefocus=False,command=backhome_order)
    btn_back.place(relx=0.5, rely=0.85, anchor=CENTER, width=700, height=100)

# Function check value of ratings
def check_ratingc():

    pro_ratings=open("ratingnfeedback.txt","r")
    proratings_content=pro_ratings.read()
    proratings_list=proratings_content.split("\n")

    global pro_uid
    global client_uid
    global pro_name
    global client_name

    client_review = textentry_feedback.get("1.0", "end-1c") 
    
    # Change into float in 1dp
    if var_ratingc.get() == 1:
        rating = 1.0
    elif var_ratingc.get() == 2:
        rating = 2.0
    elif var_ratingc.get() == 3:
        rating = 3.0
    elif var_ratingc.get() == 4:
        rating = 4.0
    elif var_ratingc.get() == 5:
        rating = 5.0

    # Open rating txt file and record client ratings under pro_uid
    pro_ratings=open("ratingnfeedback.txt","a")
    pro_ratings.write("\n"+pro_uid+"\n")
    pro_ratings.write(pro_name+"\n")
    pro_ratings.write(client_uid+"\n")
    pro_ratings.write(client_name+"\n")
    pro_ratings.write(str(rating))
    pro_ratings.write("\n"+client_review)
    pro_ratings.close()
    # Call function to show task fully complete
    taskpayment_complete()

# Function client rating
def rating_client():
    frame_ratingc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_ratingc.pack_propagate(False)
    frame_ratingc.lift() 

    lbl_rating = ttkb.Label(frame_ratingc, text="Rating", font=style_title2)
    lbl_rating.place(x=200,y=30)

    lbl_info = ttkb.Label(frame_ratingc, text="Please rate your Pro on a scale of 1-5 ☆", font=style_title1)
    lbl_info.place(relx=0.5, rely=0.2, anchor=CENTER)

    style_btn_ratingc = ttkb.Style()
    style_btn_ratingc.configure("BtnRatingC.dark.Outline.TButton", font=("Helvetica",15,"bold"))

    global var_ratingc
    var_ratingc = IntVar()
    # Client choose 1-5 stars rating
    style_btn_ratingc.configure("BtnStar.dark.Outline.Toolbutton", font=("Helvetica",30,"bold"))
    rbtn_star1 = ttkb.Radiobutton(frame_ratingc, text="1 ☆",
                                 style="BtnStar.dark.Outline.Toolbutton", 
                                 variable=var_ratingc, 
                                 value = 1,
                                 takefocus=False
                                )
    rbtn_star1.place(relx=0.2, rely=0.3, width=200, height=100, anchor=CENTER)

    rbtn_star2 = ttkb.Radiobutton(frame_ratingc, text="2 ☆",
                                 style="BtnStar.dark.Outline.Toolbutton", 
                                 variable=var_ratingc, 
                                 value = 2,
                                 takefocus=False
                                )
    rbtn_star2.place(relx=0.35, rely=0.3, width=200, height=100, anchor=CENTER)

    rbtn_star3 = ttkb.Radiobutton(frame_ratingc, text="3 ☆",
                                 style="BtnStar.dark.Outline.Toolbutton", 
                                 variable=var_ratingc, 
                                 value = 3,
                                 takefocus=False
                                )
    rbtn_star3.place(relx=0.5, rely=0.3, width=200, height=100, anchor=CENTER)

    rbtn_star4 = ttkb.Radiobutton(frame_ratingc, text="4 ☆",
                                 style="BtnStar.dark.Outline.Toolbutton", 
                                 variable=var_ratingc, 
                                 value = 4,
                                 takefocus=False
                                )
    rbtn_star4.place(relx=0.65, rely=0.3, width=200, height=100, anchor=CENTER)

    rbtn_star5 = ttkb.Radiobutton(frame_ratingc, text="5 ☆",
                                 style="BtnStar.dark.Outline.Toolbutton", 
                                 variable=var_ratingc, 
                                 value = 5,
                                 takefocus=False
                                )
    rbtn_star5.place(relx=0.8, rely=0.3, width=200, height=100, anchor=CENTER)

    lbl_feedback = ttkb.Label(frame_ratingc, text="Leave a review !", font=style_title1)
    lbl_feedback.place(relx=0.5, rely=0.42, anchor=CENTER)

    global textentry_feedback
    textentry_feedback = Text(frame_ratingc, wrap="word", relief="sunken", font=style_text1)
    textentry_feedback.place(relx=0.5, rely=0.55, anchor=CENTER, width=1000, height=200)
    textentry_feedback.configure(highlightthickness=1)

    style_btn_ratingc.configure("BtnRatingConfirm.success.TButton", font=("Helvetica",15,"bold"))
    btn_confirm = ttkb.Button(frame_ratingc, text="Confirm", width=20,  style="BtnRatingConfirm.success.TButton", takefocus=False,command=check_ratingc)
    btn_confirm.place(relx=0.5, rely=0.8, height=80, anchor=CENTER)

# Function payment successful
def payment_successful():
    frame_choosepayment.place_forget()
    frame_paymentsuccessc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_paymentsuccessc.pack_propagate(False)
    frame_paymentsuccessc.lift()

    lbl_success = ttkb.Label(frame_paymentsuccessc, text="Payment Successful ! ", font=style_title3)
    lbl_success.place(relx=0.5, rely=0.3, anchor=CENTER)
    lbl_info = ttkb.Label(frame_paymentsuccessc, text="Please inform your Pro to click the 'Task Complete' button on their side", font=style_title1)
    lbl_info.place(relx=0.5, rely=0.43, anchor=CENTER)
    lbl_info = ttkb.Label(frame_paymentsuccessc, text="so that the commission fee can be deposited to them.", font=style_title1)
    lbl_info.place(relx=0.5, rely=0.5, anchor=CENTER)

    style_btn_successc = ttkb.Style()
    style_btn_successc.configure("BtnSuccess.success.TButton", font=("Helvetica",15,"bold"))
    btn_confirm = ttkb.Button(frame_paymentsuccessc, text="Continue", width=20,  style="BtnSuccess.success.TButton", takefocus=False,command=rating_client)
    btn_confirm.place(relx=0.5, rely=0.8, height=80, anchor=CENTER)

# Function show payment counting details
def taskpayment_details():
    frame_paymentc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_paymentc.pack_propagate(False)
    frame_paymentc.lift()

    global function_from
    function_from = "task_payment"

    global final_fee
    # Counting of total fee: (price per hour * total hours) - discount(if any)
    total_fee = float(priceperhour)*hours
    fee_discount = total_fee*discount
    final_fee = "{:.2f}".format(total_fee - fee_discount)
    
    # Change into 2dp, and hours to 0dp
    total_fee_2f = "{:.2f}".format(float(total_fee))
    priceperhour_2f = "{:.2f}".format(float(priceperhour))
    hours_2f = "{:.0f}".format(hours)
    fee_discount_2f = "{:.2f}".format(fee_discount)

    lbl_profile = ttkb.Label(frame_paymentc, text="Payment", font=style_title2)
    lbl_profile.place(x=300, y=30)

    lbl_type = ttkb.Label(frame_paymentc, text="Type", font=style_title1)
    lbl_type.place(x=300, y=170)
    lbl_amount = ttkb.Label(frame_paymentc, text="Amount (RM)", font=style_title1)
    lbl_amount.place(x=1300, y=170)

    sep = ttkb.Separator(frame_paymentc, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=260, relwidth=0.8, anchor=CENTER)

    lbl_base = ttkb.Label(frame_paymentc, text="Fee (per hour)", font=style_text4)
    lbl_base.place(x=300, y=290)
    lbl_basenum = ttkb.Label(frame_paymentc, text=str(priceperhour_2f), font=style_text4)
    lbl_basenum.place(x=1500, y=290, anchor=NE)

    lbl_hours = ttkb.Label(frame_paymentc, text="Total Hour(s)", font=style_text4)
    lbl_hours.place(x=300, y=350)
    lbl_hoursnum = ttkb.Label(frame_paymentc, text=str(hours_2f), font=style_text4)
    lbl_hoursnum.place(x=1500, y=350, anchor=NE)

    sep = ttkb.Separator(frame_paymentc, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=430, relwidth=0.8, anchor=CENTER)

    lbl_subtotal = ttkb.Label(frame_paymentc, text="Subtotal", font=style_text4)
    lbl_subtotal.place(x=1000, y=460)
    lbl_subtotalnum = ttkb.Label(frame_paymentc, text=str(total_fee_2f), font=style_text4)
    lbl_subtotalnum.place(x=1500, y=460, anchor=NE)

    lbl_discount = ttkb.Label(frame_paymentc, text="Discount", font=style_text4)
    lbl_discount.place(x=1000, y=520)
    lbl_hoursnum = ttkb.Label(frame_paymentc, text=str(fee_discount_2f), font=style_text4)
    lbl_hoursnum.place(x=1500, y=520, anchor=NE)

    lbl_total = ttkb.Label(frame_paymentc, text="Total", font=style_title1)
    lbl_total.place(x=1000, y=580)
    lbl_totalnum = ttkb.Label(frame_paymentc, text=str(final_fee), font=style_title1)
    lbl_totalnum.place(x=1500, y=580, anchor=NE)

    style_btn_paymentc = ttkb.Style()
    style_btn_paymentc.configure("BtnOrder.dark.Outline.TButton", font=("Helvetica",15,"bold"))

    style_btn_paymentc.configure("BtnComplete.success.TButton", font=("Helvetica",15,"bold"))
    btn_confirm = ttkb.Button(frame_paymentc, text="Confirm Payment", width=25,  style="BtnComplete.success.TButton", takefocus=False,command=choose_paymentc)
    btn_confirm.place(relx=0.5, rely=0.8, height=80, anchor=CENTER)

# Check client's hours input
def check_hoursc(hours_clicked):
    global hours
    hours = entry_hoursc.get()
    # If hours is a number(whole number)
    if hours.isdigit():
        # Float value and call function to show payment details
        hours = float(hours)
        taskpayment_details()
    else:
        # if not a number, show error msg telling client to key in a number
        entry_hoursc.delete(0, END)
        lbl_error = Label(frame_hoursc, text="Please key in a number!", font=style_text3)
        lbl_error.place(relx=0.5, rely=0.68, anchor=CENTER)
        lbl_error.configure(fg="RED")
# Function client type total hours
def hoursc():
    global frame_hoursc
    frame_hoursc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_hoursc.pack_propagate(False)
    frame_hoursc.lift()

    lbl_hourstitle = ttkb.Label(frame_hoursc, text="Please key in the hours of work of hired Pro", font=style_title2)
    lbl_hourstitle.place(relx=0.5, rely=0.25, anchor=CENTER)

    lbl_hours = ttkb.Label(frame_hoursc, text="Hours", font=style_title1)
    lbl_hours.place(relx=0.55, rely=0.4, anchor=CENTER)

    lbl_explain = ttkb.Label(frame_hoursc, text="*This will be used to count the Pro's payment fee.", font=style_text1)
    lbl_explain.place(relx=0.5, rely=0.55, anchor=CENTER)

    global entry_hoursc

    entry_hoursc = Entry(frame_hoursc, justify=RIGHT)
    entry_hoursc.place(relx=0.45, rely=0.4, anchor=CENTER, width=200, height=100)
    entry_hoursc.configure(font=style_title2)
    entry_hoursc.bind("<Return>", check_hoursc)

    style_btn_hoursc = ttkb.Style()
    style_btn_hoursc.configure("BtnOrder.dark.Outline.TButton", font=("Helvetica",15,"bold"))

    style_btn_hoursc.configure("BtnComplete.success.TButton", font=("Helvetica",15,"bold"))
    btn_hours = ttkb.Button(frame_hoursc, text="Confirm", width=20,  takefocus=False,style="BtnComplete.success.TButton")
    btn_hours.place(relx=0.5, rely=0.75, height=80, anchor=CENTER)
    btn_hours.bind("<Button-1>", check_hoursc)

# Function My Order client
def orderc():
    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    frame_orderc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_orderc.pack_propagate(False)
    frame_orderc.lift()

    client_myorder=open("client_myorder.txt","r")
    clientorder_content=client_myorder.read()
    clientorder_list=clientorder_content.split("\n")

    global pro_uid
    global pro_name
    global pro_email
    global pro_phone
    global pro_field
    global pro_skills
    global pro_rating
    global priceperhour
    global order_date
    # Try until get ValueError(cannot find value for variable), then show no order now
    try:
        frame_noorderc.place_forget()
        global client_uid
        client_idindex = clientorder_list.index(client_uid)
        # In txt file, if uid matches, show details under the uid
        if clientorder_list[client_idindex] == client_uid:
            client_idindex = clientorder_list.index(client_uid)
            client_uid = clientorder_list[client_idindex]
            pro_uid = clientorder_list[client_idindex+1]
            pro_name = clientorder_list[client_idindex+2]
            pro_email = clientorder_list[client_idindex+3]
            pro_phone = clientorder_list[client_idindex+4]
            pro_field = clientorder_list[client_idindex+5]
            pro_skills = clientorder_list[client_idindex+6]
            pro_rating = clientorder_list[client_idindex+7]
            priceperhour = clientorder_list[client_idindex+8]
            order_date = clientorder_list[client_idindex+9]

            lbl_profile = ttkb.Label(frame_orderc, text="Order Details", font=style_title2)
            lbl_profile.place(x=400, y=30)

            lbl_uid = ttkb.Label(frame_orderc, text="User ID:  " + pro_uid, font=style_button3)
            lbl_uid.place(x=420, y=130)
            lbl_name = ttkb.Label(frame_orderc, text="Name:  " + pro_name, font=style_button3)
            lbl_name.place(x=420, y=180)
            lbl_email = ttkb.Label(frame_orderc, text="Email:  " + pro_email, font=style_button3)
            lbl_email.place(x=420, y=230)
            lbl_phone = ttkb.Label(frame_orderc, text="Phone:  " + pro_phone, font=style_button3)
            lbl_phone.place(x=420, y=280)
            lbl_field = ttkb.Label(frame_orderc, text="Field:  " + pro_field, font=style_button3)
            lbl_field.place(x=420, y=330)
            lbl_skills = ttkb.Label(frame_orderc, text="Skill(s):  " + pro_skills, font=style_button3)
            lbl_skills.place(x=420, y=380)
            lbl_rating = ttkb.Label(frame_orderc, text="Ratings:  " + pro_rating    , font=style_button3)
            lbl_rating.place(x=420, y=430)
            lbl_fee = ttkb.Label(frame_orderc, text="Fee:  " + "RM"+str(priceperhour)+" / hour"    , font=style_button3)
            lbl_fee.place(x=420, y=480)
            lbl_date = ttkb.Label(frame_orderc, text="Order Date:  " + order_date    , font=style_button3)
            lbl_date.place(x=420, y=530)

            lbl_info = ttkb.Label(frame_orderc, text="* Please make sure the task/work/project"  , font=style_text3)
            lbl_info.place(relx=0.5, rely=0.64, anchor=CENTER)
            lbl_info2 = ttkb.Label(frame_orderc, text="  is fully completed before clicking this button."  , font=style_text3)
            lbl_info2.place(relx=0.5, rely=0.67, anchor=CENTER)

            style_btn_orderc = ttkb.Style()
            style_btn_orderc.configure("BtnOrder.dark.Outline.TButton", font=("Helvetica",15,"bold"))

            style_btn_orderc.configure("BtnComplete.success.TButton", font=("Helvetica",15,"bold"))
            btn_complete = ttkb.Button(frame_orderc, text="Task Completed!", width=20,  style="BtnComplete.success.TButton", takefocus=False,command=hoursc)
            btn_complete.place(relx=0.5, rely=0.75, height=80, anchor=CENTER)
    except ValueError:
        frame_noorderc.place(x=0, y=0, relheight=1, relwidth=1)
        frame_noorderc.pack_propagate(False)
        frame_noorderc.lift()

        lbl_noorder = ttkb.Label(frame_noorderc, text="There's no order now!", font=style_title2)
        lbl_noorder.place(relx=0.5, rely=0.4, anchor=CENTER)

# ---------- HISTORY Client -------------

# Function history client

def history_client():

    frame_historyc.place(x=0, y=0, relheight=1, relwidth=1)
    frame_historyc.pack_propagate(False)
    frame_historyc.lift()

    client_history=open("client_history.txt","r")
    clienthistory_content=client_history.read()
    clienthistory_list=clienthistory_content.split("\n")

    lbl_history = ttkb.Label(frame_historyc, text="Order History", font=style_title2)
    lbl_history.place(x=300,y=30)

    style_btn_refresh = ttkb.Style()
    style_btn_refresh.configure("BtnRefresh.dark.Outline.TButton", font=("Helvetica",15))
    btn_back = ttkb.Button(frame_historyc, text="Refresh", width=15,  style="BtnRefresh.dark.Outline.TButton", takefocus=False, command=history_client)
    btn_back.place(relx=0.8, y=30, height=80)

    sep = ttkb.Separator(frame_historyc, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=160, relwidth=1, anchor=CENTER)

    try:
        columns = ("order_date", "pro_uid", "pro_name", "pro_email", "pro_phone", "pro_field", "pro_skill","priceperhour", "total_payment")

        global client_history_table
        client_history_table = ttkb.Treeview(frame_historyc, bootstyle="dark", columns=columns, show="headings")
        client_history_table.place(relx=0.485, rely=0.55, anchor=CENTER, relwidth=0.95, relheight=0.6)

        hsb = ttkb.Scrollbar(frame_historyc, orient="horizontal", command=client_history_table.xview)
        hsb.place(relx=0.485, rely=0.858, relwidth=0.95, anchor=CENTER)

        vsb = ttkb.Scrollbar(frame_historyc, orient="vertical", command=client_history_table.yview)
        vsb.place(relx=0.96, rely=0.55, relheight=0.6, anchor=CENTER)

        client_history_table.configure(xscrollcommand=hsb.set)
        client_history_table.configure(yscrollcommand=vsb.set)

        client_history_table.heading('order_date', text="Order Date")
        client_history_table.heading('pro_uid', text="Pro UID")
        client_history_table.heading('pro_name', text="Pro Name")
        client_history_table.heading('pro_email', text="Pro Email")
        client_history_table.heading('pro_phone', text="Pro Phone")
        client_history_table.heading('pro_field', text="Pro Field")
        client_history_table.heading('pro_skill', text="Pro Skill")
        client_history_table.heading('priceperhour', text="Price per Hour")
        client_history_table.heading('total_payment', text="Total Payment")

        client_history_table.column("pro_email", minwidth=0, width=200, stretch=NO)
        client_history_table.column("pro_skill", minwidth=0, width=600, stretch=NO)

        history_client_list = []

        # Loop in range and append pro details into list
        for id_index in range(10,len(clienthistory_list),10):
            #client_uid = clienthistory_list[id_index]
            pro_uid = clienthistory_list[id_index+1]
            pro_name = clienthistory_list[id_index+2]
            pro_email = clienthistory_list[id_index+3]
            pro_phone = clienthistory_list[id_index+4]
            pro_field = clienthistory_list[id_index+5]
            pro_skill = clienthistory_list[id_index+6]
            priceperhour = clienthistory_list[id_index+7]
            total_payment = clienthistory_list[id_index+8]
            order_date = clienthistory_list[id_index+9]
            
            history_client_list.append((order_date, pro_uid, pro_name, pro_email, pro_phone, pro_field, pro_skill, priceperhour, total_payment))

        # Loop until all order details is inserted into table
        for order in history_client_list:
            client_history_table.insert("", END, values=order)

        columns = client_history_table["columns"]
        for column in columns:
            client_history_table.column(column, stretch=YES)
    except UnboundLocalError:
        lbl_noorder = ttkb.Label(frame_historyc, text="There's no previous order now~", font=style_title2)
        lbl_noorder.place(relx=0.5, rely=0.4, anchor=CENTER)

# ---------- LOGOUT Client ----------

# If client choose logout, set tab to defailt position then go to main
def logout_okc():
    homepagec.select(0)
    main()

# If client cancel logout, show home page
def logout_cancelc():
    homepagec.select(0)


frame_logoutc.place(relx=0.5, rely=0.4, anchor=CENTER)
frame_logoutc.pack_propagate(False)
frame_logoutc.configure(padx=20, pady=20, highlightbackground="black", highlightthickness=4)
frame_logoutc.lift()

lbl_bio = ttkb.Label(frame_logoutc, text="Are you sure to logout from your account?", font=style_button3)
lbl_bio.grid(row=0, column=0, columnspan=2)

btn_ok = Button(frame_logoutc, text="OK", width=15, height=3, font=style_button1, takefocus=False,command=logout_okc)
btn_ok.grid(row=1, column=0)

btn_cancel = Button(frame_logoutc, text="Cancel", width=15, height=3, font=style_button1, takefocus=False,command=logout_cancelc)
btn_cancel.grid(row=1, column=1)


# ---------- BROWSE (Client only) ----------

# Function back to filter(browse) page
def back_filter():
    # forget other frames(pages) and show filter(browse) frame(page)
    frame_proprofile.place_forget()
    frame_profile.place_forget()
    frame_filter.lift()

# Function show report complete
def reportchat_complete():
    frame_reportchat_complete = Frame(frame_parent_reportchat)

    frame_reportchat_complete.place(x=0, y=0, relheight=1, relwidth=1)
    frame_reportchat_complete.lift()

    lbl_report = ttkb.Label(frame_reportchat_complete, text="Report Submission Complete", font=style_text6)
    lbl_report.place(relx=0.05, rely=0.05)

    lbl_tq = ttkb.Label(frame_reportchat_complete, text="Thank you for your report", font=style_text6)
    lbl_tq.place(relx=0.5, rely=0.3, anchor=CENTER)

    lbl_ques = ttkb.Label(frame_reportchat_complete, text="We will make a thorough investigation into the matter.", font=style_text4)
    lbl_ques.place(relx=0.5, rely=0.38, anchor=CENTER)

    btn_close = ttkb.Button(frame_reportchat_complete, text="Close", width=20, style="BtnSubmit.dark.TButton", takefocus=False, command=lambda: frame_parent_chat.lift())
    btn_close.place(relx=0.5, rely=0.7, anchor=CENTER)

# Function check user input
def cbtn_report():

    reportchat=open("reportchat.txt","r")
    reportchat_content=reportchat.read()
    reportchat_list=reportchat_content.split("\n")
    # If user doesnt choose any reason, prompt user to choose at least one
    if not check_reason1.get() and not check_reason2.get() and not check_reason3.get() and not check_reason4.get() and not check_reason5.get() and not check_reason6.get(): 
            lbl_error = Label(frame_reportchat, text="Please choose or write a reason to report !", font=style_text3)
            lbl_error.place(relx=0.5, rely=0.83, anchor=CENTER)
            lbl_error.configure(fg="RED")
    else:
        lbl_error = Label(frame_reportchat, font=style_text3)
        lbl_error.place(relx=0.5, rely=0.83, anchor=CENTER)
        lbl_error.configure(text="                                                                    ")
        if textentry_other.get("1.0", "end-1c"):
            report_other = textentry_other.get("1.0", "end-1c")
        else:
            report_other = "na"
        # If value = 1, reason = reason showed on screen, else = na(not choosed)
        if check_reason1.get() == 1:
            report_chat1 = "Harassment and Bullying"
        if check_reason1.get() == 0:
            report_chat1 = "na"
        if check_reason2.get() == 1:
            report_chat2 = "Hate Speech or Discrimination"
        if check_reason2.get() == 0:
            report_chat2 = "na"
        if check_reason3.get() == 1:
            report_chat3 = "Spamming or Unsolicited Advertising"
        if check_reason3.get() == 0:
            report_chat3 = "na"
        if check_reason4.get() == 1:
            report_chat4 = "Violation of Community Guidelines"
        if check_reason4.get() == 0:
            report_chat4 = "na"
        if check_reason5.get() == 1:
            report_chat5 = "Impersonation or Identity Theft"
        if check_reason5.get() == 0:
            report_chat5 = "na"
        if check_reason6.get() == 1:
            report_chat6 = "Inappropriate or Offensive Behavior"
        if check_reason6.get() == 0:
            report_chat6 = "na"
        # Open report chat txt file and record user report in it
        reportchat=open("reportchat.txt","a")
        reportchat.write("\n"+user+"\n")
        reportchat.write(reported_user+"\n")
        reportchat.write(report_chat1+"\n")
        reportchat.write(report_chat2+"\n")
        reportchat.write(report_chat3+"\n")
        reportchat.write(report_chat4+"\n")
        reportchat.write(report_chat5+"\n")
        reportchat.write(report_chat6+"\n")
        reportchat.write(report_other)
        reportchat.close()

        # Call function after user complete report
        reportchat_complete()

# Function report user in chat
def reportchat(user_type):
    global user
    global reported_user
    # if user is client, reported user is pro, and vice versa
    if user_type == "client":
        user = client_uid
        reported_user = pro_uid
    elif user_type == "pro":
        user = pro_uid
        reported_user = client_uid

    global frame_parent_reportchat
    global frame_reportchat

    frame_parent_reportchat = ttkb.Frame(top)
    frame_reportchat = Frame(frame_parent_reportchat)

    frame_parent_reportchat.place(x=0, y=0, relheight=1, relwidth=1)
    frame_parent_reportchat.lift()

    frame_reportchat.place(relx=0.5, rely=0.5, width=1000, height=700, anchor=CENTER)
    frame_reportchat.configure(highlightbackground="black", highlightthickness=2)
    frame_reportchat.lift()

    lbl_success = ttkb.Label(frame_reportchat, text="Report User", font=style_text6)
    lbl_success.place(relx=0.05, rely=0.05)
    # Check buttons for user to choose reasons to report other user
    lbl_ques = ttkb.Label(frame_reportchat, text="Why do you want to report this user?", font=style_text4)
    lbl_ques.place(relx=0.05, rely=0.22)

    global check_reason1
    global check_reason2
    global check_reason3
    global check_reason4
    global check_reason5
    global check_reason6
    global textentry_other
    
    global cbtn_reason1
    global cbtn_reason2
    global cbtn_reason3
    global cbtn_reason4
    global cbtn_reason5
    global cbtn_reason6

    check_reason1 = IntVar()
    check_reason2 = IntVar()
    check_reason3 = IntVar()
    check_reason4 = IntVar()
    check_reason5 = IntVar()
    check_reason6 = IntVar()
    
    style_cbtn_reportchat = ttkb.Style()
    style_cbtn_reportchat.configure("BtnCbtn1.dark.TCheckbutton", font=("Helvetica",13))

    cbtn_reason1 = ttkb.Checkbutton(frame_reportchat,
                            text="Harassment or Bullying",
                            style="BtnCbtn1.dark.TCheckbutton",
                            variable=check_reason1,
                            onvalue=1,
                            offvalue=0,
                            )
    cbtn_reason1.place(relx=0.1, rely=0.3)
    
    cbtn_reason2 = ttkb.Checkbutton(frame_reportchat,
                            text="Hate Speech or Discrimination",
                            style="BtnCbtn1.dark.TCheckbutton",
                            variable=check_reason2,
                            onvalue=1,
                            offvalue=0,
                            )
    cbtn_reason2.place(relx=0.1, rely=0.4)
    
    cbtn_reason3 = ttkb.Checkbutton(frame_reportchat,
                            text="Spamming or Unsolicited Advertising",
                            style="BtnCbtn1.dark.TCheckbutton",
                            variable=check_reason3,
                            onvalue=1,
                            offvalue=0,
                            )
    cbtn_reason3.place(relx=0.1, rely=0.5)

    cbtn_reason4 = ttkb.Checkbutton(frame_reportchat,
                            text="Violation of Community Guidelines",
                            style="BtnCbtn1.dark.TCheckbutton",
                            variable=check_reason4,
                            onvalue=1,
                            offvalue=0,
                            )
    cbtn_reason4.place(relx=0.5, rely=0.3)
    
    cbtn_reason5 = ttkb.Checkbutton(frame_reportchat,
                            text="Impersonation or Identity Theft",
                            style="BtnCbtn1.dark.TCheckbutton",
                            variable=check_reason5,
                            onvalue=1,
                            offvalue=0,
                            )
    cbtn_reason5.place(relx=0.5, rely=0.4)
    
    cbtn_reason6 = ttkb.Checkbutton(frame_reportchat,
                            text="Inappropriate or Offensive Behavior",
                            style="BtnCbtn1.dark.TCheckbutton",
                            variable=check_reason6,
                            onvalue=1,
                            offvalue=0,
                            )
    cbtn_reason6.place(relx=0.5, rely=0.5)
                            
    lbl_other = ttkb.Label(frame_reportchat, text="Other:", font=style_text4)
    lbl_other.place(relx=0.05, rely=0.58)
    # Other for user to enter if other reasons to report
    textentry_other = Text(frame_reportchat, wrap="word", relief="sunken", font=style_text1)
    textentry_other.place(relx=0.05, rely=0.65, width=900, height=100)
    textentry_other.configure(highlightthickness=1)

    style_cbtn_reportchat.configure("BtnSubmit.dark.TButton", font=("Helvetica",18,"bold"))
    btn_confirm = ttkb.Button(frame_reportchat, text="Submit", width=20, style="BtnSubmit.dark.TButton", takefocus=False, command=cbtn_report)
    btn_confirm.place(relx=0.7, rely=0.9, anchor=CENTER)

    style_cbtn_reportchat.configure("BtnCancel.danger.Outline.TButton", font=("Helvetica",18,"bold"))
    btn_cancel = ttkb.Button(frame_reportchat, text="Cancel", width=20, style="BtnCancel.danger.Outline.TButton", takefocus=False, command=lambda: frame_parent_chat.lift())
    btn_cancel.place(relx=0.3, rely=0.9, anchor=CENTER)

# Fucntion conclusion(order details)
def conclusion():
    top.destroy()
    global myorderc
    myorderc = "y"
    client_myorder=open("client_myorder.txt","r")
    clientorder_content=client_myorder.read()
    clientorder_list=clientorder_content.split("\n")

    pro_myorder=open("pro_myorder.txt","r")
    proorder_content=pro_myorder.read()
    proorder_list=proorder_content.split("\n")
    # get what field pro is
    global field_index
    global skill_index
    if field_index == 8:
        pro_field = "Literature"
    if field_index == 9:
        pro_field = "Programming"
    if field_index == 10:
        pro_field = "Multimedia"
    # get current date time and set into format
    now = datetime.datetime.now()
    order_date = now.strftime('%d/%m/%Y  %H:%M:%S')

    proid_index = proprofile_list.index(pro_uid)
    pro_email = proprofile_list[proid_index+2]
    pro_phone = proprofile_list[proid_index+3]
    pro_field = pro_field
    pro_skills = proprofile_list[proid_index+skill_index]

    clientid_index = proprofile_list.index(pro_uid)
    # Pro email and phone as important details (for client to contact them)
    pro_email = proprofile_list[proid_index+2]
    pro_phone = proprofile_list[proid_index+3]

    # Open client and pro myorder txt file and write current respective order details into it
    client_myorder=open("client_myorder.txt","a")
    client_myorder.write("\n"+client_uid+"\n")
    client_myorder.write(pro_uid+"\n")
    client_myorder.write(pro_name+"\n")
    client_myorder.write(pro_email+"\n")
    client_myorder.write(pro_phone+"\n")
    client_myorder.write(pro_field+"\n")
    client_myorder.write(pro_skills+"\n")
    client_myorder.write(pro_rating+"\n")
    client_myorder.write(priceperhour+"\n")
    client_myorder.write(order_date)
    client_myorder.close()

    pro_myorder=open("pro_myorder.txt","a")
    pro_myorder.write("\n"+pro_uid+"\n")
    pro_myorder.write(client_uid+"\n")
    pro_myorder.write(client_name+"\n")
    pro_myorder.write(client_email+"\n")
    pro_myorder.write(client_phone+"\n")
    pro_myorder.write(pro_field+"\n")
    pro_myorder.write(priceperhour+"\n")
    pro_myorder.write(order_date)
    pro_myorder.close()

    # Call function to show current order details in both client and pro My Order tab
    orderc()
    orderp()
    # show My Order tab
    homepagec.select(4)

# Function close chat
def cancel_chat():
    top.destroy()

# Function accept or delcine pro
def acceptp():
    global client_name
    global pro_name

    client_ad = chatclient.get()
    pro_ad = chatpro.get()

    if pro_ad == "AcceptP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'{pro_name} had chosen ACCEPT !')
        chatbox_client.itemconfig(END, {'fg':'green'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'You had chosen ACCEPT !')
        chatbox_pro.itemconfig(END, {'fg':'green'})
        chatbox_pro.insert(END,"")

    elif pro_ad == "DeclineP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'{pro_name} had chosen DECLINE !')
        chatbox_client.itemconfig(END, {'fg':'red'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'You had chosen DECLINE !')
        chatbox_pro.itemconfig(END, {'fg':'red'})
        chatbox_pro.insert(END,"")


    if client_ad == "AcceptC" and pro_ad == "AcceptP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'<System> Order Accepted. Proceeding to Order details...')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'<System> Order Accepted. Proceeding to Order details...')
        chatbox_pro.itemconfig(END, {'fg':'grey'}) 
        chatbox_pro.insert(END,"")
        timer = threading.Timer(3, conclusion)
        timer.start()

    elif client_ad == "DeclineC" and pro_ad == "AcceptP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_pro.itemconfig(END, {'fg':'grey'}) 
        chatbox_pro.insert(END,"")
        timer = threading.Timer(3, cancel_chat)
        timer.start()

    elif client_ad == "AcceptC" and pro_ad == "DeclineP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_pro.itemconfig(END, {'fg':'grey'}) 
        chatbox_pro.insert(END,"")
        timer = threading.Timer(3, cancel_chat)
        timer.start()

    elif client_ad == "DeclineC" and pro_ad == "DeclineP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_pro.itemconfig(END, {'fg':'grey'}) 
        chatbox_pro.insert(END,"")
        timer = threading.Timer(3, cancel_chat)
        timer.start()
    else:
        pass
# Function accept or decline client
def acceptc():
    global client_name
    global pro_name
    # get value of a/d button from both chat
    client_ad = chatclient.get()
    pro_ad = chatpro.get()

    # if user choose accept button, msg will show on both chatbox saying user chooses accept in green clour, 
    # and vice versa in red colour if decline
    if client_ad == "AcceptC":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'You had chosen ACCEPT !')
        chatbox_client.itemconfig(END, {'fg':'green'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'{client_name} had chosen ACCEPT !')
        chatbox_pro.itemconfig(END, {'fg':'green'})
        chatbox_pro.insert(END,"")

    elif client_ad == "DeclineC":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'You had chosen DECLINE !')
        chatbox_client.itemconfig(END, {'fg':'red'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'{client_name} had chosen DECLINE !')
        chatbox_pro.itemconfig(END, {'fg':'red'})
        chatbox_pro.insert(END,"")
    # Call conclusion function if and only if both client and pro chooses ACCEPT
    # if either side or both sides chooses decline, then call function cancel_chat
    if client_ad == "AcceptC" and pro_ad == "AcceptP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'<System> Order Accepted. Proceeding to Order details...')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'<System> Order Accepted. Proceeding to Order details...')
        chatbox_pro.itemconfig(END, {'fg':'grey'}) 
        chatbox_pro.insert(END,"")
        # threading for setting a timer of 3s for user to read system msg before proceeding
        timer = threading.Timer(3, conclusion)
        timer.start()

    elif client_ad == "DeclineC" and pro_ad == "AcceptP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_pro.itemconfig(END, {'fg':'grey'}) 
        chatbox_pro.insert(END,"")
        timer = threading.Timer(3, cancel_chat)
        timer.start()

    elif client_ad == "AcceptC" and pro_ad == "DeclineP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_pro.itemconfig(END, {'fg':'grey'}) 
        chatbox_pro.insert(END,"")
        timer = threading.Timer(3, cancel_chat)
        timer.start()

    elif client_ad == "DeclineC" and pro_ad == "DeclineP":
        chatbox_client.insert(END,"")
        chatbox_client.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_client.insert(END,"")
        chatbox_pro.insert(END,"")
        chatbox_pro.insert(END,f'<System> Order cancelled. Closing chat...')
        chatbox_pro.itemconfig(END, {'fg':'grey'}) 
        chatbox_pro.insert(END,"")
        timer = threading.Timer(3, cancel_chat)
        timer.start()
    else:
        pass

# Function send msg from client chat
def sendmsg_client(send_msg_c):
    global msg_client
    msg_client = entry_client.get()
    entry_client.delete(0, END)

    if msg_client != "":

        msg_list_client.append(msg_client)
        chatbox_client.insert(END,f'<{client_name}> {msg_client}')

        msg_list_pro.append(msg_client)
        chatbox_pro.insert(END,f'<{client_name}> {msg_client}')

        global username
        username = "client"

        if username == "client":
            chatbox_client.itemconfig(END, {'fg':'blue'})
            chatbox_pro.itemconfig(END, {'fg':'black'})
        elif username == "pro":
            chatbox_client.itemconfig(END, {'fg':'black'})
            chatbox_pro.itemconfig(END, {'fg':'blue'})
# Function send msg from pro chat
def sendmsg_pro(send_msg_p):
    global msg_pro
    msg_pro = entry_pro.get()
    entry_pro.delete(0, END)
    # if msg is not empty
    if msg_pro != "":
        msg_list_pro.append(msg_pro)
        # insert pro msg in newline in both chatboxes
        chatbox_client.insert(END,f'<{pro_name}> {msg_pro}')

        msg_list_pro.append(msg_pro)
        chatbox_pro.insert(END,f'<{pro_name}> {msg_pro}')

        global username
        username = "pro"
        # get which user sends the msg: if in the sender's chatbox, text colour is blue, black vice versa
        if username == "client":
            chatbox_client.itemconfig(END, {'fg':'blue'})
            chatbox_pro.itemconfig(END, {'fg':'black'})
        elif username == "pro":
            chatbox_client.itemconfig(END, {'fg':'black'})
            chatbox_pro.itemconfig(END, {'fg':'blue'})
# Function insert system msg
def system_msg():
    # System msges
    system_msg1 = str(f'<System> *** Please read before chatting *** \n')
    system_msg2 = str(f'                 This is a temporary chat for Clients and Pros to have a short conversation')
    system_msg3 = str(f'                 about the task/project/work. The hiring process will only be confirmed')
    system_msg4 = str(f'                 when both Clients and Pros choose the "Accept" button below (hiring')
    system_msg5 = str(f'                 process will be cancelled when either or both sides choose the "Decline"')
    system_msg6 = str(f'                 button). After confirmation, an Order details page will appear on the Clients’')
    system_msg7 = str(f'                 side showing Pros’ contact information (email, phone). Clients can contact')
    system_msg8 = str(f'                 Pros by these contact information to have a more detailed discussion')
    system_msg9 = str(f'                 about the task/project/work. Please refrain from using vulgar words while')
    system_msg10 = str(f'                 chatting and kindly report any instances you came across.\n')
    # Create list and insert msgs into list
    system_msgall = [system_msg1,system_msg2,system_msg3,system_msg4,system_msg5,system_msg6,system_msg7,system_msg8,system_msg9,system_msg10]
    
    global chatbox_client
    global chatbox_pro
    # Loop until all msges in list are inserted into new lines while setting text color to grey
    for msg in system_msgall:
        chatbox_client.insert(END,f'{msg}\n')
        chatbox_client.itemconfig(END, {'fg':'grey'})
        chatbox_pro.insert(END,f'{msg}\n')
        chatbox_pro.itemconfig(END, {'fg':'grey'})

# Chat main function        
def chat():
    global top
    global frame_parent_chat
    global frame_chat_client
    global frame_chat_pro
    
    # Create new window
    top = Toplevel()
    top.title("Chat")
    # updates all changes(size etc.) made to the window(that dont require user interaction)
    top.update_idletasks()
    width = 1200
    height = 800
    # Find center position of window on screen
    x_offset = (top.winfo_screenwidth() - width) // 2
    y_offset = (top.winfo_screenheight() - height) // 2
    # Set position
    top.geometry(f"{width}x{height}+{x_offset}+{y_offset}")
    # Chat frames
    frame_parent_chat = ttkb.Frame(top)
    frame_chat_client = Frame(frame_parent_chat)
    frame_chat_pro = Frame(frame_parent_chat)

    frame_parent_chat.place(x=0, y=0, relheight=1, relwidth=1)

    # ----- Client Chat -----
    frame_chat_client.pack(side=LEFT, fill=BOTH, expand=True)
    frame_chat_client.configure(highlightbackground="black", highlightthickness=1)

    frame_top_client = Frame(frame_chat_client)
    frame_top_client.pack(fill=X, pady=10)

    lbl_client = Label(frame_top_client, text=pro_name, font=style_text4)
    lbl_client.place(relx=0.02)

    btn_report = ttkb.Button(frame_top_client, bootstyle="danger", text=" ! ", takefocus=False, command=lambda: reportchat("client"))
    btn_report.pack(side=RIGHT, padx=10, pady=5) 
    
    # Entry to send msg
    global entry_client
    entry_client = Entry(frame_chat_client)
    entry_client.place(relx=0.5, rely=0.73, anchor=CENTER, width=400, height=50)
    entry_client.configure(font=style_text3)
    entry_client.bind("<Return>", sendmsg_client)

    global icon_send
    icon_send = 'C:\VSCode\sem3 project\send.png'
    icon_send = PhotoImage(file='C:\VSCode\sem3 project\send.png')
    btn_send_c = ttkb.Button(frame_chat_client, image=icon_send, bootstyle="light",takefocus=False, command=sendmsg_client)
    btn_send_c.place(relx=0.9, rely=0.73, anchor=CENTER)
    btn_send_c.bind("<Button-1>", sendmsg_client)

    # string variable to get value(accept/decline)
    global chatclient
    chatclient = StringVar()

    style_btn_chat = ttkb.Style()
    style_btn_chat.configure("BtnChat.dark.Outline.TButton", font=("Helvetica",15,))

    style_btn_chat.configure("BtnAccept.success.Outline.Toolbutton", font=("Helvetica",15))
    rbtn_acceptc = ttkb.Radiobutton(frame_chat_client, text="Accept",
                                 style="BtnAccept.success.Outline.Toolbutton", 
                                 variable=chatclient, 
                                 value = "AcceptC",
                                 takefocus=False,
                                 command=acceptc
                                )
    rbtn_acceptc.place(relx=0.1, rely=0.8, width=200, height=50)

    style_btn_chat.configure("BtnDecline.danger.Outline.Toolbutton", font=("Helvetica",15))
    rbtn_declinec = ttkb.Radiobutton(frame_chat_client, text="Decline",
                                 style="BtnDecline.danger.Outline.Toolbutton", 
                                 variable=chatclient, 
                                 value = "DeclineC",
                                 takefocus=False,
                                 command=acceptc
                                )
    rbtn_declinec.place(relx=0.6, rely=0.8, width=200, height=50)

    global msg_list_client
    global chatbox_client

    msg_list_client = []

    frame_chatbox_c = Frame(frame_chat_client)
    frame_chatbox_c.pack(fill=X)

    scroll_c = Scrollbar(frame_chatbox_c, orient=VERTICAL)

    chatbox_client = Listbox(frame_chatbox_c, yscrollcommand=scroll_c.set)
    chatbox_client.configure(height=22)

    scroll_c.configure(command=chatbox_client.yview)
    scroll_c.pack(side=RIGHT, fill=Y)

    chatbox_client.pack(fill=X)

    # ----- Pro Chat -----
    frame_chat_pro.pack(side=RIGHT, fill=BOTH, expand=True)
    frame_chat_pro.configure(highlightbackground="black", highlightthickness=1)

    frame_top_pro = Frame(frame_chat_pro)
    frame_top_pro.pack(fill=X, pady=10)

    lbl_pro = Label(frame_top_pro, text=client_name, font=style_text4)
    lbl_pro.place(relx=0.02)

    btn_report = ttkb.Button(frame_top_pro, bootstyle="danger", text=" ! ", takefocus=False, command=lambda: reportchat("pro"))
    btn_report.pack(side=RIGHT, padx=10, pady=5) 

    global entry_pro
    entry_pro = Entry(frame_chat_pro)
    entry_pro.place(relx=0.5, rely=0.73, anchor=CENTER, width=400, height=50)
    entry_pro.configure(font=style_text3)
    entry_pro.bind("<Return>", sendmsg_pro)

    btn_send_p = ttkb.Button(frame_chat_pro, image=icon_send, bootstyle="light", takefocus=False,command=sendmsg_pro)
    btn_send_p.place(relx=0.9, rely=0.73, anchor=CENTER)
    btn_send_p.bind("<Button-1>", sendmsg_pro)

    global chatpro
    chatpro = StringVar()

    style_btn_chat.configure("BtnAccept.success.Outline.Toolbutton", font=("Helvetica",15))
    rbtn_acceptp = ttkb.Radiobutton(frame_chat_pro, text="Accept",
                                 style="BtnAccept.success.Outline.Toolbutton", 
                                 variable=chatpro, 
                                 value = "AcceptP",
                                 takefocus=False,
                                 command=acceptp
                                )
    rbtn_acceptp.place(relx=0.1, rely=0.8, width=200, height=50)

    style_btn_chat.configure("BtnDecline.danger.Outline.Toolbutton", font=("Helvetica",15))
    rbtn_declinep = ttkb.Radiobutton(frame_chat_pro, text="Decline",
                                 style="BtnDecline.danger.Outline.Toolbutton", 
                                 variable=chatpro, 
                                 value = "DeclineP",
                                 takefocus=False,
                                 command=acceptp
                                )
    rbtn_declinep.place(relx=0.6, rely=0.8, width=200, height=50)

    global msg_list_pro
    global chatbox_pro

    msg_list_pro = []
    frame_chatbox_p = Frame(frame_chat_pro)
    frame_chatbox_p.pack(fill=X)

    scroll_p = Scrollbar(frame_chatbox_p, orient=VERTICAL)

    chatbox_pro = Listbox(frame_chatbox_p, yscrollcommand=scroll_p.set)
    chatbox_pro.configure(height=22)

    scroll_p.configure(command=chatbox_pro.yview)
    scroll_p.pack(side=RIGHT, fill=Y)

    chatbox_pro.pack(fill=X)
    # call function to insert system msg everytime user opens chat
    system_msg()

# Ratings

# if X button clicked, close all rating frames
def close_rating():
    frame_ratings.place_forget()
    frame_ratingstop.place_forget()
    frame_ratingsbg.place_forget()

def ratings():
    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    pro_ratings=open("ratingnfeedback.txt","r")
    proratings_content=pro_ratings.read()
    proratings_list=proratings_content.split("\n")

    global frame_ratings
    global frame_ratingsbg
    global frame_ratingstop
    global pro_uid

    frame_ratingstop = Frame(frame_profile)
    frame_ratingstop.place(relx=0.72, rely=0.1, width=502)
    frame_ratingstop.configure(highlightbackground="black", highlightthickness=2)
    frame_ratingstop.lift()

    # outline frame
    frame_ratingsbg = Frame(frame_profile)
    frame_ratingsbg.place(relx=0.72, rely=0.17, width=502, height=502)
    frame_ratingsbg.configure(highlightbackground="black", highlightthickness=2)
    frame_ratingsbg.lift()

    # Scrolled frame to scroll
    frame_ratings = ScrolledFrame(frame_profile, autohide=FALSE)
    frame_ratings.place(relx=0.7215, rely=0.17, width=498, height=500)

    lbl_rating = Label(frame_ratingstop, text="Clients' Review", font=style_button2)
    lbl_rating.pack(padx=20, pady=20, side=LEFT)
    btn_x = ttkb.Button(frame_ratingstop, text="X", bootstyle="danger", takefocus=False,command=close_rating)
    btn_x.pack(side=RIGHT, padx=20, pady=5, ipadx=2) 

    # loop in range of rating list and show ratings that is under the chosen uid
    for id_index in range(6, len(proratings_list),6):
        if proratings_list[id_index] == pro_uid:
            uid = proratings_list[id_index]
            name = proratings_list[id_index+3]
            rating = proratings_list[id_index+4]
            feedback = proratings_list[id_index+5]

            frame_clientratings1 = Frame(frame_ratings)
            lbl_name = Label(frame_clientratings1, text=name, font=style_button2)
            lbl_name.pack(padx=20, pady=20, side=LEFT)
            lbl_rating = Label(frame_clientratings1, text=rating+" / 5.0", font=style_button2)
            lbl_rating.place(relx=0.7, rely=0.3)

            frame_clientratings2 = Frame(frame_ratings)
            lbl_feedback = Label(frame_clientratings2, text=feedback, font=style_button1)
            lbl_feedback.pack(padx=20, side=LEFT)
            frame_clientratings1.pack(fill=X, expand=TRUE)
            frame_clientratings2.pack(fill=X, expand=TRUE)
            sep = ttkb.Separator(frame_ratings, bootstyle="default", orient="horizontal")
            sep.pack(ipadx=200, pady=10)
        
# First button function
def proprofile_first():
    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    global field_index
    global skill_index
    global uid
    global id_index

    # id_index = 15(first uid index)
    uid = proprofile_list[15]
    id_index = proprofile_list.index(uid)

    uid = proprofile_list[id_index]
    name = proprofile_list[id_index+1]
    gender = proprofile_list[id_index+4]
    age = proprofile_list[id_index+5]
    bday = proprofile_list[id_index+6]
    bio = proprofile_list[id_index+7]
    skills = proprofile_list[id_index+skill_index]

    global pro_uid
    global pro_name
    pro_uid = uid
    pro_name = name

    pro_ratings=open("ratingnfeedback.txt","r")
    proratings_content=pro_ratings.read()
    proratings_list=proratings_content.split("\n")

    global pro_rating
    rating_list = []

    try:
        for pro_rating_index in range(6, len(proratings_list),6):
            if proratings_list[pro_rating_index] == pro_uid:
                rating = float(proratings_list[pro_rating_index+4])
                rating_list.append(rating)
        total_rating = sum(rating_list)
        avg_rating = total_rating / len(rating_list)
        final_rating = round(avg_rating,1)
        pro_rating = str(final_rating)
        btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, command=ratings)
        btn_rating.place(x=1050, y=800, height=80)
    except ZeroDivisionError:
        pro_rating = "No ratings yet"

        btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, state=DISABLED)
        btn_rating.place(x=1050, y=800, height=80)

    # Counting pro price per hour
    split_skills = skills.split(",")
    skill_count = len(split_skills)

    # Count "na" as 0
    skill_count -= split_skills.count("na")
    # Count bonus percentage by 5% per skill
    bonus = skill_count*0.05
    # Count price by RM10+bonus(per hour)
    global priceperhour
    priceperhour = "{:.2f}".format(10+(10*bonus))

    global lbl_name
    global lbl_biotext
    global lbl_skilltext

    lbl_uid = Label(frame_proprofile, text ="User ID:  "+uid+"                          ", font=style_button3)
    lbl_uid.place(x=30, y=30)
    lbl_name = Label(frame_proprofile, text ="Name:  "+name+"                               ", font=style_button3)
    lbl_name.place(x=30, y=80)

    lbl_price = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
    lbl_price.place(x=700, y=10, width=470, height=80)
    lbl_price.tag_configure("right", justify='right')
    lbl_price.insert("end", "RM"+str(priceperhour)+" / hour", "right")
    lbl_price.configure(highlightthickness=0, state=DISABLED)

    lbl_rating = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
    lbl_rating.place(x=700, y=100, width=470, height=90)
    lbl_rating.tag_configure("right", justify='right')
    lbl_rating.insert("end", pro_rating+" / 5.0 ☆", "right")
    lbl_rating.configure(highlightthickness=0, state=DISABLED)

    lbl_gender = Label(frame_proprofile, text ="Gender:  "+gender+"                               ", font=style_button3)
    lbl_gender.place(x=30, y=130)
    lbl_age = Label(frame_proprofile, text ="Age:  "+age+"                               ", font=style_button3)
    lbl_age.place(x=30, y=180)
    lbl_bday = Label(frame_proprofile, text ="Birthday:  "+bday+"                               ", font=style_button3)
    lbl_bday.place(x=30, y=230)

    sep = ttkb.Separator(frame_proprofile, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=290, relwidth=0.95, anchor=CENTER)

    lbl_skill = Label(frame_proprofile, text ="Skills: ", bg="#d0d6d6", font=style_button3)
    lbl_skill.place(x=30, y=300)

    lbl_skilltext = Text(frame_proprofile, wrap="word", relief="flat", width=50, font=style_button3)
    lbl_skilltext.place(x=130, y=300, width=1000, height=200)
    lbl_skilltext.insert("end", skills)
    lbl_skilltext.configure(highlightthickness=0, state=DISABLED)

    lbl_bio = Label(frame_proprofile, text ="Bio: ", font=style_button3)
    lbl_bio.place(x=30, y=440)
    
    lbl_biotext = Text(frame_proprofile, wrap="word", relief="sunken", width=50, font=style_button3)
    lbl_biotext.place(x=130, y=440, width=1050, height=200)
    lbl_biotext.insert("end", bio)
    lbl_biotext.configure(highlightthickness=0, state=DISABLED)

    style_btn_browse = ttkb.Style()
    style_btn_browse.configure("BtnBrowse.dark.Outline.TButton", font=("Helvetica",40,"bold"))

    style_btn_browse.configure("Btnchange.dark.Outline.TButton", font=("Helvetica",40,"bold"))
    btn_previous = ttkb.Button(frame_profile, text="<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_previous, state=DISABLED)
    btn_previous.place(relx=0.135, rely=0.45, anchor=CENTER, width=125, height=500)
    btn_next = ttkb.Button(frame_profile, text=">", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_next)
    btn_next.place(relx=0.87, rely=0.45, anchor=CENTER, width=125, height=500)
    
    btn_first = ttkb.Button(frame_profile, text="|<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_first, state=DISABLED)
    btn_first.place(relx=0.06, rely=0.45, anchor=CENTER, width=100, height=500)
    btn_last = ttkb.Button(frame_profile, text=">|", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_last)
    btn_last.place(relx=0.945, rely=0.45, anchor=CENTER, width=100, height=500)

# Last button function
def proprofile_last():
    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    global field_index
    global skill_index
    global uid
    global id_index
    # Find last uid index
    last_pro_index = len(proprofile_list) - 15
    id_index = last_pro_index

    while proprofile_list[id_index+field_index] == "n":
        id_index -=15
    uid = proprofile_list[id_index]
    name = proprofile_list[id_index+1]
    gender = proprofile_list[id_index+4]
    age = proprofile_list[id_index+5]
    bday = proprofile_list[id_index+6]
    bio = proprofile_list[id_index+7]
    skills = proprofile_list[id_index+skill_index]

    global pro_uid
    global pro_name
    pro_uid = uid
    pro_name = name

    pro_ratings=open("ratingnfeedback.txt","r")
    proratings_content=pro_ratings.read()
    proratings_list=proratings_content.split("\n")

    global pro_rating
    rating_list = []

    try:
        for pro_rating_index in range(6, len(proratings_list),6):
            if proratings_list[pro_rating_index] == pro_uid:
                rating = float(proratings_list[pro_rating_index+4])
                rating_list.append(rating)
        total_rating = sum(rating_list)
        avg_rating = total_rating / len(rating_list)
        final_rating = round(avg_rating,1)
        pro_rating = str(final_rating)
        btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, command=ratings)
        btn_rating.place(x=1050, y=800, height=80)
    except ZeroDivisionError:
        pro_rating = "No ratings yet"

        btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, state=DISABLED)
        btn_rating.place(x=1050, y=800, height=80)

    # Counting pro price per hour
    split_skills = skills.split(",")
    skill_count = len(split_skills)

    # Count "na" as 0
    skill_count -= split_skills.count("na")
    # Count bonus percentage by 5% per skill
    bonus = skill_count*0.05
    # Count price by RM10+bonus(per hour)
    global priceperhour
    priceperhour = "{:.2f}".format(10+(10*bonus))

    global lbl_name
    global lbl_biotext
    global lbl_skilltext

    lbl_uid = Label(frame_proprofile, text ="User ID:  "+uid+"                          ", font=style_button3)
    lbl_uid.place(x=30, y=30)
    lbl_name = Label(frame_proprofile, text ="Name:  "+name+"                               ", font=style_button3)
    lbl_name.place(x=30, y=80)

    lbl_price = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
    lbl_price.place(x=700, y=10, width=470, height=80)
    lbl_price.tag_configure("right", justify='right')
    lbl_price.insert("end", "RM"+str(priceperhour)+" / hour", "right")
    lbl_price.configure(highlightthickness=0, state=DISABLED)

    lbl_rating = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
    lbl_rating.place(x=700, y=100, width=470, height=90)
    lbl_rating.tag_configure("right", justify='right')
    lbl_rating.insert("end", pro_rating+" / 5.0 ☆", "right")
    lbl_rating.configure(highlightthickness=0, state=DISABLED)

    lbl_gender = Label(frame_proprofile, text ="Gender:  "+gender+"                               ", font=style_button3)
    lbl_gender.place(x=30, y=130)
    lbl_age = Label(frame_proprofile, text ="Age:  "+age+"                               ", font=style_button3)
    lbl_age.place(x=30, y=180)
    lbl_bday = Label(frame_proprofile, text ="Birthday:  "+bday+"                               ", font=style_button3)
    lbl_bday.place(x=30, y=230)

    sep = ttkb.Separator(frame_proprofile, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=290, relwidth=0.95, anchor=CENTER)

    lbl_skill = Label(frame_proprofile, text ="Skills: ", bg="#d0d6d6", font=style_button3)
    lbl_skill.place(x=30, y=300)

    lbl_skilltext = Text(frame_proprofile, wrap="word", relief="flat", width=50, font=style_button3)
    lbl_skilltext.place(x=130, y=300, width=1000, height=200)
    lbl_skilltext.insert("end", skills)
    lbl_skilltext.configure(highlightthickness=0, state=DISABLED)

    lbl_bio = Label(frame_proprofile, text ="Bio: ", font=style_button3)
    lbl_bio.place(x=30, y=440)
    
    lbl_biotext = Text(frame_proprofile, wrap="word", relief="sunken", width=50, font=style_button3)
    lbl_biotext.place(x=130, y=440, width=1050, height=200)
    lbl_biotext.insert("end", bio)
    lbl_biotext.configure(highlightthickness=0, state=DISABLED)

    style_btn_browse = ttkb.Style()
    style_btn_browse.configure("BtnBrowse.dark.Outline.TButton", font=("Helvetica",40,"bold"))

    style_btn_browse.configure("Btnchange.dark.Outline.TButton", font=("Helvetica",40,"bold"))
    btn_previous = ttkb.Button(frame_profile, text="<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_previous)
    btn_previous.place(relx=0.135, rely=0.45, anchor=CENTER, width=125, height=500)
    btn_next = ttkb.Button(frame_profile, text=">", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_next, state=DISABLED)
    btn_next.place(relx=0.87, rely=0.45, anchor=CENTER, width=125, height=500)
    
    btn_first = ttkb.Button(frame_profile, text="|<", style="Btnchange.dark.Outline.TButton",takefocus=False, command=proprofile_first )
    btn_first.place(relx=0.06, rely=0.45, anchor=CENTER, width=100, height=500)
    btn_last = ttkb.Button(frame_profile, text=">|", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_last, state=DISABLED)
    btn_last.place(relx=0.945, rely=0.45, anchor=CENTER, width=100, height=500)

# Next button function
def proprofile_next():

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    global field_index
    global skill_index
    global uid
    global id_index
    # +15 to id_index to next uid
    id_index = proprofile_list.index(uid)+15
    # +15 until find uid that is in the field
    try:
        while proprofile_list[id_index+field_index] == "n":
            id_index +=15
        uid = proprofile_list[id_index]
        name = proprofile_list[id_index+1]
        gender = proprofile_list[id_index+4]
        age = proprofile_list[id_index+5]
        bday = proprofile_list[id_index+6]
        bio = proprofile_list[id_index+7]
        skills = proprofile_list[id_index+skill_index]

        global pro_uid
        global pro_name
        pro_uid = uid
        pro_name = name

        pro_ratings=open("ratingnfeedback.txt","r")
        proratings_content=pro_ratings.read()
        proratings_list=proratings_content.split("\n")

        global pro_rating
        rating_list = []

        try:
            for pro_rating_index in range(6, len(proratings_list),6):
                if proratings_list[pro_rating_index] == pro_uid:
                    rating = float(proratings_list[pro_rating_index+4])
                    rating_list.append(rating)
            total_rating = sum(rating_list)
            avg_rating = total_rating / len(rating_list)
            final_rating = round(avg_rating,1)
            pro_rating = str(final_rating)
            btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, command=ratings)
            btn_rating.place(x=1050, y=800, height=80)
        except ZeroDivisionError:
            pro_rating = "No ratings yet"

            btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, state=DISABLED)
            btn_rating.place(x=1050, y=800, height=80)

        # Counting pro price per hour
        split_skills = skills.split(",")
        skill_count = len(split_skills)

        # Count "na" as 0
        skill_count -= split_skills.count("na")
        # Count bonus percentage by 5% per skill
        bonus = skill_count*0.05
        # Count price by RM10+bonus(per hour)
        global priceperhour
        priceperhour = "{:.2f}".format(10+(10*bonus))

        global lbl_name
        global lbl_biotext
        global lbl_skilltext

        lbl_uid = Label(frame_proprofile, text ="User ID:  "+uid+"                          ", font=style_button3)
        lbl_uid.place(x=30, y=30)
        lbl_name = Label(frame_proprofile, text ="Name:  "+name+"                               ", font=style_button3)
        lbl_name.place(x=30, y=80)

        lbl_price = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
        lbl_price.place(x=700, y=10, width=470, height=80)
        lbl_price.tag_configure("right", justify='right')
        lbl_price.insert("end", "RM"+str(priceperhour)+" / hour", "right")
        lbl_price.configure(highlightthickness=0, state=DISABLED)

        lbl_rating = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
        lbl_rating.place(x=700, y=100, width=470, height=90)
        lbl_rating.tag_configure("right", justify='right')
        lbl_rating.insert("end", pro_rating+" / 5.0 ☆", "right")
        lbl_rating.configure(highlightthickness=0, state=DISABLED)

        lbl_gender = Label(frame_proprofile, text ="Gender:  "+gender+"                               ", font=style_button3)
        lbl_gender.place(x=30, y=130)
        lbl_age = Label(frame_proprofile, text ="Age:  "+age+"                               ", font=style_button3)
        lbl_age.place(x=30, y=180)
        lbl_bday = Label(frame_proprofile, text ="Birthday:  "+bday+"                               ", font=style_button3)
        lbl_bday.place(x=30, y=230)

        sep = ttkb.Separator(frame_proprofile, bootstyle="default", orient="horizontal")
        sep.place(relx=0.5, y=290, relwidth=0.95, anchor=CENTER)

        lbl_skill = Label(frame_proprofile, text ="Skills: ", bg="#d0d6d6", font=style_button3)
        lbl_skill.place(x=30, y=300)

        lbl_skilltext = Text(frame_proprofile, wrap="word", relief="flat", width=50, font=style_button3)
        lbl_skilltext.place(x=130, y=300, width=1000, height=200)
        lbl_skilltext.insert("end", skills)
        lbl_skilltext.configure(highlightthickness=0, state=DISABLED)

        lbl_bio = Label(frame_proprofile, text ="Bio: ", font=style_button3)
        lbl_bio.place(x=30, y=440)
        
        lbl_biotext = Text(frame_proprofile, wrap="word", relief="sunken", width=50, font=style_button3)
        lbl_biotext.place(x=130, y=440, width=1050, height=200)
        lbl_biotext.insert("end", bio)
        lbl_biotext.configure(highlightthickness=0, state=DISABLED)

        style_btn_browse = ttkb.Style()
        style_btn_browse.configure("BtnBrowse.dark.Outline.TButton", font=("Helvetica",40,"bold"))

        style_btn_browse.configure("Btnchange.dark.Outline.TButton", font=("Helvetica",40,"bold"))
        btn_previous = ttkb.Button(frame_profile, text="<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_previous )
        btn_previous.place(relx=0.135, rely=0.45, anchor=CENTER, width=125, height=500)
        btn_next = ttkb.Button(frame_profile, text=">", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_next)
        btn_next.place(relx=0.87, rely=0.45, anchor=CENTER, width=125, height=500)
        
        btn_first = ttkb.Button(frame_profile, text="|<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_first )
        btn_first.place(relx=0.06, rely=0.45, anchor=CENTER, width=100, height=500)
        btn_last = ttkb.Button(frame_profile, text=">|", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_last)
        btn_last.place(relx=0.945, rely=0.45, anchor=CENTER, width=100, height=500)

        # if id_index = last index in txt file -15, disable next and last button
        last_pro_index = len(proprofile_list) - 15
        if id_index == last_pro_index:
            btn_next = ttkb.Button(frame_profile, text=">", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_next, state=DISABLED)
            btn_next.place(relx=0.87, rely=0.45, anchor=CENTER, width=125, height=500)
            btn_last = ttkb.Button(frame_profile, text=">|", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_last, state=DISABLED)
            btn_last.place(relx=0.945, rely=0.45, anchor=CENTER, width=100, height=500)
            pro_profile.close()
    # if index out of range, disable next and last button
    except IndexError:
        btn_next = ttkb.Button(frame_profile, text=">", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_next, state=DISABLED)
        btn_next.place(relx=0.87, rely=0.45, anchor=CENTER, width=125, height=500)
        btn_last = ttkb.Button(frame_profile, text=">|", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_last, state=DISABLED)
        btn_last.place(relx=0.945, rely=0.45, anchor=CENTER, width=100, height=500)
        pro_profile.close()


# Previous button function
def proprofile_previous():

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    global field_index
    global skill_index
    global uid
    global id_index

    # -15id_index until find previous uid that is in the chosen field
    id_index = proprofile_list.index(uid)-15

    while proprofile_list[id_index+field_index] == "n":
        id_index -=15
    uid = proprofile_list[id_index]
    name = proprofile_list[id_index+1]
    gender = proprofile_list[id_index+4]
    age = proprofile_list[id_index+5]
    bday = proprofile_list[id_index+6]
    bio = proprofile_list[id_index+7]
    skills = proprofile_list[id_index+skill_index]

    global pro_uid
    global pro_name
    pro_uid = uid
    pro_name = name

    pro_ratings=open("ratingnfeedback.txt","r")
    proratings_content=pro_ratings.read()
    proratings_list=proratings_content.split("\n")

    global pro_rating
    rating_list = []

    try:
        for pro_rating_index in range(6, len(proratings_list),6):
            if proratings_list[pro_rating_index] == pro_uid:
                rating = float(proratings_list[pro_rating_index+4])
                rating_list.append(rating)
        total_rating = sum(rating_list)
        avg_rating = total_rating / len(rating_list)
        final_rating = round(avg_rating,1)
        pro_rating = str(final_rating)
        btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, command=ratings)
        btn_rating.place(x=1050, y=800, height=80)
    except ZeroDivisionError:
        pro_rating = "No ratings yet"

        btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, state=DISABLED)
        btn_rating.place(x=1050, y=800, height=80)

    # Counting pro price per hour
    split_skills = skills.split(",")
    skill_count = len(split_skills)

    # Count "na" as 0
    skill_count -= split_skills.count("na")
    # Count bonus percentage by 5% per skill
    bonus = skill_count*0.05
    # Count price by RM10+bonus(per hour)
    global priceperhour
    priceperhour = "{:.2f}".format(10+(10*bonus))

    global lbl_name
    global lbl_biotext
    global lbl_skilltext

    lbl_uid = Label(frame_proprofile, text ="User ID:  "+uid+"                          ", font=style_button3)
    lbl_uid.place(x=30, y=30)
    lbl_name = Label(frame_proprofile, text ="Name:  "+name+"                               ", font=style_button3)
    lbl_name.place(x=30, y=80)

    lbl_price = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
    lbl_price.place(x=700, y=10, width=470, height=80)
    lbl_price.tag_configure("right", justify='right')
    lbl_price.insert("end", "RM"+str(priceperhour)+" / hour", "right")
    lbl_price.configure(highlightthickness=0, state=DISABLED)

    lbl_rating = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
    lbl_rating.place(x=700, y=100, width=470, height=90)
    lbl_rating.tag_configure("right", justify='right')
    lbl_rating.insert("end", pro_rating+" / 5.0 ☆", "right")
    lbl_rating.configure(highlightthickness=0, state=DISABLED)

    lbl_gender = Label(frame_proprofile, text ="Gender:  "+gender+"                               ", font=style_button3)
    lbl_gender.place(x=30, y=130)
    lbl_age = Label(frame_proprofile, text ="Age:  "+age+"                               ", font=style_button3)
    lbl_age.place(x=30, y=180)
    lbl_bday = Label(frame_proprofile, text ="Birthday:  "+bday+"                               ", font=style_button3)
    lbl_bday.place(x=30, y=230)

    sep = ttkb.Separator(frame_proprofile, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=290, relwidth=0.95, anchor=CENTER)

    lbl_skill = Label(frame_proprofile, text ="Skills: ", bg="#d0d6d6", font=style_button3)
    lbl_skill.place(x=30, y=300)

    lbl_skilltext = Text(frame_proprofile, wrap="word", relief="flat", width=50, font=style_button3)
    lbl_skilltext.place(x=130, y=300, width=1000, height=200)
    lbl_skilltext.insert("end", skills)
    lbl_skilltext.configure(highlightthickness=0, state=DISABLED)

    lbl_bio = Label(frame_proprofile, text ="Bio: ", font=style_button3)
    lbl_bio.place(x=30, y=440)
    
    lbl_biotext = Text(frame_proprofile, wrap="word", relief="sunken", width=50, font=style_button3)
    lbl_biotext.place(x=130, y=440, width=1050, height=200)
    lbl_biotext.insert("end", bio)
    lbl_biotext.configure(highlightthickness=0, state=DISABLED)

    style_btn_browse = ttkb.Style()
    style_btn_browse.configure("BtnBrowse.dark.Outline.TButton", font=("Helvetica",40,"bold"))

    style_btn_browse.configure("Btnchange.dark.Outline.TButton", font=("Helvetica",40,"bold"))
    btn_previous = ttkb.Button(frame_profile, text="<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_previous )
    btn_previous.place(relx=0.135, rely=0.45, anchor=CENTER, width=125, height=500)
    btn_next = ttkb.Button(frame_profile, text=">", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_next)
    btn_next.place(relx=0.87, rely=0.45, anchor=CENTER, width=125, height=500)
    
    btn_first = ttkb.Button(frame_profile, text="|<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_first )
    btn_first.place(relx=0.06, rely=0.45, anchor=CENTER, width=100, height=500)
    btn_last = ttkb.Button(frame_profile, text=">|", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_last)
    btn_last.place(relx=0.945, rely=0.45, anchor=CENTER, width=100, height=500)

    # if id_index = 15(first user uid), then disable previous and first button
    if id_index == 15 :
            btn_previous = ttkb.Button(frame_profile, text="<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_previous, state=DISABLED )
            btn_previous.place(relx=0.135, rely=0.45, anchor=CENTER, width=125, height=500)

            btn_first = ttkb.Button(frame_profile, text="|<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_first, state=DISABLED )
            btn_first.place(relx=0.06, rely=0.45, anchor=CENTER, width=100, height=500)
# Show pro profile function
def filter_proprofile(field):
    global field_index
    global skill_index

    field_index = field

    # Base frame
    frame_profile.place(x=0, y=0, relheight=1, relwidth=1)
    frame_profile.lift()
    # Profile frame
    frame_proprofile.place(relx=0.5, rely=0.45, anchor=CENTER)
    frame_proprofile.configure(height=650, width=1200, highlightbackground="black", highlightthickness=1)

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")
    # Each field index and skill represents each field and respective skills index in txt file
    if field_index == 8:
        skill_index = 11
        lbl_title = Label(frame_profile, text="Literature          ", font=style_title2)
        lbl_title.place(x=100, y=20)
    if field_index == 9:
        skill_index = 12
        lbl_title = Label(frame_profile, text="Programming         ", font=style_title2)
        lbl_title.place(x=100, y=20)
    if field_index == 10:
        skill_index = 13
        lbl_title = Label(frame_profile, text="Multimedia          ", font=style_title2)
        lbl_title.place(x=100, y=20)

    global uid
    global id_index
    # Start at index 15(as previous 0-14 are guidelines)
    uid = proprofile_list[15]
    id_index = proprofile_list.index(uid)

    style_btn_profile = ttkb.Style()
    style_btn_profile.configure("BtnProfile.dark.Outline.TButton", font=("Helvetica",15,"bold"))

    # Try until capture IndexError, and if captured == No pro in the field
    try:
        # Loop of idindex + 15 as field index value in txt file = "n"(No)
        while proprofile_list[id_index+field_index] == "n":
            id_index +=15
        uid = proprofile_list[id_index]
        name = proprofile_list[id_index+1]
        gender = proprofile_list[id_index+4]
        age = proprofile_list[id_index+5]
        bday = proprofile_list[id_index+6]
        bio = proprofile_list[id_index+7]
        skills = proprofile_list[id_index+skill_index]

        global pro_uid
        global pro_name
        pro_uid = uid
        pro_name = name

        pro_ratings=open("ratingnfeedback.txt","r")
        proratings_content=pro_ratings.read()
        proratings_list=proratings_content.split("\n")

        global pro_rating
        rating_list = []

        try:
            for pro_rating_index in range(6, len(proratings_list),6):
                if proratings_list[pro_rating_index] == pro_uid:
                    rating = float(proratings_list[pro_rating_index+4])
                    rating_list.append(rating)
            total_rating = sum(rating_list)
            avg_rating = total_rating / len(rating_list)
            final_rating = round(avg_rating,1)
            pro_rating = str(final_rating)
            btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, command=ratings)
            btn_rating.place(x=1050, y=800, height=80)
        except ZeroDivisionError:
            pro_rating = "No ratings yet"

            btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, state=DISABLED)
            btn_rating.place(x=1050, y=800, height=80)

        # Counting pro price per hour
        split_skills = skills.split(",")
        skill_count = len(split_skills)

        # Count "na" as 0
        skill_count -= split_skills.count("na")
        # Count bonus percentage by 5% per skill
        bonus = skill_count*0.05
        # Count price by RM10+bonus(per hour)
        global priceperhour
        priceperhour = "{:.2f}".format(10+(10*bonus))

        global lbl_name
        global lbl_biotext
        global lbl_skilltext

        lbl_uid = Label(frame_proprofile, text ="User ID:  "+uid+"                          ", font=style_button3)
        lbl_uid.place(x=30, y=30)
        lbl_name = Label(frame_proprofile, text ="Name:  "+name+"                               ", font=style_button3)
        lbl_name.place(x=30, y=80)

        lbl_price = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
        lbl_price.place(x=700, y=10, width=470, height=80)
        lbl_price.tag_configure("right", justify='right')
        lbl_price.insert("end", "RM"+str(priceperhour)+" / hour", "right")
        lbl_price.configure(highlightthickness=0, state=DISABLED)

        lbl_rating = Text(frame_proprofile, wrap="word", relief="flat", font=style_title2)
        lbl_rating.place(x=700, y=100, width=470, height=90)
        lbl_rating.tag_configure("right", justify='right')
        lbl_rating.insert("end", pro_rating+" / 5.0 ☆", "right")
        lbl_rating.configure(highlightthickness=0, state=DISABLED)

        lbl_gender = Label(frame_proprofile, text ="Gender:  "+gender+"                               ", font=style_button3)
        lbl_gender.place(x=30, y=130)
        lbl_age = Label(frame_proprofile, text ="Age:  "+age+"                               ", font=style_button3)
        lbl_age.place(x=30, y=180)
        lbl_bday = Label(frame_proprofile, text ="Birthday:  "+bday+"                               ", font=style_button3)
        lbl_bday.place(x=30, y=230)

        sep = ttkb.Separator(frame_proprofile, bootstyle="default", orient="horizontal")
        sep.place(relx=0.5, y=290, relwidth=0.95, anchor=CENTER)

        lbl_skill = Label(frame_proprofile, text ="Skills: ", bg="#d0d6d6", font=style_button3)
        lbl_skill.place(x=30, y=300)

        lbl_skilltext = Text(frame_proprofile, wrap="word", relief="flat", width=50, font=style_button3)
        lbl_skilltext.place(x=130, y=300, width=1000, height=200)
        lbl_skilltext.insert("end", skills)
        lbl_skilltext.configure(highlightthickness=0, state=DISABLED)

        lbl_bio = Label(frame_proprofile, text ="Bio: ", font=style_button3)
        lbl_bio.place(x=30, y=440)

        lbl_biotext = Text(frame_proprofile, wrap="word", relief="sunken", width=50, font=style_button3)
        lbl_biotext.place(x=130, y=440, width=1050, height=200)
        lbl_biotext.insert("end", bio)
        lbl_biotext.configure(highlightthickness=0, state=DISABLED)
        
        style_btn_browse = ttkb.Style()
        style_btn_browse.configure("BtnBrowse.dark.Outline.TButton", font=("Helvetica",40,"bold"))

        style_btn_browse.configure("Btnchange.dark.Outline.TButton", font=("Helvetica",40,"bold"))
        btn_previous = ttkb.Button(frame_profile, text="<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_previous, state=DISABLED)
        btn_previous.place(relx=0.135, rely=0.45, anchor=CENTER, width=125, height=500)
        btn_next = ttkb.Button(frame_profile, text=">", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_next)
        btn_next.place(relx=0.87, rely=0.45, anchor=CENTER, width=125, height=500)
        
        btn_first = ttkb.Button(frame_profile, text="|<", style="Btnchange.dark.Outline.TButton", takefocus=False,command=proprofile_first, state=DISABLED)
        btn_first.place(relx=0.06, rely=0.45, anchor=CENTER, width=100, height=500)
        btn_last = ttkb.Button(frame_profile, text=">|", style="Btnchange.dark.Outline.TButton",takefocus=False, command=proprofile_last)
        btn_last.place(relx=0.945, rely=0.45, anchor=CENTER, width=100, height=500)

        style_btn_profile.configure("BtnChoosePro.success.TButton", font=("Helvetica",20,"bold"))
        btn_choose = ttkb.Button(frame_profile, text="Choose this Pro", width=20,  style="BtnChoosePro.success.TButton", takefocus=False,command=chat)
        btn_choose.place(x=450, y=800, height=80)

        style_btn_profile.configure("BtnChoosePro.info.TButton", font=("Helvetica",20,"bold"))
        btn_rating = ttkb.Button(frame_profile, text="Clients' Review", width=20,  style="BtnChoosePro.info.TButton", takefocus=False, command=ratings)
        btn_rating.place(x=1050, y=800, height=80)
    except IndexError:
        lbl_empty = Label(frame_proprofile, text ="Unfortunately there's no Proffesionals in this field :(", bg="#d0d6d6", font=style_title2)
        lbl_empty.grid(row=0, column=0)
        lbl_empty.configure(bg="#ffffff")

    style_btn_profile.configure("Btnback.dark.Outline.TButton", font=("Helvetica",15))
    btn_back = ttkb.Button(frame_profile, text="Back", width=15,  style="Btnback.dark.Outline.TButton", takefocus=False,command=back_filter)
    btn_back.place(x=100, y=800, height=80)

# Frame filter functions
def browse():
    frame_filter.place(x=0, y=0, relheight=1, relwidth=1)
    frame_filter.tkraise()

    label_search = Label(frame_filter, text = "Please choose a field that you want to browse", font=style_title2)
    label_search.place(relx=0.5, y=80, anchor=CENTER)

    style_btn_filter = ttkb.Style()
    style_btn_filter.configure("BtnFilter.dark.Outline.TButton", font=("Times New Roman",20,"bold"))
                                                                                                                                    # Each button will carry different value as field index to next function
    btn_lit = ttkb.Button(frame_filter, text="Literature", width=30, style="BtnFilter.dark.Outline.TButton", takefocus=False, command=lambda: filter_proprofile(8))
    btn_lit.place(relx=0.19, rely=0.42, anchor=CENTER, width=570, height=470)

    btn_pgrm = ttkb.Button(frame_filter, text="Programming", width=30, style="BtnFilter.dark.Outline.TButton", takefocus=False, command=lambda: filter_proprofile(9))
    btn_pgrm.place(relx=0.5, rely=0.42, anchor=CENTER, width=570, height=470)

    btn_multi = ttkb.Button(frame_filter, text="Multimedia", width=30, style="BtnFilter.dark.Outline.TButton", takefocus=False, command=lambda: filter_proprofile(10))
    btn_multi.place(relx=0.81, rely=0.42, anchor=CENTER, width=570, height=470)

# ----- Show first frame when tab clicked -----

# If text on tab = respective, forget other frames and show the first ones
def show_framec(client_tab_clicked):
    current_tab = client_tab_clicked.widget.tab('current')['text']
    if current_tab == "Home":
        frame_search.place_forget()
        frame_homec.lift()
    elif current_tab == "Browse":
        frame_proprofile.place_forget()
        frame_profile.place_forget()
        frame_filter.lift()
    elif current_tab == "Task Striker Premium":
        id_index = clientlist.index(client_uid)
        if clientlist[id_index+3] == "n":
            frame_cancelconfirm.place_forget()
            frame_tspstatus.place_forget()
            frame_jointsp.place_forget()
            frame_membershipc.lift()
        if clientlist[id_index+3] == "y":
            frame_tspcomplete.place_forget()
            frame_membershipc.place_forget()
            frame_tspstatus.lift()
    elif current_tab == "Profile":
        frame_editprofilec.place_forget()
        frame_profilec.lift()
    elif current_tab == "History":
        frame_historyc.lift()

# Bind homepage tabs with mouse click to show first page of all tabs
homepagec.bind("<Button-1>", show_framec)


# ---------- Call Menu Client/Pro ----------

# menu client (call all homepage tab firstpage function first)
def menu_client():
    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    homepagec.lift()
    # Check whether client have join membership or not
    id_index = clientlist.index(client_uid)
    if clientlist[id_index+3] == "n":
        membershipc()
    elif clientlist[id_index+3] == "y":
        status_tsp()
    home_loginc()
    browse()
    profile_client()
    orderc()
    history_client()

# menu pro (call all homepage tab firstpage function first)
def menu_pro():
    homepagep.lift()
    home_loginp()
    profile_pro()
    orderp()
    history_pro()

# menu admin (call all homepage tab firstpage function first)
def menu_admin():
    homepagemin.lift()
    home_admin()

# ---------- Login Functions ----------

# Login validation function
def check_login():
    # Get input field value
    global entry_id
    global lbl_status

    uid = entry_id.get()
    pwd = entry_pwd.get()

    # Open txt file
    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    file_pro=open("prolist.txt","r")
    pro_content=file_pro.read()
    prolist=pro_content.split("\n")

    if not uid:
        entry_id.delete(0, END)
        entry_pwd.delete(0, END)
        lbl_status = Label(frame_login, text = "User ID or password incorrect!", font=style_texterror, bg="#d0d6d6")
        lbl_status.place(relx=0.5, y=750, anchor=CENTER)
        lbl_status.configure(fg='RED')
        return
    # Admin uid and pwd is hardcoded
    if uid == "admin123" and pwd == "369369369":
        # Admin login successful
        lbl_status = Label(frame_login, font=style_texterror)
        lbl_status.place(relx=0.5, y=750, anchor=CENTER)
        lbl_status.configure(text="                                                                    ")

        # Continue with admin actions
        print("Admin login successful")
        file_client.close()
        menu_admin()  # Replace `admin_menu()` with the function for admin actions

    if uid not in clientlist and uid not in prolist:
        entry_id.delete(0, END)
        entry_pwd.delete(0, END)
        lbl_status = Label(frame_login, text = "User ID or password incorrect!", font=style_texterror)
        lbl_status.place(relx=0.5, y=750, anchor=CENTER)
        lbl_status.configure(fg='RED')
        return
    if not pwd:
        entry_id.delete(0, END)
        entry_pwd.delete(0, END)
        lbl_status = Label(frame_login, text = "User ID or password incorrect!", font=style_texterror)
        lbl_status.place(relx=0.5, y=750, anchor=CENTER)
        lbl_status.configure(fg='RED')
        return
    else:
        # If account correct, continue to check whether user is client or pro
        if uid in clientlist:
            id_index = clientlist.index(uid)
            if pwd != clientlist[id_index+2]:
                entry_id.delete(0, END)
                entry_pwd.delete(0, END)
                lbl_status = Label(frame_login, text = "User ID or password incorrect!", font=style_texterror)
                lbl_status.place(relx=0.5, y=750, anchor=CENTER)
                lbl_status.configure(fg='RED')
                return
            else:
                lbl_status = Label(frame_login, font=style_texterror)
                lbl_status.place(relx=0.5, y=750, anchor=CENTER)
                lbl_status.configure(text="                                                                    ")

                global client_uid
                client_uid = uid
                global client_name
                client_name = clientlist[id_index+1]
                global client_pwd
                client_pwd = clientlist[id_index+2]

                # Close txt file then continue to home page.
                print("login successful")
                file_client.close()
                menu_client()
        elif uid in prolist:
            id_index = prolist.index(uid)
            if pwd != prolist[id_index+2]:
                entry_id.delete(0, END)
                entry_pwd.delete(0, END)
                lbl_status = Label(frame_login, text = "User ID or password incorrect!", font=style_texterror, bg="#d0d6d6")
                lbl_status.place(relx=0.5, y=750, anchor=CENTER)
                lbl_status.configure(fg='RED')
                return
            else:
                lbl_status = Label(frame_login, font=style_texterror, bg="#d0d6d6")
                lbl_status.place(relx=0.5, y=750, anchor=CENTER)
                lbl_status.configure(text="                                                                    ")

                global pro_uid
                pro_uid = uid
                global pro_name
                pro_name = prolist[id_index+1]
                global pro_pwd
                pro_pwd = prolist[id_index+2]

                # Close txt file then continue to home page.
                file_pro.close()
                menu_pro()

# Login function
def login():

    frame_login.grid(row=0, column=0, sticky="nsew")
    frame_login.grid_propagate(False)
    frame_login.tkraise()


    lbl_login = Label(frame_login, text = "Login to Task Striker Account", font=style_title2, padx=10, pady=10)
    lbl_login.place(relx=0.5, rely=0.1, anchor=CENTER)

    lbl_id = Label(frame_login, text = "User ID", font=style_text1, padx=10, pady=10)
    lbl_id.place(relx=0.3, y=300)
    lbl_pwd = Label(frame_login, text = "Password ", font=style_text1, padx=10, pady=10)
    lbl_pwd.place(relx=0.3, y=400)

    # global to pass it to other functions
    global entry_id
    global entry_pwd

    entry_id = Entry(frame_login)
    entry_id.place(relx=0.55, y=330, width=500, height=50, anchor=CENTER)

    entry_pwd = Entry(frame_login)
    entry_pwd.place(relx=0.55, y=430, width=500, height=50, anchor=CENTER)

    entry_id.configure(font=style_text1)
    entry_pwd.configure(font=style_text1, show="*")

    style_btn_login = ttkb.Style()
    style_btn_login.configure("BtnLogin.dark.TButton", font=("Helvetica",15,"bold"))

    btn_login = ttkb.Button(frame_login, text="Login", width=20,  style="BtnLogin.dark.TButton", takefocus=False, command=check_login)
    btn_login.place(relx=0.5, y=840, height=80, anchor=CENTER)

    style_btn_login.configure("Btnback.dark.Outline.TButton", font=("Helvetica",15))
    btn_back = ttkb.Button(frame_login, text="Back", width=15,  style="Btnback.dark.Outline.TButton", takefocus=False, command=lambda: frame_main.tkraise())
    btn_back.place(x=100, y=800, height=80)

# ---------- Register Functions ----------


# ----- Client Register Functions -----

# Frame after user completed account registration
def register_complete():
    frame_register_complete.place(x=0, y=0, relheight=1, relwidth=1)
    frame_register_complete.pack_propagate(False)
    frame_register_complete.lift()

    lbl_complete = ttkb.Label(frame_register_complete, text="Account Register Complete", font=style_title2)
    lbl_complete.place(x=200,y=30)

    lbl_welcome = ttkb.Label(frame_register_complete, text="Welcome to Task Striker !", font=style_title3)
    lbl_welcome.place(relx=0.5, rely=0.3, anchor=CENTER)
    lbl_info = ttkb.Label(frame_register_complete, text="Please click 'Continue' to login to our platform and start exploring!", font=style_title1)
    lbl_info.place(relx=0.5, rely=0.4, anchor=CENTER)

    # Button navigate to login
    style_btn_rcomplete = ttkb.Style()
    style_btn_rcomplete.configure("BtnContinue.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    btn_back = ttkb.Button(frame_register_complete, text="Continue", width=15,  style="BtnContinue.dark.Outline.TButton", takefocus=False,command=login)
    btn_back.place(relx=0.5, rely=0.85, anchor=CENTER, width=500, height=100)

# btn_submit Function

def check_submitc():

    # Get input field value
    global name
    global uid
    global pwd

    name = entry_name.get()
    uid = entry_id.get()
    pwd = entry_pwd.get()
    pwdconfirm = entry_pwdconfirm.get()

    # Open txt file
    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    # Create list for later status value append
    status_list = []

    # Check whether input value fulfill requirements
    if not name:
        status_list.append("name_empty")
    if not uid:
        status_list.append("id_empty")
    if uid in clientlist or uid in prolist:
        status_list.append("id_exist")
    if not pwd:
        status_list.append("pwd_empty")
    if not pwdconfirm:
        status_list.append("pwdconfirm_empty")
    if len(pwd) < 8:
        status_list.append("pwd_small")
    elif pwdconfirm != pwd:
        status_list.append("pwd_wrong")

    # if value in status list
    if status_list:

        # Create, place, and configure label ori value for error message
        lbl_errorname = Label(frame_registerc, text = "                                                  ", font=style_texterror, bg="#d0d6d6")
        lbl_errorname.place(x=950, y=280)
        lbl_errorname.configure(fg='RED')
        lbl_errorid = Label(frame_registerc, text = "                                                  ", font=style_texterror, bg="#d0d6d6")
        lbl_errorid.place(x=950, y=360)
        lbl_errorid.configure(fg='RED')
        lbl_errorpwd = Label(frame_registerc, text = "                                                                       ", font=style_texterror, bg="#d0d6d6")
        lbl_errorpwd.place(x=950, y=440)
        lbl_errorpwd.configure(fg='RED')
        lbl_errorpwdconfirm = Label(frame_registerc, text = "                                                                   ", font=style_texterror, bg="#d0d6d6")
        lbl_errorpwdconfirm.place(x=950, y=520)
        lbl_errorpwdconfirm.configure(fg='RED')
        lbl_status = Label(frame_registerc, text = "                                        ", font=style_texterror, bg="#d0d6d6")
        lbl_status.place(x=830, y=750)
        lbl_status.configure(fg='RED')

        # for loop that shows error message below respective input field until fulfill requirements
        for status in status_list:
            if status == "name_empty":
                entry_name.delete(0, END)
                lbl_errorname = Label(frame_registerc, font=style_texterror, bg="#d0d6d6")
                lbl_errorname.place(x=950, y=280)
                lbl_errorname.configure(fg='RED', text = "Name cannot be empty.")
            if status == "id_empty":
                entry_id.delete(0, END)
                lbl_errorid = Label(frame_registerc, font=style_texterror, bg="#d0d6d6")
                lbl_errorid.place(x=950, y=360)
                lbl_errorid.configure(fg='RED', text = "User ID cannot be empty.        ")
            if status == 'id_exist':
                entry_id.delete(0, END)
                lbl_errorid = Label(frame_registerc, font=style_texterror, bg="#d0d6d6")
                lbl_errorid.place(x=950, y=360)
                lbl_errorid.configure(fg='RED', text = "User ID already exist.     ")
            if status == "pwd_empty":
                entry_pwd.delete(0, END)
                lbl_errorpwd = Label(frame_registerc, font=style_texterror, bg="#d0d6d6")
                lbl_errorpwd.place(x=950, y=440)
                lbl_errorpwd.configure(fg='RED', text = "Password cannot be empty.      ")
            if status == "pwdconfirm_empty":
                entry_pwdconfirm.delete(0, END)
                lbl_errorpwdconfirm = Label(frame_registerc, font=style_texterror, bg="#d0d6d6")
                lbl_errorpwdconfirm.place(x=950, y=520)
                lbl_errorpwdconfirm.configure(fg='RED', text = "Password confirmation cannot be empty.       ")
            if status == "pwd_small":
                entry_pwd.delete(0, END)
                entry_pwdconfirm.delete(0, END)
                lbl_errorpwd = Label(frame_registerc, font=style_texterror, bg="#d0d6d6")
                lbl_errorpwd.place(x=950, y=440)
                lbl_errorpwd.configure(fg='RED', text = "Password must be 8 characters or more.     ")
            if status == "pwd_wrong":
                entry_pwd.delete(0, END)
                entry_pwdconfirm.delete(0, END)
                lbl_errorpwdconfirm = Label(frame_registerc, font=style_texterror, bg="#d0d6d6")
                lbl_errorpwdconfirm.place(x=950, y=520)
                lbl_errorpwdconfirm.configure(fg='RED', text = "Password confirmation failed. Please try again.")
        lbl_status = Label(frame_registerc, text = "*** Please check input.", font=style_texterror, bg="#d0d6d6")
        lbl_status.place(x=830, y=750)
        lbl_status.configure(fg='RED')
        return
    # Break loop(when fulfill requirements)
    
    lbl_errorname = Label(frame_registerc, font=style_texterror)
    lbl_errorname.place(x=950, y=280)
    lbl_errorname.configure(text = "                                                                    ")
    lbl_errorid = Label(frame_registerc, font=style_texterror)
    lbl_errorid.place(x=950, y=360)
    lbl_errorid.configure(text="                                                                    ")
    lbl_errorpwd = Label(frame_registerc, font=style_texterror)
    lbl_errorpwd.place(x=950, y=440)
    lbl_errorpwd.configure(text="                                                                    ")
    lbl_errorpwdconfirm = Label(frame_registerc, font=style_texterror)
    lbl_errorpwdconfirm.place(x=950, y=520)
    lbl_errorpwdconfirm.configure(text="                                                                             ")
    lbl_status = Label(frame_registerc, font=style_texterror)
    lbl_status.place(x=830, y=750)
    lbl_status.configure(text="                                                                     ")

    tsp_status = "n"
    tsp_date = "d/m/y"

    # Open txt file and append new user information, then close txt file and continue to home page.
    file_client=open("clientlist.txt","a")
    file_client.write("\n"+uid+"\n")
    file_client.write(name+"\n")
    file_client.write(pwd+"\n")
    file_client.write(tsp_status+"\n")
    file_client.write(tsp_date+"\n")
    file_client.write(user)
    file_client.close()

    global phone
    global gender
    global age
    global bday
    global bio
    
    email = "na"
    phone = "na"
    gender = "na"
    age = "na"
    bday = "na"
    bio = "na"

    # Open txt file and append new client details in new lines
    client_profile=open("client_profile.txt","a")
    client_profile.write("\n"+uid+"\n")
    client_profile.write(name+"\n")
    client_profile.write(email+"\n")
    client_profile.write(phone+"\n")
    client_profile.write(gender+"\n")
    client_profile.write(age+"\n")
    client_profile.write(bday+"\n")
    client_profile.write(bio)
    client_profile.close()

    # Call function after all completed
    register_complete()

# Register for Client
def register_client():

    # User type = "C"lient
    global user
    user = "c"

    frame_registerc.grid(row=0, column=0, sticky="nsew")
    frame_registerc.grid_propagate(False)
    frame_registerc.configure()
    frame_registerc.tkraise()

    # Create, place, and configure label initial value for error message
    lbl_errorname = Label(frame_registerc, text = "                                                  ", font=style_texterror, bg="#d0d6d6")
    lbl_errorname.place(x=950, y=280)
    lbl_errorname.configure(fg='RED')
    lbl_errorid = Label(frame_registerc, text = "                                                  ", font=style_texterror, bg="#d0d6d6")
    lbl_errorid.place(x=950, y=360)
    lbl_errorid.configure(fg='RED')
    lbl_errorpwd = Label(frame_registerc, text = "                                                                       ", font=style_texterror, bg="#d0d6d6")
    lbl_errorpwd.place(x=950, y=440)
    lbl_errorpwd.configure(fg='RED')
    lbl_errorpwdconfirm = Label(frame_registerc, text = "                                                                   ", font=style_texterror, bg="#d0d6d6")
    lbl_errorpwdconfirm.place(x=950, y=520)
    lbl_errorpwdconfirm.configure(fg='RED')
    lbl_status = Label(frame_registerc, text = "                                        ", font=style_texterror, bg="#d0d6d6")
    lbl_status.place(x=830, y=750)
    lbl_status.configure(fg='RED')

    # Widgets creating and positioning etc.
    lbl_register = Label(frame_registerc, text = "Create a TSP account", font=style_title2, bg="#d0d6d6", padx=10, pady=10)
    lbl_register.place(x=625,y=50)

    lbl_name = Label(frame_registerc, text = "Name  ", bg="#d0d6d6", font=style_text2, padx=10, pady=10)
    lbl_id = Label(frame_registerc, text = "User ID", bg="#d0d6d6", font=style_text2, padx=10, pady=10)
    lbl_pwd = Label(frame_registerc, text = "Password (8 or more characters) ", font=style_text2, bg="#d0d6d6", padx=10, pady=10)
    lbl_pwdconfirm = Label(frame_registerc, text = "Password Confirmation", font=style_text2, bg="#d0d6d6", padx=10, pady=10)

    lbl_name.place(x=450, y=230)
    lbl_id.place(x=450, y=310)
    lbl_pwd.place(x=450, y=390)
    lbl_pwdconfirm.place(x=450, y=470)

    global entry_name
    global entry_id
    global entry_pwd
    global entry_pwdconfirm

    entry_name = Entry(frame_registerc)
    entry_id = Entry(frame_registerc)
    entry_pwd = Entry(frame_registerc)
    entry_pwdconfirm = Entry(frame_registerc)

    entry_name.place(x=950, y=235, width=450, height=40)
    entry_id.place(x=950, y=315, width=450, height=40)
    entry_pwd.place(x=950, y=395, width=450, height=40)
    entry_pwdconfirm.place(x=950, y=475, width=450, height=40)

    entry_name.configure(font=style_text1)
    entry_id.configure(font=style_text1)
    entry_pwd.configure(font=style_text1, show="*")
    entry_pwdconfirm.configure(font=style_text1, show="*")

    style_btn_registerc = ttkb.Style()
    style_btn_registerc.configure("BtnRC.dark.TButton", font=("Helvetica",15,"bold"))
    btn_submit = ttkb.Button(frame_registerc, text="Create", width=20,  style="BtnRC.dark.TButton", takefocus=False, command=check_submitc)
    btn_submit.place(relx=0.5, rely=0.775, height=80, anchor=CENTER)

    style_btn_registerc.configure("Btnback.dark.Outline.TButton", font=("Helvetica",15))
    btn_back = ttkb.Button(frame_registerc, text="Back", width=15,  style="Btnback.dark.Outline.TButton", takefocus=False, command=lambda: frame_choosecp.tkraise())
    btn_back.place(x=100, y=800, height=80)


# ----- Pro Register Functions -----

# Fucntion to validate inputs in start_edit_profilep
def check_startp():
    # Open nessesary txt file
    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    client_profile=open("client_profile.txt","r")
    clientprofile_content=client_profile.read()
    clientprofile_list=clientprofile_content.split("\n")

    # Get birthday from date entry
    pro_bday = entry_bdayp.entry.get()
    # Change input from str to date format
    pro_bday = datetime.datetime.strptime(pro_bday, "%d/%m/%Y").date()
    # Get today's date
    today = date.today()
    # Calculate age by substracting today's date's year and birthday date year
    # then substract a Boolean(1/0) that represents if today's day/month precedes the birth day/month
    pro_age = today.year - pro_bday.year - ((today.month, today.day) < (pro_bday.month, pro_bday.day))

    # Create empty list
    startp_status = []
    # Append entry status into list if fulfill error requirements
    if not entry_namep.get():
        startp_status.append("name_empty")
    if not entry_emailp.get():
        startp_status.append("email_empty")
    if entry_emailp.get() in clientprofile_list or entry_emailp.get() in proprofile_list:
        startp_status.append("email_exist")
    if not entry_phonep.get():
        startp_status.append("phone_empty")
    if entry_phonep.get() in clientprofile_list or entry_phonep.get() in proprofile_list:
        startp_status.append("phone_exist")
    if check_lit.get() + check_pgrm.get() + check_multi.get() == 0:
        startp_status.append("field_empty")
    if pro_age < 19:
        startp_status.append("age_small")

    # If in list
    if startp_status:
        # Initial value for lbl error msges
        lbl_errorname = Label(frame_startp, font=style_texterror)
        lbl_errorname.place(x=480, y=280)
        lbl_errorname.configure(fg='RED', text = "                       ")
        lbl_erroremail = Label(frame_startp, font=style_texterror)
        lbl_erroremail.place(x=590, y=370)
        lbl_erroremail.configure(fg='RED', text = "                                                          ")
        lbl_errorphone = Label(frame_startp, font=style_texterror)
        lbl_errorphone.place(x=600, y=455)
        lbl_errorphone.configure(fg='RED', text = "                                                          ")
        lbl_errorfield = Label(frame_startp, font=style_texterror)
        lbl_errorfield.place(x=1250, y=575, anchor=CENTER)
        lbl_errorfield.configure(fg='RED', text = "                                                           ")
        lbl_errorage = Label(frame_startp, font=style_texterror)
        lbl_errorage.place(x=1035, y=340, anchor=CENTER)
        lbl_errorage.configure(fg='RED', text = "                                                                    ")
        lbl_age = ttkb.Label(frame_startp, text="Age: "+str(pro_age)+"                 " , font=style_button3)
        lbl_age.place(x=700, y=320)
        lbl_status = Label(frame_startp, font=style_texterror)
        lbl_status.place(relx=0.8, rely=0.75, anchor=CENTER)
        lbl_status.configure(fg='RED', text = "                                             ")
        # Loop to show error msges until all requirements are fulfill
        for status in startp_status:
            if status == "name_empty":
                lbl_errorname = Label(frame_startp, font=style_texterror)
                lbl_errorname.place(x=480, y=280)
                lbl_errorname.configure(fg='RED', text = "Please enter name!     ")
            if status == "email_empty":
                lbl_erroremail = Label(frame_startp, font=style_texterror)
                lbl_erroremail.place(x=590, y=370)
                lbl_erroremail.configure(fg='RED', text = "Please enter email address!       ")
            if status == "email_exist":
                lbl_erroremail = Label(frame_startp, font=style_texterror)
                lbl_erroremail.place(x=590, y=370)
                lbl_erroremail.configure(fg='RED', text = "Email address already exist!       ")
            if status == "phone_empty":
                lbl_errorphone = Label(frame_startp, font=style_texterror)
                lbl_errorphone.place(x=600, y=455)
                lbl_errorphone.configure(fg='RED', text = "Please enter phone number!        ")
            if status == "phone_exist":
                lbl_errorphone = Label(frame_startp, font=style_texterror)
                lbl_errorphone.place(x=600, y=455)
                lbl_errorphone.configure(fg='RED', text = "Phone number already exist!       ")
            if status == "field_empty":
                lbl_errorfield = Label(frame_startp, font=style_texterror)
                lbl_errorfield.place(x=1250, y=575, anchor=CENTER)
                lbl_errorfield.configure(fg='RED', text = "*** Please choose at least 1 field !")
            if status == "age_small":
                lbl_age = ttkb.Label(frame_startp, text="Age: "+str(pro_age)+"                 " , font=style_button3)
                lbl_age.place(x=700, y=320)
                lbl_errorage = Label(frame_startp, font=style_texterror)
                lbl_errorage.place(x=1035, y=340, anchor=CENTER)
                lbl_errorage.configure(fg='RED', text = "You need to be above 18 years old to be a Pro!")
        lbl_status = Label(frame_startp, font=style_texterror)
        lbl_status.place(relx=0.8, rely=0.75, anchor=CENTER)
        lbl_status.configure(fg='RED', text = "*** Please check input")
        return
    # if all requirements fulfilled, all lbl error msges will disappear
    lbl_errorname = Label(frame_startp, font=style_texterror)
    lbl_errorname.place(x=480, y=280)
    lbl_errorname.configure(fg='RED', text = "                     ")
    lbl_erroremail = Label(frame_startp, font=style_texterror)
    lbl_erroremail.place(x=590, y=370)
    lbl_erroremail.configure(fg='RED', text = "                                                          ")
    lbl_errorphone = Label(frame_startp, font=style_texterror)
    lbl_errorphone.place(x=600, y=455)
    lbl_errorphone.configure(fg='RED', text = "                                                          ")
    lbl_errorfield = Label(frame_startp, font=style_texterror)
    lbl_errorfield.place(x=1250, y=575, anchor=CENTER)
    lbl_errorfield.configure(fg='RED', text = "                                                           ")
    lbl_errorage = Label(frame_startp, font=style_texterror)
    lbl_errorage.place(x=1035, y=340, anchor=CENTER)
    lbl_errorage.configure(fg='RED', text = "                                                                      ")
    lbl_age = ttkb.Label(frame_startp, text="Age: "+str(pro_age)+"                 " , font=style_button3)
    lbl_age.place(x=700, y=320)
    lbl_status = Label(frame_startp, font=style_texterror)
    lbl_status.place(relx=0.8, rely=0.75, anchor=CENTER)
    lbl_status.configure(fg='RED', text = "                                             ")

    global name
    global phone
    global gender
    global age
    global bday
    global bio
    global lit
    global pgrm
    global multi
    global skill_lit1
    global skill_lit2
    global skill_lit3
    global skill_pgrm1
    global skill_pgrm2
    global skill_pgrm3
    global skill_multi1
    global skill_multi2
    global skill_multi3
    global rating

    # Get optional details. If no value, value=na in txtfile, else will be its value gotten
    if not entry_genderp.get():
        gender = "na"
    else:
        gender = entry_genderp.get()
    if not entry_biop.get("1.0", "end-1c"):
        bio = "na"
    else:
        bio = entry_biop.get("1.0", "end-1c")

    if entry_litskill1.get() == "":
        skill_lit1 = "na"
    else:
        skill_lit1 = entry_litskill1.get()
    if entry_litskill2.get() == "":
        skill_lit2 = "na"
    else:
        skill_lit2 = entry_litskill2.get()
    if entry_litskill3.get() == "":
        skill_lit3 = "na"
    else:
        skill_lit3 = entry_litskill3.get()
    if entry_pgrmskill1.get() == "":
        skill_pgrm1 = "na"
    else:
        skill_pgrm1 = entry_pgrmskill1.get()
    if entry_pgrmskill2.get() == "":
        skill_pgrm2 = "na"
    else:
        skill_pgrm2 = entry_pgrmskill2.get()
    if entry_pgrmskill3.get() == "":
        skill_pgrm3 = "na"
    else:
        skill_pgrm3 = entry_pgrmskill3.get()
    if entry_multiskill1.get() == "":
        skill_multi1 = "na"
    else:
        skill_multi1 = entry_multiskill1.get()
    if entry_multiskill2.get() == "":
        skill_multi2 = "na"
    else:
        skill_multi2 = entry_multiskill2.get()
    if entry_multiskill3.get() == "":
        skill_multi3 = "na"
    else:
        skill_multi3 = entry_multiskill3.get()
    
    # Nessesary details value = value of entry if no error
    name = entry_namep.get()
    email = entry_emailp.get()
    phone = entry_phonep.get()
    rating = "na"
    bday = datetime.datetime.strftime(pro_bday, "%d/%m/%Y")
    age = str(pro_age)

    # Open txt file and append new pro details
    pro_profile=open("pro_profile.txt","a")
    pro_profile.write("\n"+uid+"\n")
    pro_profile.write(name+"\n")
    pro_profile.write(email+"\n")
    pro_profile.write(phone+"\n")
    pro_profile.write(gender+"\n")
    pro_profile.write(age+"\n")
    pro_profile.write(bday+"\n")
    pro_profile.write(bio+"\n")
    pro_profile.write(lit+"\n")
    pro_profile.write(pgrm+"\n")
    pro_profile.write(multi+"\n")
    # Group 3 skills in each field to become one line
    pro_profile.write(f'{skill_lit1},{skill_lit2},{skill_lit3}\n')
    pro_profile.write(f'{skill_pgrm1},{skill_pgrm2},{skill_pgrm3}\n')
    pro_profile.write(f'{skill_multi1},{skill_multi2},{skill_multi3}\n')
    pro_profile.write(rating)
    pro_profile.close()

    #Call function after all validation and data record completed
    register_complete()

# Function to create entry widgets when value = 1, and place " - " when value = 0
def field_existp():
    global check_lit
    global check_pgrm
    global check_multi

    entry_litskill1 = Entry(frame_startp, font=style_text2)
    entry_litskill2 = Entry(frame_startp, font=style_text2)
    entry_litskill3 = Entry(frame_startp, font=style_text2)

    entry_pgrmskill1 = Entry(frame_startp, font=style_text2)
    entry_pgrmskill2 = Entry(frame_startp, font=style_text2)
    entry_pgrmskill3 = Entry(frame_startp, font=style_text2)

    entry_multiskill1 = Entry(frame_startp, font=style_text2)
    entry_multiskill2 = Entry(frame_startp, font=style_text2)
    entry_multiskill3 = Entry(frame_startp, font=style_text2)
    if check_lit.get() == 1:
        entry_litskill1.place(x=300, y=600, width=350, height=45)
        entry_litskill2.place(x=700, y=600, width=350, height=45)
        entry_litskill3.place(x=1100, y=600, width=350, height=45)
    if check_lit.get() == 0:
        entry_litskill1.place_forget()
        entry_litskill2.place_forget()
        entry_litskill3.place_forget()
        lbl_skill3 = ttkb.Label(frame_startp, text=" -                                                                                                                "
                                , font=style_text5)
        lbl_skill3.place(x=300, y=600)

    if check_pgrm.get() == 1:
        entry_pgrmskill1.place(x=380, y=670, width=350, height=45)
        entry_pgrmskill2.place(x=780, y=670, width=350, height=45)
        entry_pgrmskill3.place(x=1180, y=670, width=350, height=45)
    if check_pgrm.get() == 0:
        entry_pgrmskill1.place_forget()
        entry_pgrmskill2.place_forget()
        entry_pgrmskill3.place_forget()
        lbl_skill3 = ttkb.Label(frame_startp, text=" -                                                                                                                "
                                , font=style_text5)
        lbl_skill3.place(x=380, y=670)

    if check_multi.get() == 1:
        entry_multiskill1.place(x=320, y=740, width=350, height=45)
        entry_multiskill2.place(x=720, y=740, width=350, height=45)
        entry_multiskill3.place(x=1120, y=740, width=350, height=45)
    if check_multi.get() == 0:
        entry_multiskill1.place_forget()
        entry_multiskill2.place_forget()
        entry_multiskill3.place_forget()
        lbl_skill3 = ttkb.Label(frame_startp, text=" -                                                                                                                "
                                , font=style_text5)
        lbl_skill3.place(x=320, y=740)

# Frame Pro complete profile
def start_edit_profilep():
    frame_startp.grid(row=0, column=0, sticky="nsew")
    frame_startp.grid_propagate(False)
    frame_startp.tkraise()

    global entry_namep
    global entry_emailp
    global entry_phonep
    global entry_genderp
    global entry_bdayp
    global entry_biop

    global entry_litskill1
    global entry_litskill2
    global entry_litskill3
    global entry_pgrmskill1
    global entry_pgrmskill2
    global entry_pgrmskill3
    global entry_multiskill1
    global entry_multiskill2
    global entry_multiskill3

    # Widgets creating and positioning etc.
    lbl_title = Label(frame_startp, text="Complete Your Profile", font=style_title1)
    lbl_title.place(x=30, y=20)
    lbl_title = Label(frame_startp, text="Clients will see your profile when browsing, and don't worry because these can be edited later in Profile.", font=style_text1)
    lbl_title.place(x=30, y=90)

    lbl_uid = Label(frame_startp, text="User ID: "+ uid, font=style_text4)
    lbl_uid.place(x=30, y=170)
    lbl_uidinfo = Label(frame_startp, text="Others will search for you by this ID", font=style_text3)
    lbl_uidinfo.place(x=30, y=210)

    lbl_name = Label(frame_startp, text="Name: ", font=style_text4)
    lbl_name.place(x=30, y=260)
    lbl_nameinfo = Label(frame_startp, text="How you want others to call you", font=style_text3)
    lbl_nameinfo.place(x=30, y=300)
    entry_namep = Entry(frame_startp, font=style_text2)
    entry_namep.place(x=150, y=260, width=300, height=45)
    entry_namep.insert(0,name)

    lbl_email = Label(frame_startp, text="Email address: ", font=style_text4)
    lbl_email.place(x=30, y=350)
    lbl_emailinfo = Label(frame_startp, text="A way for clients to contact you", font=style_text3)
    lbl_emailinfo.place(x=30, y=390)
    entry_emailp = Entry(frame_startp, font=style_text2)
    entry_emailp.place(x=260, y=350, width=300, height=45)

    lbl_phone = Label(frame_startp, text="Phone number: ", font=style_text4)
    lbl_phone.place(x=30, y=440)
    lbl_phoneinfo = Label(frame_startp, text="Another way to keep in contact with your client", font=style_text3)
    lbl_phoneinfo.place(x=30, y=480)
    entry_phonep = Entry(frame_startp, font=style_text2)
    entry_phonep.place(x=270, y=440, width=300, height=45)

    lbl_moreinfo = Label(frame_startp, text="Let others know more about you", font=style_text1)
    lbl_moreinfo.place(x=700, y=170)

    lbl_gender = Label(frame_startp, text="Gender: ", font=style_text4)
    lbl_gender.place(x=700, y=220)
    genders = ['Male', 'Female', 'Others', 'Rather not say']
    entry_genderp = ttkb.Combobox(frame_startp, bootstyle='dark', values=genders)
    entry_genderp.place(x=850, y=220)

    lbl_bday = Label(frame_startp, text="Birthday: ", font=style_text4)
    lbl_bday.place(x=700, y=270)
    bday = "6/9/2000"
    startbday = datetime.datetime.strptime(bday, "%d/%m/%Y").date()
    entry_bdayp = ttkb.DateEntry(frame_startp, bootstyle="dark", dateformat="%d/%m/%Y", startdate=startbday)
    entry_bdayp.place(x=850, y=270)

    lbl_age = Label(frame_startp, text="Age:  ", font=style_text4)
    lbl_age.place(x=700, y=320)

    lbl_bioinfo = Label(frame_startp, text="A simple biography about yourself", font=style_text1)
    lbl_bioinfo.place(x=1250, y=170)
    lbl_bio = Label(frame_startp, text="Bio: ", font=style_text4)
    lbl_bio.place(x=1250, y=220)
    entry_biop = Text(frame_startp, wrap="word", relief="sunken", width=30, height=5, font=style_text2)
    entry_biop.place(x=1250, y=260)
    entry_biop.configure(highlightthickness=2)


    sep = ttkb.Separator(frame_startp, bootstyle="default", orient="horizontal")
    sep.place(relx=0.5, y=530, relwidth=0.98, anchor=CENTER)

    lbl_field = Label(frame_startp, text="Field(s): ", font=style_text4)
    lbl_field.place(x=30, y=550)


    lbl_lit = Label(frame_startp, text="Literature Skill(s): ", font=style_text4)
    lbl_lit.place(x=30, y=600)
    lbl_pgrm = Label(frame_startp, text="Programming Skill(s): ", font=style_text4)
    lbl_pgrm.place(x=30, y=670)
    lbl_multi = Label(frame_startp, text="Multimedia Skill(s): ", font=style_text4)
    lbl_multi.place(x=30, y=740)

    lbl_skillinfo = Label(frame_startp, text="Your price per hour will depends on the number of skills you have: ", font=style_text3)
    lbl_skillinfo.place(x=30, y=785)
    lbl_skillinfo = Label(frame_startp, text="The base rate per hour for each field is RM10. 5% will be added for each skill within a field", font=style_text3)
    lbl_skillinfo.place(x=30, y=815)
    lbl_skillinfo = Label(frame_startp, text="which a maximum 15% will be added if you have maximum three skills in a field.", font=style_text3)
    lbl_skillinfo.place(x=30, y=845)
    lbl_skillinfo = Label(frame_startp, text="Lastly, the platform will take 10% from the total fee as commission.", font=style_text3)
    lbl_skillinfo.place(x=30, y=875)

    # check buttons for fields (take value from previous page)
    style_cbtn_startp = ttkb.Style()
    style_cbtn_startp.configure("BtnStartP.dark.Toolbutton", font=(style_text4))

    global choose_lit
    global choose_pgrm
    global choose_multi

    choose_lit = ttkb.Checkbutton(frame_startp, 
                                text="Literature", 
                                style="BtnStartP.dark.Toolbutton",
                                variable=check_lit,
                                onvalue=1,
                                offvalue=0,
                                command=field_existp
                                )
    choose_lit.place(x=200, y=545,width=250, height=45)

    choose_pgrm = ttkb.Checkbutton(frame_startp, 
                                text="Programming", 
                                style="BtnStartP.dark.Toolbutton",
                                variable=check_pgrm,
                                onvalue=1,
                                offvalue=0,
                                command=field_existp
                                )
    choose_pgrm.place(x=500, y=545,width=250, height=45)

    choose_multi = ttkb.Checkbutton(frame_startp, 
                                text="Multimedia", 
                                style="BtnStartP.dark.Toolbutton",
                                variable=check_multi,
                                onvalue=1,
                                offvalue=0,
                                command=field_existp
                                )
    choose_multi.place(x=800, y=545,width=250, height=45)

    # If value get = 1, checkbutton is checked and vice versa
    if lit == "y":
        check_lit.set(1)
    if lit == "n":
        check_lit.set(0)
    if pgrm == "y":
        check_pgrm.set(1)
    if pgrm == "n":
        check_pgrm.set(0)
    if multi == "y":
        check_multi.set(1)
    if multi == "n":
        check_multi.set(0)

    entry_litskill1 = Entry(frame_startp, font=style_text2)
    entry_litskill2 = Entry(frame_startp, font=style_text2)
    entry_litskill3 = Entry(frame_startp, font=style_text2)

    entry_pgrmskill1 = Entry(frame_startp, font=style_text2)
    entry_pgrmskill2 = Entry(frame_startp, font=style_text2)
    entry_pgrmskill3 = Entry(frame_startp, font=style_text2)

    entry_multiskill1 = Entry(frame_startp, font=style_text2)
    entry_multiskill2 = Entry(frame_startp, font=style_text2)
    entry_multiskill3 = Entry(frame_startp, font=style_text2)
    # if field value = 1, create and place entry widgets for respective field skills input
    if check_lit.get() == 1:
        entry_litskill1.place(x=300, y=600, width=350, height=45)
        entry_litskill2.place(x=700, y=600, width=350, height=45)
        entry_litskill3.place(x=1100, y=600, width=350, height=45)
    if check_lit.get() == 0:
        lbl_skill3 = ttkb.Label(frame_startp, text=" -                                                                                                                "
                                , font=style_button3)
        lbl_skill3.place(x=300, y=600)

    if check_pgrm.get() == 1:
        entry_pgrmskill1.place(x=380, y=670, width=350, height=45)
        entry_pgrmskill2.place(x=780, y=670, width=350, height=45)
        entry_pgrmskill3.place(x=1180, y=670, width=350, height=45)
    if check_pgrm.get() == 0:
        lbl_skill3 = ttkb.Label(frame_startp, text="                                                                                                                "
                                , font=style_button3)
        lbl_skill3.place(x=380, y=670)

    if check_multi.get() == 1:
        entry_multiskill1.place(x=320, y=740, width=350, height=45)
        entry_multiskill2.place(x=720, y=740, width=350, height=45)
        entry_multiskill3.place(x=1120, y=740, width=350, height=45)
    if check_multi.get() == 0:
        lbl_skill3 = ttkb.Label(frame_startp, text=" -                                                                                                                "
                                , font=style_button3)
        lbl_skill3.place(x=320, y=740)

    style_cbtn_startp.configure("BtnConfirmP.dark.TButton", font=("Helvetica", 20,"bold"))
    btn_confirm = ttkb.Button(frame_startp, text="Confirm", width=30, style="BtnConfirmP.dark.TButton", takefocus=False, command=check_startp)
    btn_confirm.place(relx=0.8, rely=0.85, anchor=CENTER, height=100)

# Function Check field at least 1
def check_field():

    global lit
    global pgrm
    global multi

    if check_lit.get() + check_pgrm.get() + check_multi.get() == 0:
        lbl_errorfield = Label(frame_choosefield, font=style_texterror)
        lbl_errorfield.place(relx=0.5, rely=0.8, anchor=CENTER)
        lbl_errorfield.configure(fg='RED', text = "*** Please choose at least 1 field !")
    else:
        lbl_errorfield = Label(frame_choosefield, font=style_texterror)
        lbl_errorfield.place(relx=0.5, rely=0.8, anchor=CENTER)
        lbl_errorfield.configure(text = "                                                                  ")
        if check_lit.get() == 1:
            lit  = "y"
        if check_lit.get() == 0:
            lit = "n"
        if check_pgrm.get() == 1:
            pgrm = "y"
        if check_pgrm.get() == 0:
            pgrm = "n"
        if check_multi.get() == 1:
            multi = "y"
        if check_multi.get() == 0:
            multi = "n"

        start_edit_profilep()

# Frame Pro choose field function
def choose_field():

    frame_choosefield.grid(row=0, column=0, sticky="nsew")
    frame_choosefield.grid_propagate(False)
    frame_choosefield.tkraise()

    lbl_field = Label(frame_choosefield, text = "Please choose the field(s) that you have skills in (Minimum 1 Maximum 3).  ", font=style_title1)
    lbl_field.place(relx=0.5, rely=0.1, anchor=CENTER)

    global lit
    global pgrm
    global multi

    global check_lit
    global check_pgrm
    global check_multi
    
    check_lit = IntVar()
    check_pgrm = IntVar()
    check_multi = IntVar()

    style_cbtn_choosefield = ttkb.Style()
    style_cbtn_choosefield.configure("BtnChooseField.dark.Toolbutton", font=(style_title1))

    cbtn_lit = ttkb.Checkbutton(frame_choosefield, 
                                text="Literature", 
                                style="BtnChooseField.dark.Toolbutton",
                                variable=check_lit,
                                onvalue=1,
                                offvalue=0,
                                )
    cbtn_lit.place(relx=0.2, rely=0.4, anchor=CENTER, width=500, height=200)

    cbtn_pgrm = ttkb.Checkbutton(frame_choosefield, 
                                text="Programming", 
                                style="BtnChooseField.dark.Toolbutton",
                                variable=check_pgrm,
                                onvalue=1,
                                offvalue=0,
                                )
    cbtn_pgrm.place(relx=0.5, rely=0.4, anchor=CENTER, width=500, height=200)

    cbtn_multi = ttkb.Checkbutton(frame_choosefield, 
                                text="Multimedia", 
                                style="BtnChooseField.dark.Toolbutton",
                                variable=check_multi,
                                onvalue=1,
                                offvalue=0,
                                )
    cbtn_multi.place(relx=0.8, rely=0.4, anchor=CENTER, width=500, height=200)

    style_cbtn_choosefield.configure("BtnConfirm.dark.Outline.TButton", font=("Helvetica",20,"bold"))
    btn_confirm = ttkb.Button(frame_choosefield, text="Confirm", width=20, style="BtnConfirm.dark.Outline.TButton", takefocus=False, command=check_field)
    btn_confirm.place(relx=0.5, rely=0.85, anchor=CENTER, height=80)

# btn_submit Function
def check_submitp():
    # Get input field value
    global name
    global uid
    global pwd

    name = entry_name.get()
    uid = entry_id.get()
    pwd = entry_pwd.get()
    pwdconfirm = entry_pwdconfirm.get()

    # Open txt file
    file_client=open("clientlist.txt","r")
    client_content=file_client.read()
    clientlist=client_content.split("\n")

    file_pro=open("prolist.txt","r")
    pro_content=file_pro.read()
    prolist=pro_content.split("\n")

    pro_profile=open("pro_profile.txt","r")
    proprofile_content=pro_profile.read()
    proprofile_list=proprofile_content.split("\n")

    # Create list for later status value append
    status_list = []

    # Check whether input value fulfill requirements
    if not name:
        status_list.append("name_empty")
    if not uid:
        status_list.append("id_empty")
    #if id == clientlist[index_id]:(later use)
    if uid in clientlist or uid in prolist:
        status_list.append("id_exist")
    if not pwd:
        status_list.append("pwd_empty")
    if not pwdconfirm:
        status_list.append("pwdconfirm_empty")
    if len(pwd) < 8:
        status_list.append("pwd_small")
    elif pwdconfirm != pwd:
        status_list.append("pwd_wrong")

    # if statement start
    if status_list:
        lbl_errorname = Label(frame_registerp, font=style_texterror)
        lbl_errorname.place(x=950, y=280)
        lbl_errorname.configure(text = "                                                                    ")
        lbl_errorid = Label(frame_registerp, font=style_texterror)
        lbl_errorid.place(x=950, y=360)
        lbl_errorid.configure(text="                                                                    ")
        lbl_errorpwd = Label(frame_registerp, font=style_texterror)
        lbl_errorpwd.place(x=950, y=440)
        lbl_errorpwd.configure(text="                                                                    ")
        lbl_errorpwdconfirm = Label(frame_registerp, font=style_texterror)
        lbl_errorpwdconfirm.place(x=950, y=520)
        lbl_errorpwdconfirm.configure(text="                                                                             ")
        lbl_status = Label(frame_registerp, font=style_texterror)
        lbl_status.place(x=830, y=750)
        lbl_status.configure(text="                                                  ")
        # for loop that shows error message below respective input field until fulfill all requirements
        for status in status_list:
            if status == "name_empty":
                entry_name.delete(0, END)
                lbl_errorname = Label(frame_registerp, font=style_texterror)
                lbl_errorname.place(x=950, y=280)
                lbl_errorname.configure(fg='RED', text = "Name cannot be empty.")
            if status == "id_empty":
                entry_id.delete(0, END)
                lbl_errorid = Label(frame_registerp, font=style_texterror)
                lbl_errorid.place(x=950, y=360)
                lbl_errorid.configure(fg='RED', text = "User ID cannot be empty.        ")
            if status == 'id_exist':
                entry_id.delete(0, END)
                lbl_errorid = Label(frame_registerp, font=style_texterror)
                lbl_errorid.place(x=950, y=360)
                lbl_errorid.configure(fg='RED', text = "User ID already exist.     ")
            if status == "pwd_empty":
                entry_pwd.delete(0, END)
                lbl_errorpwd = Label(frame_registerp, font=style_texterror)
                lbl_errorpwd.place(x=950, y=440)
                lbl_errorpwd.configure(fg='RED', text = "Password cannot be empty.      ")
            if status == "pwdconfirm_empty":
                entry_pwdconfirm.delete(0, END)
                lbl_errorpwdconfirm = Label(frame_registerp, font=style_texterror)
                lbl_errorpwdconfirm.place(x=950, y=520)
                lbl_errorpwdconfirm.configure(fg='RED', text = "Password confirmation cannot be empty.       ")
            if status == "pwd_small":
                entry_pwd.delete(0, END)
                entry_pwdconfirm.delete(0, END)
                lbl_errorpwd = Label(frame_registerp, font=style_texterror)
                lbl_errorpwd.place(x=950, y=440)
                lbl_errorpwd.configure(fg='RED', text = "Password must be 8 characters or more.     ")
            if status == "pwd_wrong":
                entry_pwd.delete(0, END)
                entry_pwdconfirm.delete(0, END)
                lbl_errorpwdconfirm = Label(frame_registerp, font=style_texterror)
                lbl_errorpwdconfirm.place(x=950, y=440)
                lbl_errorpwdconfirm.configure(fg='RED', text = "Password confirmation failed. Please try again.")
        lbl_status = Label(frame_registerp, text = "*** Please check input.", font=style_texterror, bg="#d0d6d6")
        lbl_status.place(x=830, y=750)
        lbl_status.configure(fg='RED')
        return
    
    # Break for loop(when fulfill requirements)
    lbl_errorname = Label(frame_registerp, font=style_texterror)
    lbl_errorname.place(x=950, y=280)
    lbl_errorname.configure(text = "                                                                    ")
    lbl_errorid = Label(frame_registerp, font=style_texterror)
    lbl_errorid.place(x=950, y=360)
    lbl_errorid.configure(text="                                                                    ")
    lbl_errorpwd = Label(frame_registerp, font=style_texterror)
    lbl_errorpwd.place(x=950, y=440)
    lbl_errorpwd.configure(text="                                                                    ")
    lbl_errorpwdconfirm = Label(frame_registerp, font=style_texterror)
    lbl_errorpwdconfirm.place(x=950, y=520)
    lbl_errorpwdconfirm.configure(text="                                                                             ")
    lbl_status = Label(frame_registerp, font=style_texterror)
    lbl_status.place(x=830, y=750)
    lbl_status.configure(text="                                                  ")

    # Open txt file and append new user information, then close txt file and continue to home page.

    file_pro=open("prolist.txt","a")
    file_pro.write("\n"+uid+"\n")
    file_pro.write(name+"\n")
    file_pro.write(pwd+"\n")
    file_pro.write(user)
    file_pro.close()

    choose_field()

# Register for Pro
def register_pro():

    # User type = "P"ro
    global user
    user = "p"

    frame_registerp.grid(row=0, column=0, sticky="nsew")
    frame_registerp.grid_propagate(False)
    frame_registerp.tkraise()

    # Create, place, and configure label ori value for error message
    lbl_errorname = Label(frame_registerp, text = "                                                  ", font=style_texterror, bg="#d0d6d6")
    lbl_errorname.place(x=950, y=280)
    lbl_errorname.configure(fg='RED')
    lbl_errorid = Label(frame_registerp, text = "                                                  ", font=style_texterror, bg="#d0d6d6")
    lbl_errorid.place(x=950, y=360)
    lbl_errorid.configure(fg='RED')
    lbl_errorpwd = Label(frame_registerp, text = "                                                                       ", font=style_texterror, bg="#d0d6d6")
    lbl_errorpwd.place(x=950, y=440)
    lbl_errorpwd.configure(fg='RED')
    lbl_errorpwdconfirm = Label(frame_registerp, text = "                                                                   ", font=style_texterror, bg="#d0d6d6")
    lbl_errorpwdconfirm.place(x=950, y=520)
    lbl_errorpwdconfirm.configure(fg='RED')
    lbl_status = Label(frame_registerp, text = "                                        ", font=style_texterror, bg="#d0d6d6")
    lbl_status.place(x=830, y=750)
    lbl_status.configure(fg='RED')

    lbl_register = Label(frame_registerp, text = "Create a Task Striker Account", font=style_title2, bg="#d0d6d6", padx=10, pady=10)
    lbl_register.place(relx=0.5, y=100, anchor=CENTER)

    lbl_name = Label(frame_registerp, text = "Name  ", bg="#d0d6d6", font=style_text2, padx=10, pady=10)
    lbl_id = Label(frame_registerp, text = "User ID", bg="#d0d6d6", font=style_text2, padx=10, pady=10)
    lbl_pwd = Label(frame_registerp, text = "Password (8 or more characters) ", font=style_text2, bg="#d0d6d6", padx=10, pady=10)
    lbl_pwdconfirm = Label(frame_registerp, text = "Password Confirmation", font=style_text2, bg="#d0d6d6", padx=10, pady=10)

    lbl_name.place(x=450, y=230)
    lbl_id.place(x=450, y=310)
    lbl_pwd.place(x=450, y=390)
    lbl_pwdconfirm.place(x=450, y=470)

    global entry_name
    global entry_id
    global entry_pwd
    global entry_pwdconfirm

    # widget creating and positioning
    entry_name = Entry(frame_registerp)
    entry_id = Entry(frame_registerp)
    entry_pwd = Entry(frame_registerp)
    entry_pwdconfirm = Entry(frame_registerp)

    entry_name.place(x=950, y=235, width=450, height=40)
    entry_id.place(x=950, y=315, width=450, height=40)
    entry_pwd.place(x=950, y=395, width=450, height=40)
    entry_pwdconfirm.place(x=950, y=475, width=450, height=40)

    entry_name.configure(font=style_text1)
    entry_id.configure(font=style_text1)
    entry_pwd.configure(font=style_text1, show="*")
    entry_pwdconfirm.configure(font=style_text1, show="*")

    style_btn_registerp = ttkb.Style()
    style_btn_registerp.configure("BtnRP.dark.TButton", font=("Helvetica",15,"bold"))
    btn_submit = ttkb.Button(frame_registerp, text="Create", width=20,  style="BtnRP.dark.TButton", takefocus=False, command=check_submitp)
    btn_submit.place(relx=0.5, rely=0.775, height=80, anchor=CENTER)

    style_btn_registerp.configure("Btnback.dark.Outline.TButton", font=("Helvetica",15))
    btn_back = ttkb.Button(frame_registerp, text="Back", width=15,  style="Btnback.dark.Outline.TButton", takefocus=False, command=lambda: frame_choosecp.tkraise())
    btn_back.place(x=100, y=800, height=80)


# ----- Choose Client/Pro Function -----

# Choose client or pro after clicking Register
def choosecp():
    frame_choosecp.grid(row=0, column=0, sticky="nsew")
    frame_choosecp.grid_propagate(False)
    frame_choosecp.configure(width=1920, height=1080)
    frame_choosecp.tkraise()

    label_choose = Label(frame_choosecp, text="Join as a Client or Professional", font=style_title2)
    label_choose.place(relx=0.52,rely=0.1, anchor=CENTER)

    style_btn_choosecp = ttkb.Style()
    style_btn_choosecp.configure("BtnCP.dark.Outline.TButton", font=("Helvetica",15,"bold"))

    btn_client = ttkb.Button(frame_choosecp, text="Client", width=30, style="BtnCP.dark.Outline.TButton", takefocus=False, command=register_client)
    btn_client.place(relx=0.335, rely=0.42, anchor=CENTER, width=600, height=500)

    btn_pro = ttkb.Button(frame_choosecp, text="Pro", width=30,  style="BtnCP.dark.Outline.TButton", takefocus=False, command=register_pro)
    btn_pro.place(relx=0.665, rely=0.42, anchor=CENTER, width=600, height=500)

    style_btn_choosecp.configure("Btnback.dark.Outline.TButton", font=("Helvetica",15))
    btn_back = ttkb.Button(frame_choosecp, text="Back", width=15,  style="Btnback.dark.Outline.TButton", takefocus=False, command=lambda: frame_main.tkraise())
    btn_back.place(x=100, y=800, height=80)


#---------- Get Start Functions ----------

# Get Started page 4
def getstart4():
    frame_getstart4.place(x=0, y=0, relheight=1, relwidth=1)
    frame_getstart4.lift()

    lbl_getstart = Label(frame_getstart4, text = "Let's start your journey in Task Striker", font=style_title3)
    lbl_getstart.place(relx=0.5, rely=0.27, anchor=CENTER)
    lbl_getstart = Label(frame_getstart4, text = "NOW", font=style_title4)
    lbl_getstart.place(relx=0.5, rely=0.4, anchor=CENTER)
    lbl_getstart = Label(frame_getstart4, text = "! ! !", font=style_title4)
    lbl_getstart.place(relx=0.49, rely=0.53, anchor=CENTER)

    style_btn_getstart4 = ttkb.Style()
    style_btn_getstart4.configure("BtnGS4.dark.TButton", font=("Helvetica",20,"bold"))
    btn_back = ttkb.Button(frame_getstart4, text="Confirm", width=25, style="BtnGS4.dark.TButton", takefocus=False, command=choosecp)
    btn_back.place(relx=0.5, rely=0.8, anchor=CENTER, height=100)

# Get Started page 3
def getstart3():
    frame_getstart3.place(x=0, y=0, relheight=1, relwidth=1)
    frame_getstart3.lift()

    lbl_getstart = Label(frame_getstart3, text = "Pro", font=style_title4)
    lbl_getstart.place(relx=0.8, rely=0.1, anchor=CENTER)

    global img_gs6
    img_gs6 = 'C:\VSCode\sem3 project\getstart6.png'
    img_gs6 = PhotoImage(file='C:\VSCode\sem3 project\getstart6.png')
    lbl_gs6 = Label(frame_getstart3, image=img_gs6)
    lbl_gs6.place(relx=0.01, rely=0.05)

    global img_gs7
    img_gs7 = 'C:\VSCode\sem3 project\getstart7.png'
    img_gs7 = PhotoImage(file='C:\VSCode\sem3 project\getstart7.png')
    lbl_gs7 = Label(frame_getstart3, image=img_gs7)
    lbl_gs7.place(relx=0.73, rely=0.45)

    lbl_info3 = Label(frame_getstart3, text = "A great chance to earn some extra income with your professional skill !", font=style_text4)
    lbl_info3.place(relx=0.35, rely=0.25)

    lbl_info3 = Label(frame_getstart3, text = "Obtain more experiences and meet with new people !", font=style_text4)
    lbl_info3.place(relx=0.28, rely=0.63)

    style_btn_getstart3 = ttkb.Style()
    style_btn_getstart3.configure("BtnGS3.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    style_btn_getstart3.configure("BtnGS3.dark.Outline.TButton", font=("Helvetica",15,"bold"))
    btn_back = ttkb.Button(frame_getstart3, text="Back", width=15, style="BtnGS3.dark.Outline.TButton", takefocus=False, command= lambda: frame_getstart2.lift())
    btn_back.place(relx=0.4, rely=0.85, anchor=CENTER, height=80)

    btn_next = ttkb.Button(frame_getstart3, text="Next", width=15, style="BtnGS3.dark.Outline.TButton", takefocus=False, command=getstart4)
    btn_next.place(relx=0.6, rely=0.85, anchor=CENTER, height=80)

# Get Started page 2
def getstart2():
    frame_getstart2.place(x=0, y=0, relheight=1, relwidth=1)
    frame_getstart2.lift()

    lbl_getstart = Label(frame_getstart2, text = "Client", font=style_title4)
    lbl_getstart.place(relx=0.15, rely=0.1, anchor=CENTER)

    global img_gs3
    img_gs3 = 'C:\VSCode\sem3 project\getstart3.png'
    img_gs3 = PhotoImage(file='C:\VSCode\sem3 project\getstart3.png')
    lbl_gs3 = Label(frame_getstart2, image=img_gs3)
    lbl_gs3.place(relx=0.63, rely=0.15)

    global img_gs4
    img_gs4 = 'C:\VSCode\sem3 project\getstart4.png'
    img_gs4 = PhotoImage(file='C:\VSCode\sem3 project\getstart4.png')
    lbl_gs4 = Label(frame_getstart2, image=img_gs4)
    lbl_gs4.place(relx=0.1, rely=0.35)

    global img_gs5
    img_gs5 = 'C:\VSCode\sem3 project\getstart5.png'
    img_gs5 = PhotoImage(file='C:\VSCode\sem3 project\getstart5.png')
    lbl_gs5 = Label(frame_getstart2, image=img_gs5)
    lbl_gs5.place(relx=0.63, rely=0.55)

    lbl_info2 = Label(frame_getstart2, text = "Search for your perfect Pro from various fields !", font=style_text4)
    lbl_info2.place(relx=0.59, rely=0.25, anchor=E)

    lbl_info2 = Label(frame_getstart2, text = "Have a chat with selected Pro before hiring !", font=style_text4)
    lbl_info2.place(relx=0.4, rely=0.45)

    lbl_info2 = Label(frame_getstart2, text = "Join our membership to enjoy ad-free bliss and discounts !", font=style_text4)
    lbl_info2.place(relx=0.59, rely=0.69, anchor=E)

    style_btn_getstart2 = ttkb.Style()
    style_btn_getstart2.configure("BtnGS2.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    style_btn_getstart2.configure("BtnGS2.dark.Outline.TButton", font=("Helvetica",15,"bold"))
    btn_back = ttkb.Button(frame_getstart2, text="Back", width=15, style="BtnGS2.dark.Outline.TButton", takefocus=False, command= lambda: frame_getstart1.lift())
    btn_back.place(relx=0.4, rely=0.85, anchor=CENTER, height=80)

    btn_next = ttkb.Button(frame_getstart2, text="Next", width=15, style="BtnGS1.dark.Outline.TButton", takefocus=False, command=getstart3)
    btn_next.place(relx=0.6, rely=0.85, anchor=CENTER, height=80)

# Get Started page 1
def getstart1():
    frame_getstart1.place(x=0, y=0, relheight=1, relwidth=1)
    frame_getstart1.lift()

    style_btn_getstart1 = ttkb.Style()
    style_btn_getstart1.configure("BtnGS.dark.Outline.TButton", font=("Helvetica",20,"bold"))

    lbl_getstart = Label(frame_getstart1, text = "Welcome to Task Striker !!!", font=style_title4)
    lbl_getstart.place(relx=0.5, rely=0.15, anchor=CENTER)

    global img_gs1
    img_gs1 = 'C:\VSCode\sem3 project\getstart1.png'
    img_gs1 = PhotoImage(file='C:\VSCode\sem3 project\getstart1.png')
    lbl_gs1 = Label(frame_getstart1, image=img_gs1)
    lbl_gs1.place(relx=0.07, rely=0.78, anchor=CENTER)

    global img_gs2
    img_gs2 = 'C:\VSCode\sem3 project\getstart2.png'
    img_gs2 = PhotoImage(file='C:\VSCode\sem3 project\getstart2.png')
    lbl_gs2 = Label(frame_getstart1, image=img_gs2)
    lbl_gs2.place(relx=0.89, rely=0.78, anchor=CENTER)

    lbl_info1 = Label(frame_getstart1, text = "Task Striker is a platform that connects Clients with skilled Pros (Professionals)", font=style_text4)
    lbl_info1.place(relx=0.03, rely=0.3)
    lbl_info1 = Label(frame_getstart1, text = "to tackle their tasks, projects, and work.", font=style_text4)
    lbl_info1.place(relx=0.03,rely=0.35)

    lbl_info1 = Label(frame_getstart1, text = "With various amount of talented Pros available from multiple fields, Clients can", font=style_text4)
    lbl_info1.place(relx=0.97, rely=0.45, anchor=E)
    lbl_info1 = Label(frame_getstart1, text = "find the perfect match to help them solve their challenges.", font=style_text4)
    lbl_info1.place(relx=0.97, rely=0.5, anchor=E)

    lbl_info1 = Label(frame_getstart1, text = "Whether you need assistance with a small task or a complex project, Task Striker", font=style_text4)
    lbl_info1.place(relx=0.5, rely=0.59, anchor=CENTER)

    lbl_info1 = Label(frame_getstart1, text = "offers competitive prices and ensures high-quality results every time !", font=style_text4)
    lbl_info1.place(relx=0.5, rely=0.64, anchor=CENTER)

    style_btn_getstart1.configure("BtnGS1.dark.Outline.TButton", font=("Helvetica",15,"bold"))
    btn_back = ttkb.Button(frame_getstart1, text="Back", width=15, style="BtnGS1.dark.Outline.TButton", takefocus=False, command= lambda: frame_main.tkraise())
    btn_back.place(relx=0.4, rely=0.85, anchor=CENTER, height=80)

    btn_next = ttkb.Button(frame_getstart1, text="Next", width=15, style="BtnGS1.dark.Outline.TButton", takefocus=False, command=getstart2)
    btn_next.place(relx=0.6, rely=0.85, anchor=CENTER, height=80)

# ----- Main Function -----
def main():

    frame_main.grid(row=0, column=0, sticky="nsew")
    frame_main.grid_propagate(False)
    frame_main.configure(width=1920, height=1080)
    frame_main.tkraise()

    global img_logo # so that the img will not be define as garbage or cache smth by the system

    img_logo = 'C:\VSCode\sem3 project\logo.png'
    img_logo = PhotoImage(file='C:\VSCode\sem3 project\logo.png')
    lbl_logo = Label(frame_main, image=img_logo)
    lbl_logo.place(relx=0.528, rely=0.25, anchor=CENTER)

    style_btn_main = ttkb.Style()
    style_btn_main.configure("BtnMain.dark.Outline.TButton", font=("Helvetica",15))

    btn_getstart = ttkb.Button(frame_main, text="Get Started!", width=20,style="BtnMain.dark.Outline.TButton", padding=(80,50), takefocus=False, command=getstart1)
    btn_login = ttkb.Button(frame_main, text="Login", width=20,style="BtnMain.dark.Outline.TButton", padding=(80,50), takefocus=False, command=login)
    btn_register = ttkb.Button(frame_main, text="Register", width=20,style="BtnMain.dark.Outline.TButton", padding=(80,50), takefocus=False, command= choosecp)

    btn_getstart.place(relx=0.5, rely=0.5, anchor=CENTER)
    btn_login.place(relx=0.5, rely=0.64, anchor=CENTER)
    btn_register.place(relx=0.5, rely=0.78, anchor=CENTER)

# --------------------  Main program --------------------
main()


# -------------------- Close txt file ----------------------
file_client.close()
file_pro.close()
pro_profile.close()
client_profile.close()

# --------------------  Loop for main window --------------------
root.mainloop()